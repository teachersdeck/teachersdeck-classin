/* =========================================================
   TeachersDeck — core shell
   Storage model:
     localStorage  -> small state (layout, active widgets, theme id, roster, checklist)
     IndexedDB     -> larger blobs (uploaded files, custom background/logo images), db name "TeachersDeck"
   ========================================================= */

const LS_KEY = 'ww_state_v1';

/* ---------------- Classes (multiple independent decks) ----------------
   A teacher with several classes a day keeps one TeachersDeck per class.
   Each class has its OWN copy of everything that lives in `state` — roster,
   open widgets and their positions, theme/background, checklist, scoreboard,
   attendance, agenda, layout mode, language, dock placement, the lot — stored
   under its own localStorage key. Switching class reloads the page so the new
   class comes up as a clean instance (every widget re-inits from its own
   state) rather than trying to hot-swap 4,000 lines of live UI.

   Shared across all classes (deliberately — it's one teacher, one browser):
   the IndexedDB media library (files, games, music, videos, sounds), the
   school logo, and the Pro license. Background IMAGES are per class (each
   class stores its own image id in state.activeBgId).

   Key layout:
     td_classes_v1      -> { active:<id>, list:[{id,name}, ...] }  (the index)
     ww_state_v1        -> state for the first/default class (unchanged, so
                           anyone upgrading keeps their existing deck as-is)
     ww_state_v1::<id>  -> state for every class added after that
   ---------------------------------------------------------------- */
const CLASSES_KEY = 'td_classes_v1';
const DEFAULT_CLASS_ID = 'default';
const MAX_CLASSES = 12;

function loadClasses(){
  let idx = null;
  try{ idx = JSON.parse(localStorage.getItem(CLASSES_KEY)); }catch(e){}
  if(!idx || !Array.isArray(idx.list) || !idx.list.length){
    // First run on this build: the deck that already exists becomes class one.
    idx = { active: DEFAULT_CLASS_ID, list: [{ id: DEFAULT_CLASS_ID, name: '' }] };
  }
  if(!idx.list.some(c=> c.id === idx.active)) idx.active = idx.list[0].id;
  return idx;
}
const classes = loadClasses();
function saveClasses(){
  try{ localStorage.setItem(CLASSES_KEY, JSON.stringify(classes)); }catch(e){ /* not persisted */ }
}
function activeClassId(){ return classes.active; }
function activeClass(){ return classes.list.find(c=> c.id === classes.active) || classes.list[0]; }
function classStateKey(id){ return id === DEFAULT_CLASS_ID ? LS_KEY : `${LS_KEY}::${id}`; }
// Per-class background image id, so each class can have its own photo while
// the ids stay stable. The default class keeps the historical 'background' id.
function bgIdForClass(){
  return activeClassId() === DEFAULT_CLASS_ID ? 'background' : `background::${activeClassId()}`;
}

const state = loadState() || {
  theme: 'dusk',
  dim: true,
  customBg: false,
  logo: false,
  active: {},           // widgetId -> true if open
  layout: {},           // widgetId -> {x,y,w,h}
  roster: ['Alex','Bao','Chen','Dara','Elif','Farid','Grace','Huy'],
  checklist: [
    { id: cid(), text: 'Warm-up: greet a partner in English', done: false },
    { id: cid(), text: 'Vocabulary review', done: false },
    { id: cid(), text: 'Pair reading activity', done: false }
  ],
  scoreboard: [
    { name:'Team One', score:0 },
    { name:'Team Two', score:0 },
    { name:'Team Three', score:0 },
    { name:'Team Four', score:0 }
  ],
  lang: 'en',
  langPair: ['en','vi'],
  dockVisible: {},
  calendarEvents: [],
  notifsEnabled: false,
  calendarSystem: 'gregorian',
  poll: { question:'', options:[{id:cid(),text:'',votes:0},{id:cid(),text:'',votes:0}] },
  musicStream: { type:'', url:'' },
  videoStream: { type:'', url:'' },
  spotifyUrl: '',
  sfxVolume: 0.8,
  license: { key:'', pro:false },
  attendance: {},                     // 'YYYY-MM-DD' -> { studentName: 'present'|'absent'|'late' }
  groupMaker: { mode:'groups', count:4, size:4, lastKey:'' },
  exitTicket: { question:'', tallies:{ got_it:0, almost:0, need_help:0 } },
  agenda: { schedule:'', objective:'', doNow:'' },
  qrHistory: [],
  countdown: { label:'', date:'' },
  hallPass: { current:null, log:[] },   // current: {name, dest, start} | null
  readingLog: { minutes:15, entries:[] },
  ttsText: '',
  announcements: [],                  // { id, text, pinned, createdAt, expiresAt|null }
  instructionsBoard: { title:'', steps:[], current:0 },
  layoutMode: 'comfortable'            // 'compact' | 'comfortable' | 'custom' — see LAYOUT_MODES below
};

// Fill in fields for anyone with a state saved before this field existed
if(!state.scoreboard){
  state.scoreboard = [
    { name:'Team One', score:0 },
    { name:'Team Two', score:0 },
    { name:'Team Three', score:0 },
    { name:'Team Four', score:0 }
  ];
}
if(!state.lang) state.lang = 'en';
if(!state.langPair) state.langPair = ['en','vi'];
if(!state.dockVisible) state.dockVisible = {};
if(!state.calendarEvents) state.calendarEvents = [];
if(!state.notifsEnabled) state.notifsEnabled = false;
if(!state.calendarSystem) state.calendarSystem = 'gregorian';
if(!state.poll) state.poll = { question:'', options:[{id:cid(),text:'',votes:0},{id:cid(),text:'',votes:0}] };
if(!state.musicStream) state.musicStream = { type:'', url:'' };
if(!state.videoStream) state.videoStream = { type:'', url:'' };
if(!state.spotifyUrl) state.spotifyUrl = '';
if(state.sfxVolume === undefined) state.sfxVolume = 0.8;
if(!state.license) state.license = { key:'', pro:false };
if(!state.edgeDock) state.edgeDock = { left:{visible:true}, right:{visible:true}, top:{visible:true} };
if(!state.edgeDock.left) state.edgeDock.left = { visible:true };
if(!state.edgeDock.right) state.edgeDock.right = { visible:true };
if(!state.edgeDock.top) state.edgeDock.top = { visible:true };
if(state.hoverOpen === undefined) state.hoverOpen = false;
if(!state.dockPlacement) state.dockPlacement = {}; // widgetId -> 'bottom' | 'left' | 'right' | 'hidden'
if(!state.attendance) state.attendance = {};
if(!state.groupMaker) state.groupMaker = { mode:'groups', count:4, size:4, lastKey:'' };
if(!state.exitTicket) state.exitTicket = { question:'', tallies:{ got_it:0, almost:0, need_help:0 } };
if(!state.agenda) state.agenda = { schedule:'', objective:'', doNow:'' };
if(!state.qrHistory) state.qrHistory = [];
if(!state.countdown) state.countdown = { label:'', date:'' };
if(!state.hallPass) state.hallPass = { current:null, log:[] };
if(!state.readingLog) state.readingLog = { minutes:15, entries:[] };
if(state.ttsText === undefined) state.ttsText = '';
if(!state.announcements) state.announcements = [];
if(!state.instructionsBoard) state.instructionsBoard = { title:'', steps:[], current:0 };
if(state.activeBgId === undefined) state.activeBgId = null;
// Pre-v0.6.4 saves: a custom background existed only as state.customBg===true
// with a fixed idb id 'background' and nothing else pointing at it.
if(state.customBg === true && !state.activeBgId){
  state.activeBgId = 'background';
}
// v0.6.4 briefly stored a list of saved backgrounds (state.customBgList) —
// that gallery UI was reverted, but keep whichever one was last active
// (or the most recent upload) as the single current background rather than
// losing it, then drop the list.
if(Array.isArray(state.customBgList)){
  if(!state.activeBgId && state.customBgList.length){
    state.activeBgId = state.customBgList[state.customBgList.length - 1];
  }
  delete state.customBgList;
}
// Anyone with state saved before layout modes existed keeps their exact
// current dock/drawer setup untouched — migrate them to 'custom' rather than
// silently snapping them into 'comfortable' (which would force both side
// drawers back on even if they'd deliberately turned one off). Brand-new
// installs get the 'comfortable' default set in the state literal above.
if(!state.layoutMode) state.layoutMode = 'custom';
if(!state.pillPlacement) state.pillPlacement = { classes:'top', lang:'top', theme:'top' }; // pillId -> 'top' | 'hidden'
if(!state.pillPlacement.classes) state.pillPlacement.classes = 'top'; // added with the classes pill
Object.keys(state.pillPlacement).forEach(id=>{
  if(state.pillPlacement[id] !== 'hidden') state.pillPlacement[id] = 'top'; // collapse old topLeft/topRight values
});

const APP_VERSION = '0.6.9';

/* =========================================================
   TeachersDeck Pro — licensing & payment config
   -----------------------------------------------------------------
   This app has no backend and no accounts (state lives only in this
   browser's localStorage/IndexedDB), so "Pro" is unlocked with an
   offline license key rather than a server-checked account. Fill in
   the placeholders below with your real payment details.

   IMPORTANT HONESTY NOTE: because the checksum used to validate a
   key lives in this same client-side file, anyone who opens the
   browser console can read PRO_LICENSE_SALT and mint their own
   working keys. This stops casual free-riding (sharing a code with
   a friend, guessing a key) but will NOT stop a determined person.
   If you need real DRM, keys should instead be issued + verified by
   a small server (e.g. via Stripe webhook -> Keygen.sh/Gumroad
   license API) which this static app would call once at activation
   time. Ask if you'd like that wired in instead.
   ========================================================= */
const PRO_PRICE_USD = 19;              // TODO: set your real one-time price
const PRO_PRICE_VND = 490000;          // TODO: set your real VND price

// --- Payment method 1: HSBC VietQR (bank transfer, shown first) ---
const HSBC_VIETQR_BIN = '458761';      // HSBC Vietnam's NAPAS bank BIN (public info; verify at vietqr.io)
const HSBC_ACCOUNT_NUMBER = '';        // TODO: your HSBC Vietnam account number
const HSBC_ACCOUNT_NAME = '';          // TODO: account holder name, no Vietnamese diacritics (e.g. "NGUYEN VAN A")

// --- Payment method 2: Stripe (card), or swap for another Asian processor ---
// Easiest no-backend option: create a Stripe "Payment Link" (dashboard.stripe.com/payment-links)
// for the Pro price and paste its URL here. Alternatives that also work without a
// backend: PayPal.me link, a Wise payment request link, or a 2Checkout/Xendit/
// PayerMax checkout link — anything that's just a URL can go in STRIPE_PAYMENT_LINK.
const STRIPE_PAYMENT_LINK = '';        // TODO: e.g. 'https://buy.stripe.com/xxxxxxxx'
const CARD_PROCESSOR_LABEL = 'Card (Stripe)'; // change if using a different processor

// Widgets that require Pro. Edit freely — this is the only place the split is defined.
// TESTING MODE: everything is unlocked (empty list) while Wave 1's new widgets are
// being built and tried out. The intended split before this goes live again —
// the original 10 Pro widgets plus the 15 new Wave 1 widgets — is kept here
// commented out so it's a one-line swap to re-lock once testing is done:
// const PRO_WIDGET_IDS = ['traffic','dice','checklist','scoreboard','poll','noise','music','videoplayer','soundboard','games',
//   'attendance','groupmaker','exitticket','agenda','qrcode','countdown','hallpass','readinglog','ttsreader','unitconverter','announcements','instructions','convocards','idiomday','grammarref'];
const PRO_WIDGET_IDS = [];

// TESTING MODE: isPro() forced to true so the license-gated, non-widget Pro
// features (custom background photo, custom school logo, left/right drawer
// customization) can be tried out without a real license key, on top of the
// PRO_WIDGET_IDS testing override above. Swap the two lines below back once
// testing is done, to require a real unlocked license again.
// function isPro(){ return !!(state.license && state.license.pro); }
function isPro(){ return true; }
function isProWidget(id){ return PRO_WIDGET_IDS.includes(id); }

// Offline license key format: TDPRO-AAAA-BBBB-CCCC
// The 4th group is a checksum of the first three, salted, so keys can be
// validated fully client-side without a server. Use generateLicenseKey()
// in the console (or a small script using the same function) to mint keys
// for customers after you confirm their VietQR/Stripe payment.
const PRO_LICENSE_SALT = 'teachersdeck-pro-2026';
function licenseChecksum(parts){
  let h = 0;
  const str = PRO_LICENSE_SALT + parts.join('-');
  for(let i=0;i<str.length;i++){ h = ((h<<5) - h + str.charCodeAt(i)) | 0; }
  return Math.abs(h).toString(36).toUpperCase().padStart(4,'0').slice(0,4);
}
function generateLicenseKey(){
  const rnd = ()=> Math.random().toString(36).toUpperCase().replace(/[^A-Z0-9]/g,'').padEnd(4,'0').slice(0,4);
  const a = rnd(), b = rnd();
  const c = licenseChecksum([a,b]);
  return `TDPRO-${a}-${b}-${c}`;
}
function validateLicenseKey(key){
  if(!key) return false;
  const m = /^TDPRO-([A-Z0-9]{4})-([A-Z0-9]{4})-([A-Z0-9]{4})$/.exec(key.trim().toUpperCase());
  if(!m) return false;
  return licenseChecksum([m[1],m[2]]) === m[3];
}
function activateLicense(rawKey){
  const key = (rawKey||'').trim().toUpperCase();
  if(!validateLicenseKey(key)) return false;
  state.license = { key, pro:true };
  saveState();
  return true;
}

function cid(){ return Math.random().toString(36).slice(2,9); }

function loadState(){
  try{ return JSON.parse(localStorage.getItem(classStateKey(activeClassId()))); }catch(e){ return null; }
}
function saveState(){
  // Storage can be blocked (sandboxed/embedded preview, some private modes).
  // Don't let that throw and abort whatever the caller was about to do next
  // (e.g. applying a theme) — just keep running from memory.
  try{ localStorage.setItem(classStateKey(activeClassId()), JSON.stringify(state)); }catch(e){ /* not persisted */ }
}

/* =========================================================
   Localization
   ========================================================= */
const LANGS = [
  { code:'en', name:'English' },
  { code:'vi', name:'Tiếng Việt' },
  { code:'es', name:'Español' },
  { code:'fr', name:'Français' },
  { code:'zh', name:'中文' },
  { code:'ja', name:'日本語' },
  { code:'ko', name:'한국어' },
  { code:'tl', name:'Tagalog' }
];
const LOCALE_MAP = { en:'en-US', vi:'vi-VN', es:'es-ES', fr:'fr-FR', zh:'zh-CN', ja:'ja-JP', ko:'ko-KR', tl:'fil-PH' };

const STRINGS = {
  clock:        { en:'Clock', vi:'Đồng hồ', es:'Reloj', fr:'Horloge', zh:'时钟', ja:'時計', ko:'시계', tl:'Orasan' },
  timer:        { en:'Timer', vi:'Hẹn giờ', es:'Temporizador', fr:'Minuteur', zh:'计时器', ja:'タイマー', ko:'타이머', tl:'Timer' },
  stopwatch:    { en:'Stopwatch', vi:'Bấm giờ', es:'Cronómetro', fr:'Chronomètre', zh:'秒表', ja:'ストップウォッチ', ko:'스톱워치', tl:'Stopwatch' },
  traffic:      { en:'Traffic Light', vi:'Đèn giao thông', es:'Semáforo', fr:'Feu tricolore', zh:'交通灯', ja:'信号機', ko:'신호등', tl:'Ilaw-trapiko' },
  dice:         { en:'Dice', vi:'Xúc xắc', es:'Dados', fr:'Dés', zh:'骰子', ja:'サイコロ', ko:'주사위', tl:'Dice' },
  checklist:    { en:'Checklist', vi:'Danh sách việc', es:'Lista de tareas', fr:'Liste de tâches', zh:'清单', ja:'チェックリスト', ko:'체크리스트', tl:'Tsekliste' },
  namepicker:   { en:'Name Picker', vi:'Chọn tên học sinh', es:'Selector de nombres', fr:'Sélecteur de noms', zh:'随机点名', ja:'名前選び', ko:'이름 뽑기', tl:'Pumili ng Pangalan' },
  files:        { en:'Files', vi:'Tệp tin', es:'Archivos', fr:'Fichiers', zh:'文件', ja:'ファイル', ko:'파일', tl:'Mga File' },
  games:        { en:'Games', vi:'Trò chơi', es:'Juegos', fr:'Jeux', zh:'游戏', ja:'ゲーム', ko:'게임', tl:'Mga Laro' },
  scoreboard:   { en:'Scoreboard', vi:'Bảng điểm', es:'Marcador', fr:'Tableau des scores', zh:'计分板', ja:'スコアボード', ko:'점수판', tl:'Scoreboard' },
  settings:     { en:'Settings', vi:'Cài đặt', es:'Configuración', fr:'Paramètres', zh:'设置', ja:'設定', ko:'설정', tl:'Mga Setting' },

  theme_title:  { en:'Theme', vi:'Giao diện', es:'Tema', fr:'Thème', zh:'主题', ja:'テーマ', ko:'테마', tl:'Tema' },
  backgrounds:  { en:'Backgrounds', vi:'Hình nền', es:'Fondos', fr:'Arrière-plans', zh:'背景', ja:'背景', ko:'배경', tl:'Mga Background' },
  your_image:   { en:'Your image or logo', vi:'Hình ảnh hoặc logo của bạn', es:'Tu imagen o logo', fr:'Votre image ou logo', zh:'您的图片或标志', ja:'画像またはロゴ', ko:'이미지 또는 로고', tl:'Larawan o logo mo' },
  upload_bg:    { en:'Upload a background image', vi:'Tải lên hình nền', es:'Subir una imagen de fondo', fr:"Importer une image de fond", zh:'上传背景图片', ja:'背景画像をアップロード', ko:'배경 이미지 업로드', tl:'Mag-upload ng background na larawan' },
  upload_logo:  { en:'Upload a school / company logo', vi:'Tải lên logo trường / công ty', es:'Subir el logo de la escuela / empresa', fr:"Importer le logo de l'école / l'entreprise", zh:'上传学校/公司标志', ja:'学校・会社のロゴをアップロード', ko:'학교/회사 로고 업로드', tl:'Mag-upload ng logo ng paaralan / kumpanya' },
  remove_logo:  { en:'Remove logo', vi:'Xóa logo', es:'Quitar logo', fr:'Retirer le logo', zh:'移除标志', ja:'ロゴを削除', ko:'로고 제거', tl:'Alisin ang logo' },
  dim_bg:       { en:'Dim background (better contrast)', vi:'Làm tối nền (tăng độ tương phản)', es:'Oscurecer el fondo (mejor contraste)', fr:"Assombrir l'arrière-plan (meilleur contraste)", zh:'使背景变暗（提高对比度）', ja:'背景を暗くする（コントラスト向上）', ko:'배경 어둡게 하기 (대비 향상)', tl:'Padilimin ang background (mas magandang contrast)' },

  settings_title:  { en:'Settings', vi:'Cài đặt', es:'Configuración', fr:'Paramètres', zh:'设置', ja:'設定', ko:'설정', tl:'Mga Setting' },
  language_section:{ en:'Language', vi:'Ngôn ngữ', es:'Idioma', fr:'Langue', zh:'语言', ja:'言語', ko:'언어', tl:'Wika' },
  dock_buttons: { en:'Dock buttons', vi:'Nút trên thanh dock', es:'Botones del dock', fr:'Boutons du dock', zh:'底部工具栏按钮', ja:'ドックのボタン', ko:'독 버튼', tl:'Mga Button sa Dock' },
  dock_buttons_hint: { en:'Choose where each widget\u2019s launcher lives — bottom dock, a side drawer, or hidden', vi:'Chọn nơi hiển thị nút mở từng widget — thanh dock dưới, ngăn hai bên, hoặc ẩn' },
  placement_bottom: { en:'Bottom dock', vi:'Thanh dock dưới' },
  placement_left:   { en:'Left drawer', vi:'Ngăn bên trái' },
  placement_right:  { en:'Right drawer', vi:'Ngăn bên phải' },
  placement_top:    { en:'Top dock (5 max)', vi:'Thanh dock trên cùng (tối đa 5)' },
  placement_hidden: { en:'Hidden', vi:'Ẩn' },
  layout_mode_section: { en:'Layout mode', vi:'Chế độ bố cục' },
  layout_mode_hint: { en:'Choose how docks and the widget tray are arranged', vi:'Chọn cách sắp xếp các thanh dock và khay widget' },
  layout_mode_compact: { en:'Compact', vi:'Gọn' },
  layout_mode_compact_desc: { en:'Just the bottom dock — tap the arrow above it for an app tray with every widget', vi:'Chỉ có thanh dock dưới — chạm mũi tên phía trên để mở khay ứng dụng chứa mọi widget' },
  layout_mode_comfortable: { en:'Comfortable', vi:'Thoải mái' },
  layout_mode_comfortable_desc: { en:'Bottom, left and right docks all shown', vi:'Hiện đầy đủ thanh dock dưới, trái và phải' },
  layout_mode_custom: { en:'Custom', vi:'Tùy chỉnh' },
  layout_mode_custom_desc: { en:'Pick each widget\u2019s dock and toggle drawers yourself', vi:'Tự chọn thanh dock cho từng widget và tự bật/tắt ngăn kéo' },
  layout_lock_hint: { en:'Set by the layout mode above — switch to Custom to control this yourself', vi:'Do chế độ bố cục ở trên quyết định — chuyển sang Tùy chỉnh để tự điều chỉnh' },
  app_tray_open: { en:'Open app tray', vi:'Mở khay ứng dụng' },
  app_tray_close: { en:'Close app tray', vi:'Đóng khay ứng dụng' },
  app_tray_title: { en:'All widgets', vi:'Tất cả widget' },
  drawers_section:  { en:'Side & top drawers', vi:'Ngăn hai bên & trên cùng' },
  drawer_left_visible_label:  { en:'Show left drawer', vi:'Hiện ngăn bên trái' },
  drawer_right_visible_label: { en:'Show right drawer', vi:'Hiện ngăn bên phải' },
  drawer_top_visible_label:   { en:'Show top drawer', vi:'Hiện ngăn trên cùng' },
  drawer_hover_label: { en:'Open drawers on hover', vi:'Mở ngăn khi rê chuột tới mép màn hình' },
  drawer_hover_hint:  { en:'On: drawers tuck away to a thin edge strip and pop open when your mouse reaches that edge (bottom, top, left and right). Off: any drawer you\u2019ve made visible above just stays fully open.', vi:'Bật: các ngăn thu lại thành một dải mỏng ở mép màn hình và tự mở ra khi chuột chạm mép đó (trên, dưới, trái, phải). Tắt: ngăn nào đang hiện ở trên sẽ luôn mở rộng sẵn.' },
  drawer_full_toast: { en:'{side} is full ({max} max)', vi:'{side} đã đầy (tối đa {max})' },
  pills_section:      { en:'Top bar pills', vi:'Nút nhanh trên cùng' },
  pills_section_hint: { en:'Where the language switch and theme button appear when the top drawer is on', vi:'Nơi hiển thị nút chuyển ngôn ngữ và nút giao diện khi ngăn trên cùng đang mở' },
  pill_lang_label:  { en:'Language switch', vi:'Nút chuyển ngôn ngữ' },
  pill_theme_label: { en:'Theme button', vi:'Nút giao diện' },
  placement_shown: { en:'Shown', vi:'Hiện' },
  version_label: { en:'Version', vi:'Phiên bản' },
  quick_lang_1: { en:'Quick language 1', vi:'Ngôn ngữ nhanh 1', es:'Idioma rápido 1', fr:'Langue rapide 1', zh:'快捷语言 1', ja:'クイック言語 1', ko:'빠른 언어 1', tl:'Mabilis na wika 1' },
  quick_lang_2: { en:'Quick language 2', vi:'Ngôn ngữ nhanh 2', es:'Idioma rápido 2', fr:'Langue rapide 2', zh:'快捷语言 2', ja:'クイック言語 2', ko:'빠른 언어 2', tl:'Mabilis na wika 2' },
  roster_label: { en:'Class list (used by Name Picker)', vi:'Danh sách lớp (dùng cho Chọn tên học sinh)', es:'Lista de la clase (usada por el selector de nombres)', fr:'Liste de classe (utilisée par le sélecteur de noms)', zh:'班级名单（用于随机点名）', ja:'クラス名簿（名前選びで使用）', ko:'학급 명단 (이름 뽑기에 사용)', tl:'Listahan ng klase (ginagamit ng Pumili ng Pangalan)' },
  roster_placeholder:{ en:'One student name per line', vi:'Mỗi dòng một tên học sinh', es:'Un nombre de estudiante por línea', fr:"Un nom d'élève par ligne", zh:'每行一个学生姓名', ja:'1行に生徒の名前を1つ', ko:'한 줄에 학생 이름 하나씩', tl:'Isang pangalan ng estudyante bawat linya' },
  save_roster:  { en:'Save class list', vi:'Lưu danh sách lớp', es:'Guardar lista de la clase', fr:'Enregistrer la liste de classe', zh:'保存班级名单', ja:'クラス名簿を保存', ko:'학급 명단 저장', tl:'I-save ang listahan ng klase' },
  layout_label: { en:'Layout', vi:'Bố cục', es:'Diseño', fr:'Disposition', zh:'布局', ja:'レイアウト', ko:'레이아웃', tl:'Layout' },
  reset_layout: { en:'Reset widget positions', vi:'Đặt lại vị trí widget', es:'Restablecer posición de los widgets', fr:'Réinitialiser la position des widgets', zh:'重置小组件位置', ja:'ウィジェットの位置をリセット', ko:'위젯 위치 재설정', tl:'I-reset ang posisyon ng mga widget' },
  reset_all:    { en:'Reset everything', vi:'Đặt lại tất cả', es:'Restablecer todo', fr:'Tout réinitialiser', zh:'重置全部', ja:'すべてリセット', ko:'전체 재설정', tl:'I-reset lahat' },
  reset_all_confirm:{ en:'This clears widgets, theme, files and the class list on this device. Continue?', vi:'Thao tác này sẽ xóa widget, giao diện, tệp tin và danh sách lớp trên thiết bị này. Tiếp tục?', es:'Esto borrará los widgets, el tema, los archivos y la lista de la clase en este dispositivo. ¿Continuar?', fr:'Cela effacera les widgets, le thème, les fichiers et la liste de classe sur cet appareil. Continuer ?', zh:'此操作将清除本设备上的小组件、主题、文件和班级名单。是否继续？', ja:'この操作でウィジェット、テーマ、ファイル、クラス名簿がこの端末から削除されます。続行しますか？', ko:'이 기기의 위젯, 테마, 파일, 학급 명단이 모두 삭제됩니다. 계속할까요?', tl:'Buburahin nito ang mga widget, tema, file, at listahan ng klase sa device na ito. Magpatuloy?' },

  file_added:   { en:'File added — stored in this browser only', vi:'Đã thêm tệp — chỉ lưu trên trình duyệt này', es:'Archivo añadido — guardado solo en este navegador', fr:'Fichier ajouté — enregistré uniquement dans ce navigateur', zh:'已添加文件 — 仅保存在此浏览器中', ja:'ファイルを追加しました — このブラウザにのみ保存されます', ko:'파일이 추가되었습니다 — 이 브라우저에만 저장됨', tl:'Naidagdag ang file — naka-save lang sa browser na ito' },
  game_saved:   { en:'Game saved — quick-start it anytime from this widget', vi:'Đã lưu trò chơi — khởi chạy nhanh bất cứ lúc nào từ widget này', es:'Juego guardado — inícialo rápidamente desde este widget cuando quieras', fr:'Jeu enregistré — lancez-le rapidement depuis ce widget quand vous voulez', zh:'已保存游戏 — 随时可在此小组件中快速启动', ja:'ゲームを保存しました — このウィジェットからいつでもすぐに起動できます', ko:'게임이 저장되었습니다 — 이 위젯에서 언제든 빠르게 실행하세요', tl:'Na-save ang laro — pwede itong i-launch agad mula sa widget na ito' },
  class_list_saved:{ en:'Class list saved', vi:'Đã lưu danh sách lớp', es:'Lista de la clase guardada', fr:'Liste de classe enregistrée', zh:'已保存班级名单', ja:'クラス名簿を保存しました', ko:'학급 명단이 저장되었습니다', tl:'Na-save ang listahan ng klase' },
  layout_reset_toast:{ en:'Layout reset', vi:'Đã đặt lại bố cục', es:'Diseño restablecido', fr:'Disposition réinitialisée', zh:'布局已重置', ja:'レイアウトをリセットしました', ko:'레이아웃이 재설정되었습니다', tl:'Na-reset ang layout' },
  classes_section:{ en:'Classes', vi:'Lớp học', es:'Clases', fr:'Classes', zh:'班级', ja:'クラス', ko:'수업', tl:'Mga Klase' },
  classes_hint: { en:'Each class keeps its own roster, widgets, layout and theme. Switching opens that class.', vi:'Mỗi lớp có danh sách, tiện ích, bố cục và giao diện riêng. Chuyển lớp sẽ mở lớp đó.', es:'Cada clase guarda su propia lista, widgets, diseño y tema. Cambiar abre esa clase.', fr:'Chaque classe garde sa liste, ses widgets, sa disposition et son thème. Changer ouvre cette classe.', zh:'每个班级保留自己的名单、小组件、布局和主题。切换即可打开该班级。', ja:'各クラスは名簿・ウィジェット・レイアウト・テーマを個別に保持します。切り替えるとそのクラスが開きます。', ko:'각 수업은 명단, 위젯, 레이아웃, 테마를 따로 유지합니다. 전환하면 해당 수업이 열립니다.', tl:'May sariling roster, widget, layout at tema ang bawat klase. Ang paglipat ay magbubukas ng klaseng iyon.' },
  class_default_name: { en:'My class', vi:'Lớp của tôi', es:'Mi clase', fr:'Ma classe', zh:'我的班级', ja:'マイクラス', ko:'내 수업', tl:'Aking klase' },
  class_switch_label: { en:'Switch class', vi:'Chuyển lớp', es:'Cambiar de clase', fr:'Changer de classe', zh:'切换班级', ja:'クラスを切り替え', ko:'수업 전환', tl:'Magpalit ng klase' },
  class_manage:  { en:'Manage classes…', vi:'Quản lý lớp…', es:'Gestionar clases…', fr:'Gérer les classes…', zh:'管理班级…', ja:'クラスを管理…', ko:'수업 관리…', tl:'Pamahalaan ang mga klase…' },
  class_name_ph: { en:'Class name (e.g. 7A Monday)', vi:'Tên lớp (vd: 7A thứ Hai)', es:'Nombre de la clase (p. ej. 7A lunes)', fr:'Nom de la classe (ex. 7A lundi)', zh:'班级名称（例如 7A 周一）', ja:'クラス名（例：7A 月曜）', ko:'수업 이름 (예: 7A 월요일)', tl:'Pangalan ng klase (hal. 7A Lunes)' },
  class_add:     { en:'Add a class', vi:'Thêm lớp', es:'Añadir una clase', fr:'Ajouter une classe', zh:'添加班级', ja:'クラスを追加', ko:'수업 추가', tl:'Magdagdag ng klase' },
  class_add_btn: { en:'Create & open', vi:'Tạo và mở', es:'Crear y abrir', fr:'Créer et ouvrir', zh:'创建并打开', ja:'作成して開く', ko:'만들고 열기', tl:'Gumawa at buksan' },
  class_copy:    { en:'Copy this class', vi:'Sao chép lớp này', es:'Copiar esta clase', fr:'Copier cette classe', zh:'复制此班级', ja:'このクラスを複製', ko:'이 수업 복제', tl:'Kopyahin ang klaseng ito' },
  class_copy_hint:{ en:'Makes a new class with the same widgets, layout and theme — handy for a second section.', vi:'Tạo lớp mới với cùng tiện ích, bố cục và giao diện — tiện cho lớp thứ hai.', es:'Crea una clase nueva con los mismos widgets, diseño y tema — útil para otra sección.', fr:'Crée une classe avec les mêmes widgets, disposition et thème — pratique pour une autre section.', zh:'创建具有相同小组件、布局和主题的新班级 — 适合另一个班。', ja:'同じウィジェット・レイアウト・テーマの新しいクラスを作成します（別クラスに便利）。', ko:'같은 위젯, 레이아웃, 테마로 새 수업을 만듭니다 — 다른 반에 유용합니다.', tl:'Gumagawa ng bagong klase na may parehong widget, layout at tema — praktikal para sa ibang seksyon.' },
  class_copy_suffix:{ en:'copy', vi:'bản sao', es:'copia', fr:'copie', zh:'副本', ja:'コピー', ko:'복사본', tl:'kopya' },
  class_switch_to:{ en:'Open', vi:'Mở', es:'Abrir', fr:'Ouvrir', zh:'打开', ja:'開く', ko:'열기', tl:'Buksan' },
  class_current: { en:'Open now', vi:'Đang mở', es:'Abierta ahora', fr:'Ouverte', zh:'当前打开', ja:'表示中', ko:'현재 열림', tl:'Bukas ngayon' },
  class_delete:  { en:'Delete class', vi:'Xóa lớp', es:'Eliminar clase', fr:'Supprimer la classe', zh:'删除班级', ja:'クラスを削除', ko:'수업 삭제', tl:'Burahin ang klase' },
  class_delete_confirm: { en:'Delete "{name}"? Its roster, layout and settings are erased. Your files, games and music library are shared and stay.', vi:'Xóa "{name}"? Danh sách, bố cục và cài đặt của lớp sẽ bị xóa. Thư viện tệp, trò chơi và nhạc dùng chung vẫn được giữ.', es:'¿Eliminar "{name}"? Se borran su lista, diseño y ajustes. Tu biblioteca de archivos, juegos y música es compartida y se conserva.', fr:'Supprimer « {name} » ? Sa liste, sa disposition et ses réglages seront effacés. Votre bibliothèque de fichiers, jeux et musique est partagée et sera conservée.', zh:'删除"{name}"？其名单、布局和设置将被清除。文件、游戏和音乐库为共享内容，会保留。', ja:'「{name}」を削除しますか？名簿・レイアウト・設定は消去されます。ファイル・ゲーム・音楽のライブラリは共有のため残ります。', ko:'"{name}"을(를) 삭제할까요? 명단, 레이아웃, 설정이 지워집니다. 파일·게임·음악 라이브러리는 공유되어 유지됩니다.', tl:'Burahin ang "{name}"? Mabubura ang roster, layout at settings nito. Nananatili ang shared na library ng files, games at musika.' },
  class_deleted: { en:'Class deleted', vi:'Đã xóa lớp', es:'Clase eliminada', fr:'Classe supprimée', zh:'班级已删除', ja:'クラスを削除しました', ko:'수업이 삭제되었습니다', tl:'Nabura ang klase' },
  class_last:    { en:"That's your only class — it can't be deleted", vi:'Đây là lớp duy nhất — không thể xóa', es:'Es tu única clase — no se puede eliminar', fr:"C'est votre seule classe — impossible de la supprimer", zh:'这是您唯一的班级 — 无法删除', ja:'唯一のクラスのため削除できません', ko:'유일한 수업이라 삭제할 수 없습니다', tl:'Ito lang ang klase mo — hindi ito mabubura' },
  class_max:     { en:'You can have up to {max} classes', vi:'Bạn có thể có tối đa {max} lớp', es:'Puedes tener hasta {max} clases', fr:"Vous pouvez avoir jusqu'à {max} classes", zh:'最多可创建 {max} 个班级', ja:'クラスは最大 {max} 個までです', ko:'최대 {max}개의 수업을 만들 수 있습니다', tl:'Hanggang {max} klase lang ang pwede' },
  pill_classes_label: { en:'Class switcher', vi:'Bộ chuyển lớp', es:'Selector de clase', fr:'Sélecteur de classe', zh:'班级切换器', ja:'クラス切り替え', ko:'수업 전환기', tl:'Panlipat ng klase' },
  bg_updated:   { en:'Background updated', vi:'Đã cập nhật hình nền', es:'Fondo actualizado', fr:'Arrière-plan mis à jour', zh:'背景已更新', ja:'背景を更新しました', ko:'배경이 업데이트되었습니다', tl:'Na-update ang background' },
  bg_upload_failed: { en:"Couldn't save that image — this window may block storage (embedded preview or private mode). Try a regular browser tab.", vi:'Không thể lưu ảnh — cửa sổ này có thể chặn bộ nhớ (chế độ xem nhúng hoặc riêng tư). Hãy thử trong một tab trình duyệt thông thường.', es:'No se pudo guardar la imagen — esta ventana puede bloquear el almacenamiento (vista previa incrustada o modo privado). Prueba en una pestaña normal del navegador.', fr:"Impossible d'enregistrer cette image — cette fenêtre bloque peut-être le stockage (aperçu intégré ou navigation privée). Essayez dans un onglet de navigateur normal.", zh:'无法保存该图片 — 此窗口可能禁用了存储（嵌入式预览或隐私模式）。请在普通浏览器标签页中重试。', ja:'画像を保存できませんでした — このウィンドウでは保存が制限されている可能性があります（埋め込みプレビューやプライベートモード）。通常のブラウザタブでお試しください。', ko:'이미지를 저장하지 못했습니다 — 이 창에서 저장소가 차단되었을 수 있습니다(임베디드 미리보기 또는 비공개 모드). 일반 브라우저 탭에서 시도해 보세요.', tl:'Hindi na-save ang larawan — maaaring naka-block ang storage sa window na ito (embedded preview o private mode). Subukan sa regular na browser tab.' },
  bg_not_saved: { en:"Background applied — but this window can't save it, so it will reset on reload. Open the app in a regular browser tab to keep it.", vi:'Đã áp dụng hình nền — nhưng cửa sổ này không thể lưu nên sẽ đặt lại khi tải lại. Hãy mở ứng dụng trong tab trình duyệt thông thường để giữ lại.', es:'Fondo aplicado — pero esta ventana no puede guardarlo, así que se restablecerá al recargar. Abre la app en una pestaña normal del navegador para conservarlo.', fr:"Arrière-plan appliqué — mais cette fenêtre ne peut pas l'enregistrer, il sera réinitialisé au rechargement. Ouvrez l'app dans un onglet de navigateur normal pour le conserver.", zh:'背景已应用 — 但此窗口无法保存，刷新后将恢复。请在普通浏览器标签页中打开应用以保留。', ja:'背景を適用しました — ただしこのウィンドウでは保存できないため、再読み込みするとリセットされます。保持するには通常のブラウザタブでアプリを開いてください。', ko:'배경이 적용되었습니다 — 하지만 이 창에서는 저장할 수 없어 새로고침하면 초기화됩니다. 유지하려면 일반 브라우저 탭에서 앱을 여세요.', tl:'Na-apply ang background — pero hindi ito ma-save ng window na ito, kaya magre-reset ito kapag nag-reload. Buksan ang app sa regular na browser tab para mapanatili.' },
  logo_updated: { en:'Logo added', vi:'Đã thêm logo', es:'Logo añadido', fr:'Logo ajouté', zh:'已添加标志', ja:'ロゴを追加しました', ko:'로고가 추가되었습니다', tl:'Naidagdag ang logo' },
  logo_removed: { en:'Logo removed', vi:'Đã xóa logo', es:'Logo eliminado', fr:'Logo retiré', zh:'已移除标志', ja:'ロゴを削除しました', ko:'로고가 제거되었습니다', tl:'Naalis ang logo' },
  time_up:      { en:'Time!', vi:'Hết giờ!', es:'¡Se acabó el tiempo!', fr:'Temps écoulé !', zh:'时间到！', ja:'時間切れ！', ko:'시간 종료!', tl:'Oras na!' },
  timer_add_time:{ en:'Add some time before starting', vi:'Thêm thời gian trước khi bắt đầu', es:'Agrega tiempo antes de empezar', fr:'Ajoutez du temps avant de démarrer', zh:'开始前请先添加时间', ja:'開始する前に時間を追加してください', ko:'시작하기 전에 시간을 추가하세요', tl:'Magdagdag muna ng oras bago simulan' },
  lap:          { en:'Lap', vi:'Vòng', es:'Vuelta', fr:'Tour', zh:'圈', ja:'ラップ', ko:'랩', tl:'Lap' },

  start:        { en:'Start', vi:'Bắt đầu', es:'Iniciar', fr:'Démarrer', zh:'开始', ja:'開始', ko:'시작', tl:'Simulan' },
  pause:        { en:'Pause', vi:'Tạm dừng', es:'Pausar', fr:'Pause', zh:'暂停', ja:'一時停止', ko:'일시정지', tl:'I-pause' },
  stop:         { en:'Stop', vi:'Dừng', es:'Detener', fr:'Arrêter', zh:'停止', ja:'停止', ko:'정지', tl:'Ihinto' },
  reset_btn:    { en:'Reset', vi:'Đặt lại', es:'Restablecer', fr:'Réinitialiser', zh:'重置', ja:'リセット', ko:'재설정', tl:'I-reset' },
  browse_btn:   { en:'Browse', vi:'Duyệt tệp', es:'Explorar', fr:'Parcourir', zh:'浏览', ja:'参照', ko:'찾아보기', tl:'Mag-browse' },
  traffic_hint: { en:'Tap a light to signal noise level', vi:'Chạm vào đèn để báo hiệu mức độ ồn', es:'Toca una luz para indicar el nivel de ruido', fr:'Touchez un feu pour indiquer le niveau de bruit', zh:'点击信号灯以表示噪音等级', ja:'ライトをタップして騒音レベルを知らせましょう', ko:'신호등을 탭하여 소음 수준을 표시하세요', tl:'Pindutin ang isang ilaw para sa antas ng ingay' },
  roll:         { en:'Roll', vi:'Tung', es:'Lanzar', fr:'Lancer', zh:'掷骰子', ja:'振る', ko:'굴리기', tl:'Ihagis' },
  add_placeholder:{ en:'Add an item…', vi:'Thêm một mục…', es:'Añadir un elemento…', fr:'Ajouter un élément…', zh:'添加一项…', ja:'項目を追加…', ko:'항목 추가…', tl:'Magdagdag ng item…' },
  add_btn:      { en:'Add', vi:'Thêm', es:'Añadir', fr:'Ajouter', zh:'添加', ja:'追加', ko:'추가', tl:'Idagdag' },
  tap_pick:     { en:'Tap Pick', vi:'Chạm để chọn', es:'Toca para elegir', fr:'Touchez pour choisir', zh:'点击抽取', ja:'タップして選ぶ', ko:'탭하여 선택', tl:'Pindutin para pumili' },
  pick_student: { en:'Pick a student', vi:'Chọn học sinh', es:'Elegir estudiante', fr:'Choisir un élève', zh:'抽取学生', ja:'生徒を選ぶ', ko:'학생 선택', tl:'Pumili ng estudyante' },
  roster_count: { en:'{n} students in class list — edit in Settings', vi:'{n} học sinh trong danh sách lớp — chỉnh sửa trong Cài đặt', es:'{n} estudiantes en la lista de la clase — edítala en Configuración', fr:'{n} élèves dans la liste de classe — modifiez-la dans Paramètres', zh:'班级名单中有 {n} 名学生 — 请在设置中编辑', ja:'クラス名簿に{n}人の生徒がいます — 設定で編集できます', ko:'학급 명단에 {n}명의 학생이 있습니다 — 설정에서 편집하세요', tl:'{n} estudyante sa listahan ng klase — i-edit sa Mga Setting' },
  add_students_prompt:{ en:'Add students in Settings', vi:'Thêm học sinh trong Cài đặt', es:'Añade estudiantes en Configuración', fr:'Ajoutez des élèves dans Paramètres', zh:'请在设置中添加学生', ja:'設定で生徒を追加してください', ko:'설정에서 학생을 추가하세요', tl:'Magdagdag ng estudyante sa Mga Setting' },
  files_drop:   { en:'Click to add a PDF, PowerPoint, Word or Excel file', vi:'Nhấn để thêm tệp PDF, PowerPoint, Word hoặc Excel', es:'Toca para añadir un PDF, PowerPoint, Word o Excel', fr:'Touchez pour ajouter un PDF, PowerPoint, Word ou Excel', zh:'点击添加 PDF、PowerPoint、Word 或 Excel 文件', ja:'タップしてPDF、PowerPoint、Word、Excelファイルを追加', ko:'탭하여 PDF, PowerPoint, Word, Excel 파일 추가', tl:'Pindutin para magdagdag ng PDF, PowerPoint, Word, o Excel file' },
  files_empty:  { en:'No files added yet', vi:'Chưa có tệp nào được thêm', es:'Aún no se han añadido archivos', fr:'Aucun fichier ajouté pour le moment', zh:'尚未添加文件', ja:'まだファイルがありません', ko:'아직 추가된 파일이 없습니다', tl:'Wala pang naidaragdag na file' },
  games_drop:   { en:'Click to add an HTML game (single .html file)', vi:'Nhấn để thêm trò chơi HTML (một tệp .html)', es:'Toca para añadir un juego HTML (un solo archivo .html)', fr:'Touchez pour ajouter un jeu HTML (un seul fichier .html)', zh:'点击添加 HTML 游戏（单个 .html 文件）', ja:'タップしてHTMLゲームを追加（.htmlファイル1つ）', ko:'탭하여 HTML 게임 추가 (.html 파일 1개)', tl:'Pindutin para magdagdag ng HTML na laro (iisang .html file)' },
  games_note:   { en:'Java or Python games need converting to HTML/JS to run here — ask if you want help with that.', vi:'Trò chơi viết bằng Java hoặc Python cần được chuyển sang HTML/JS để chạy ở đây — hãy hỏi nếu bạn cần trợ giúp.', es:'Los juegos en Java o Python deben convertirse a HTML/JS para funcionar aquí — pregunta si necesitas ayuda con eso.', fr:"Les jeux en Java ou Python doivent être convertis en HTML/JS pour fonctionner ici — demandez de l'aide si besoin.", zh:'Java 或 Python 游戏需要转换为 HTML/JS 才能在此运行 — 如需帮助请告诉我们。', ja:'JavaやPythonのゲームはここで動かすためにHTML/JSへ変換する必要があります — お手伝いが必要なら聞いてください。', ko:'Java나 Python 게임은 여기서 실행하려면 HTML/JS로 변환해야 합니다 — 도움이 필요하면 말씀해 주세요.', tl:'Ang mga larong Java o Python ay kailangang i-convert sa HTML/JS para tumakbo dito — magtanong lang kung kailangan mo ng tulong.' },
  games_empty:  { en:'No games added yet', vi:'Chưa có trò chơi nào được thêm', es:'Aún no se han añadido juegos', fr:'Aucun jeu ajouté pour le moment', zh:'尚未添加游戏', ja:'まだゲームがありません', ko:'아직 추가된 게임이 없습니다', tl:'Wala pang naidaragdag na laro' },
  games_mine:   { en:'My games', vi:'Trò chơi của tôi', es:'Mis juegos', fr:'Mes jeux', zh:'我的游戏', ja:'マイゲーム', ko:'내 게임', tl:'Mga laro ko' },
  games_builtin:{ en:'Built-in games', vi:'Trò chơi có sẵn', es:'Juegos incluidos', fr:'Jeux inclus', zh:'内置游戏', ja:'内蔵ゲーム', ko:'내장 게임', tl:'Kasamang mga laro' },
  how_to_play:  { en:'How to play', vi:'Cách chơi', es:'Cómo jugar', fr:'Comment jouer', zh:'玩法说明', ja:'遊び方', ko:'게임 방법', tl:'Paano laruin' },
  sb_sub:       { en:"Tap a team's points to keep score", vi:'Chạm vào điểm của đội để ghi điểm', es:'Toca los puntos de un equipo para llevar el marcador', fr:"Touchez les points d'une équipe pour marquer", zh:'点击某队的分数即可计分', ja:'チームの得点をタップしてスコアを記録', ko:'팀의 점수를 탭하여 기록하세요', tl:'Pindutin ang puntos ng koponan para mag-score' },
  sb_reset:     { en:'Reset all scores', vi:'Đặt lại tất cả điểm số', es:'Restablecer todos los puntos', fr:'Réinitialiser tous les scores', zh:'重置所有分数', ja:'すべてのスコアをリセット', ko:'모든 점수 재설정', tl:'I-reset lahat ng puntos' },
  sb_transfer_received: { en:'Scores received in Scoreboard', vi:'Đã nhận điểm vào Bảng điểm', es:'Puntuaciones recibidas en el Marcador', fr:'Scores reçus dans le Tableau des scores', zh:'已在计分板中收到分数', ja:'スコアボードにスコアを受信しました', ko:'스코어보드에 점수를 받았습니다', tl:'Natanggap ang mga puntos sa Scoreboard' },
  games_unreachable_toast: { en:"Couldn't open this game — built-in games only work when TeachersDeck is served as real files (a local web server or the Chrome extension), not this single-page preview.", vi:'Không thể mở trò chơi này — trò chơi có sẵn chỉ hoạt động khi TeachersDeck được chạy dưới dạng tệp thật (máy chủ web cục bộ hoặc tiện ích Chrome), không phải bản xem trước một trang này.', es:'No se pudo abrir este juego — los juegos incluidos solo funcionan cuando TeachersDeck se sirve como archivos reales (un servidor web local o la extensión de Chrome), no esta vista previa de una sola página.', fr:"Impossible d'ouvrir ce jeu — les jeux intégrés ne fonctionnent que lorsque TeachersDeck est servi en tant que vrais fichiers (un serveur web local ou l'extension Chrome), pas cet aperçu monopage.", zh:'无法打开此游戏——内置游戏仅在 TeachersDeck 以真实文件形式提供时（本地网页服务器或 Chrome 扩展程序）才能运行，此单页预览无法运行。', ja:'このゲームを開けませんでした — 内蔵ゲームはTeachersDeckが実際のファイルとして配信されている場合（ローカルWebサーバーまたはChrome拡張機能）にのみ動作します。この単一ページのプレビューでは動作しません。', ko:'이 게임을 열 수 없습니다 — 내장 게임은 TeachersDeck이 실제 파일로 제공될 때(로컬 웹 서버 또는 Chrome 확장 프로그램)만 작동하며 이 단일 페이지 미리보기에서는 작동하지 않습니다.', tl:'Hindi mabuksan ang larong ito — ang mga kasamang laro ay gumagana lang kapag ang TeachersDeck ay ini-serve bilang tunay na mga file (isang lokal na web server o ang Chrome extension), hindi itong single-page na preview.' },
  close:        { en:'Close', vi:'Đóng', es:'Cerrar', fr:'Fermer', zh:'关闭', ja:'閉じる', ko:'닫기', tl:'Isara' },
  play:         { en:'Play', vi:'Chơi', es:'Reproducir', fr:'Lire', zh:'播放', ja:'再生', ko:'재생', tl:'I-play' },
  remove:       { en:'Remove', vi:'Xóa', es:'Eliminar', fr:'Retirer', zh:'移除', ja:'削除', ko:'제거', tl:'Alisin' },
  open_action:  { en:'Open', vi:'Mở', es:'Abrir', fr:'Ouvrir', zh:'打开', ja:'開く', ko:'열기', tl:'Buksan' },
  move_action:  { en:'Move', vi:'Di chuyển', es:'Mover', fr:'Déplacer', zh:'移动', ja:'移動', ko:'이동', tl:'Ilipat' },
  minimize_action:{ en:'Minimize', vi:'Thu nhỏ', es:'Minimizar', fr:'Réduire', zh:'最小化', ja:'最小化', ko:'최소화', tl:'I-minimize' },
  restore_action:{ en:'Restore', vi:'Khôi phục', es:'Restaurar', fr:'Restaurer', zh:'还原', ja:'元に戻す', ko:'복원', tl:'I-restore' },

  calendar_system_label:{ en:'Date system', vi:'Hệ lịch', es:'Sistema de fechas', fr:'Système de dates', zh:'历法', ja:'暦の種類', ko:'날짜 체계', tl:'Sistema ng Petsa' },
  cal_sys_gregorian:{ en:'Gregorian', vi:'Dương lịch', es:'Gregoriano', fr:'Grégorien', zh:'公历', ja:'新暦（グレゴリオ暦）', ko:'양력', tl:'Gregorian' },
  cal_sys_lunar:{ en:'Lunar', vi:'Âm lịch', es:'Lunar', fr:'Lunaire', zh:'农历', ja:'旧暦（太陰暦）', ko:'음력', tl:'Lunar' },
  cal_sys_both:{ en:'Both (Gregorian + Lunar)', vi:'Cả hai (Dương lịch + Âm lịch)', es:'Ambos (gregoriano y lunar)', fr:'Les deux (grégorien + lunaire)', zh:'公历和农历都显示', ja:'両方（新暦＋旧暦）', ko:'둘 다 (양력 + 음력)', tl:'Pareho (Gregorian + Lunar)' },
  lunar_prefix:{ en:'Lunar', vi:'ÂL', es:'Lunar', fr:'Lun.', zh:'农历', ja:'旧暦', ko:'음력', tl:'Lunar' },
  leap_suffix:{ en:' (leap)', vi:' (nhuận)', es:' (bisiesto)', fr:' (bissextile)', zh:'（闰）', ja:'（閏）', ko:' (윤달)', tl:' (leap)' },

  poll:         { en:'Poll', vi:'Bình chọn', es:'Encuesta', fr:'Sondage', zh:'投票', ja:'投票', ko:'투표', tl:'Botohan' },
  poll_manage:  { en:'Edit poll', vi:'Sửa bình chọn', es:'Editar encuesta', fr:'Modifier le sondage', zh:'编辑投票', ja:'投票を編集', ko:'투표 수정', tl:'I-edit ang Botohan' },
  poll_question_label:{ en:'Question', vi:'Câu hỏi', es:'Pregunta', fr:'Question', zh:'问题', ja:'質問', ko:'질문', tl:'Tanong' },
  poll_option_label:{ en:'Option', vi:'Lựa chọn', es:'Opción', fr:'Option', zh:'选项', ja:'選択肢', ko:'옵션', tl:'Pagpipilian' },
  poll_add_option:{ en:'Add option', vi:'Thêm lựa chọn', es:'Añadir opción', fr:'Ajouter une option', zh:'添加选项', ja:'選択肢を追加', ko:'옵션 추가', tl:'Magdagdag ng Pagpipilian' },
  poll_reset_votes:{ en:'Reset votes', vi:'Đặt lại số phiếu', es:'Restablecer votos', fr:'Réinitialiser les votes', zh:'重置票数', ja:'投票をリセット', ko:'투표 재설정', tl:'I-reset ang mga Boto' },
  poll_total_votes:{ en:'{n} votes', vi:'{n} phiếu bầu', es:'{n} votos', fr:'{n} votes', zh:'{n} 票', ja:'{n}票', ko:'{n}표', tl:'{n} boto' },
  poll_tap_hint:{ en:'Tap an option each time someone votes for it', vi:'Chạm vào lựa chọn mỗi khi có người bình chọn', es:'Toca una opción cada vez que alguien vote por ella', fr:'Touchez une option à chaque vote pour elle', zh:'每次有人投票就点击该选项', ja:'投票があるたびに選択肢をタップしてください', ko:'투표할 때마다 해당 옵션을 탭하세요', tl:'Pindutin ang pagpipilian tuwing may boboto dito' },
  poll_min_options:{ en:'A poll needs at least 2 options', vi:'Cần ít nhất 2 lựa chọn', es:'Una encuesta necesita al menos 2 opciones', fr:'Un sondage nécessite au moins 2 options', zh:'投票至少需要2个选项', ja:'投票には少なくとも2つの選択肢が必要です', ko:'투표에는 최소 2개의 옵션이 필요합니다', tl:'Kailangan ng hindi bababa sa 2 pagpipilian' },

  noise:        { en:'Noise Meter', vi:'Máy đo tiếng ồn', es:'Medidor de ruido', fr:'Sonomètre', zh:'噪音检测器', ja:'騒音メーター', ko:'소음 측정기', tl:'Panukat ng Ingay' },
  noise_enable: { en:'Enable microphone', vi:'Bật micro', es:'Activar micrófono', fr:'Activer le microphone', zh:'启用麦克风', ja:'マイクを有効にする', ko:'마이크 활성화', tl:'I-enable ang mikropono' },
  noise_stop:   { en:'Turn off microphone', vi:'Tắt micro', es:'Apagar micrófono', fr:'Désactiver le microphone', zh:'关闭麦克风', ja:'マイクをオフにする', ko:'마이크 끄기', tl:'Patayin ang mikropono' },
  noise_quiet:  { en:'Quiet', vi:'Yên tĩnh', es:'Silencio', fr:'Calme', zh:'安静', ja:'静か', ko:'조용함', tl:'Tahimik' },
  noise_ok:     { en:'OK', vi:'Bình thường', es:'Aceptable', fr:'Correct', zh:'适中', ja:'普通', ko:'적당함', tl:'Katamtaman' },
  noise_loud:   { en:'Too loud', vi:'Quá ồn', es:'Demasiado ruido', fr:'Trop bruyant', zh:'太吵了', ja:'うるさい', ko:'너무 시끄러움', tl:'Sobrang ingay' },
  noise_approx_note:{ en:'Approximate reading from your device microphone — not a calibrated sound level meter.', vi:'Chỉ số ước tính từ micro thiết bị — không phải máy đo độ ồn đã hiệu chuẩn.', es:'Lectura aproximada del micrófono de tu dispositivo — no es un medidor de sonido calibrado.', fr:"Mesure approximative via le microphone de l'appareil — pas un sonomètre calibré.", zh:'来自设备麦克风的近似读数 — 并非经过校准的声级计。', ja:'デバイスのマイクによるおおよその値です — 校正済みの騒音計ではありません。', ko:'기기 마이크의 대략적인 값입니다 — 보정된 소음계가 아닙니다.', tl:'Tinatayang reading mula sa mikropono ng device — hindi ito calibrated na sound level meter.' },
  noise_denied: { en:"Microphone access was blocked. Allow it in your browser's site settings and try again.", vi:'Quyền truy cập micro đã bị chặn. Hãy cho phép trong cài đặt trang web của trình duyệt rồi thử lại.', es:'Se bloqueó el acceso al micrófono. Permítelo en la configuración del sitio de tu navegador e inténtalo de nuevo.', fr:"L'accès au microphone a été bloqué. Autorisez-le dans les paramètres du site de votre navigateur et réessayez.", zh:'麦克风访问被阻止。请在浏览器的网站设置中允许后重试。', ja:'マイクへのアクセスがブロックされました。ブラウザのサイト設定で許可してから再度お試しください。', ko:'마이크 접근이 차단되었습니다. 브라우저의 사이트 설정에서 허용한 후 다시 시도하세요.', tl:'Na-block ang access sa mikropono. Payagan ito sa site settings ng browser mo at subukan ulit.' },
  noise_no_mic: { en:'No microphone was found on this device.', vi:'Không tìm thấy micro trên thiết bị này.', es:'No se encontró ningún micrófono en este dispositivo.', fr:"Aucun microphone n'a été trouvé sur cet appareil.", zh:'未在此设备上找到麦克风。', ja:'このデバイスにマイクが見つかりませんでした。', ko:'이 기기에서 마이크를 찾을 수 없습니다.', tl:'Walang nahanap na mikropono sa device na ito.' },
  noise_insecure:{ en:"Microphone access needs a secure context — load this as the Chrome extension or serve it over http://localhost, not by opening the file directly.", vi:'Truy cập micro cần một môi trường bảo mật — hãy tải ứng dụng này dưới dạng tiện ích Chrome hoặc chạy qua http://localhost, không mở trực tiếp tệp.', es:'El acceso al micrófono necesita un contexto seguro — cárgalo como la extensión de Chrome o sírvelo desde http://localhost, no abriendo el archivo directamente.', fr:"L'accès au microphone nécessite un contexte sécurisé — chargez ceci en tant qu'extension Chrome ou servez-le via http://localhost, pas en ouvrant le fichier directement.", zh:'麦克风访问需要安全环境 — 请以 Chrome 扩展程序方式加载，或通过 http://localhost 提供服务，而不要直接打开文件。', ja:'マイクへのアクセスには安全なコンテキストが必要です — Chrome拡張機能として読み込むか、http://localhost経由で提供してください。ファイルを直接開かないでください。', ko:'마이크 접근에는 보안 컨텍스트가 필요합니다 — 파일을 직접 여는 대신 Chrome 확장 프로그램으로 불러오거나 http://localhost로 제공하세요.', tl:'Ang access sa mikropono ay nangangailangan ng secure context — i-load ito bilang Chrome extension o i-serve sa pamamagitan ng http://localhost, huwag buksan ang file nang direkta.' },

  music:        { en:'Music Player', vi:'Trình phát nhạc', es:'Reproductor de música', fr:'Lecteur de musique', zh:'音乐播放器', ja:'音楽プレーヤー', ko:'음악 플레이어', tl:'Music Player' },
  video_player: { en:'Video Player', vi:'Trình phát video', es:'Reproductor de video', fr:'Lecteur vidéo', zh:'视频播放器', ja:'動画プレーヤー', ko:'동영상 플레이어', tl:'Video Player' },
  tab_my_files: { en:'My files', vi:'Tệp của tôi', es:'Mis archivos', fr:'Mes fichiers', zh:'我的文件', ja:'マイファイル', ko:'내 파일', tl:'Mga File Ko' },
  tab_stream:   { en:'Stream', vi:'Phát trực tuyến', es:'Transmitir', fr:'Diffuser', zh:'在线播放', ja:'ストリーミング', ko:'스트리밍', tl:'Stream' },
  tab_youtube:  { en:'YouTube', vi:'YouTube', es:'YouTube', fr:'YouTube', zh:'YouTube', ja:'YouTube', ko:'YouTube', tl:'YouTube' },
  tab_spotify:  { en:'Spotify', vi:'Spotify', es:'Spotify', fr:'Spotify', zh:'Spotify', ja:'Spotify', ko:'Spotify', tl:'Spotify' },
  mp_add_files: { en:'Add music files', vi:'Thêm tệp nhạc', es:'Añadir archivos de música', fr:'Ajouter des fichiers audio', zh:'添加音乐文件', ja:'音楽ファイルを追加', ko:'음악 파일 추가', tl:'Magdagdag ng Music File' },
  mp_empty:     { en:'No music added yet', vi:'Chưa có nhạc nào được thêm', es:'Aún no se ha añadido música', fr:'Aucune musique ajoutée pour le moment', zh:'尚未添加音乐', ja:'まだ音楽が追加されていません', ko:'아직 추가된 음악이 없습니다', tl:'Wala pang naidaragdag na music' },
  vp_add_files: { en:'Add video files', vi:'Thêm tệp video', es:'Añadir archivos de video', fr:'Ajouter des fichiers vidéo', zh:'添加视频文件', ja:'動画ファイルを追加', ko:'동영상 파일 추가', tl:'Magdagdag ng Video File' },
  vp_empty:     { en:'No videos added yet', vi:'Chưa có video nào được thêm', es:'Aún no se han añadido videos', fr:'Aucune vidéo ajoutée pour le moment', zh:'尚未添加视频', ja:'まだ動画が追加されていません', ko:'아직 추가된 동영상이 없습니다', tl:'Wala pang naidaragdag na video' },
  stream_placeholder:{ en:'Paste a YouTube or SoundCloud link', vi:'Dán liên kết YouTube hoặc SoundCloud', es:'Pega un enlace de YouTube o SoundCloud', fr:'Collez un lien YouTube ou SoundCloud', zh:'粘贴 YouTube 或 SoundCloud 链接', ja:'YouTubeまたはSoundCloudのリンクを貼り付け', ko:'YouTube 또는 SoundCloud 링크를 붙여넣으세요', tl:'I-paste ang link ng YouTube o SoundCloud' },
  stream_invalid:{ en:"Couldn't recognize that link — try a YouTube or SoundCloud URL", vi:'Không nhận diện được liên kết này — hãy thử URL YouTube hoặc SoundCloud', es:'No se reconoció ese enlace — prueba con una URL de YouTube o SoundCloud', fr:"Ce lien n'a pas été reconnu — essayez une URL YouTube ou SoundCloud", zh:'无法识别该链接 — 请尝试使用 YouTube 或 SoundCloud 网址', ja:'そのリンクは認識できませんでした — YouTubeまたはSoundCloudのURLをお試しください', ko:'해당 링크를 인식할 수 없습니다 — YouTube 또는 SoundCloud URL을 시도해 보세요', tl:'Hindi nakilala ang link na iyon — subukan ang YouTube o SoundCloud URL' },
  youtube_placeholder:{ en:'Paste a YouTube video or playlist link', vi:'Dán liên kết video hoặc danh sách phát YouTube', es:'Pega un enlace de video o lista de reproducción de YouTube', fr:'Collez un lien de vidéo ou de playlist YouTube', zh:'粘贴 YouTube 视频或播放列表链接', ja:'YouTubeの動画または再生リストのリンクを貼り付け', ko:'YouTube 동영상 또는 재생목록 링크를 붙여넣으세요', tl:'I-paste ang link ng YouTube video o playlist' },
  youtube_external_msg:{ en:'Opened in a new browser tab.', vi:'Đã mở trong một tab trình duyệt mới.', es:'Se abrió en una nueva pestaña del navegador.', fr:'Ouvert dans un nouvel onglet du navigateur.', zh:'已在新的浏览器标签页中打开。', ja:'新しいブラウザタブで開きました。', ko:'새 브라우저 탭에서 열렸습니다.', tl:'Nabuksan sa bagong tab ng browser.' },
  open_in_youtube:{ en:'Open in YouTube', vi:'Mở trong YouTube', es:'Abrir en YouTube', fr:'Ouvrir dans YouTube', zh:'在 YouTube 中打开', ja:'YouTubeで開く', ko:'YouTube에서 열기', tl:'Buksan sa YouTube' },
  spotify_placeholder:{ en:'Paste a Spotify playlist or track link', vi:'Dán liên kết danh sách phát hoặc bài hát Spotify', es:'Pega un enlace de lista de reproducción o canción de Spotify', fr:'Collez un lien de playlist ou de piste Spotify', zh:'粘贴 Spotify 播放列表或歌曲链接', ja:'Spotifyのプレイリストまたは曲のリンクを貼り付け', ko:'Spotify 재생목록 또는 트랙 링크를 붙여넣으세요', tl:'I-paste ang link ng Spotify playlist o track' },
  spotify_open: { en:'Open in Spotify', vi:'Mở trong Spotify', es:'Abrir en Spotify', fr:'Ouvrir dans Spotify', zh:'在 Spotify 中打开', ja:'Spotifyで開く', ko:'Spotify에서 열기', tl:'Buksan sa Spotify' },
  spotify_note: { en:"Full playback inside this widget would need a Spotify Premium account and your own registered Spotify app (OAuth) — this opens your playlist in Spotify instead. Ask if you'd like that deeper integration built.", vi:'Để phát nhạc trực tiếp trong widget này cần tài khoản Spotify Premium và ứng dụng Spotify do bạn tự đăng ký (OAuth) — thay vào đó, nút này sẽ mở danh sách phát của bạn trong Spotify. Hãy cho tôi biết nếu bạn muốn xây dựng tích hợp sâu hơn.', es:'La reproducción completa dentro de este widget necesitaría una cuenta Spotify Premium y tu propia app de Spotify registrada (OAuth) — en su lugar, esto abre tu lista en Spotify. Avísame si quieres esa integración más profunda.', fr:"Une lecture complète dans ce widget nécessiterait un compte Spotify Premium et votre propre application Spotify enregistrée (OAuth) — ceci ouvre plutôt votre playlist dans Spotify. Dites-le-moi si vous voulez cette intégration plus poussée.", zh:'要在此小组件内完整播放，需要 Spotify Premium 账户和您自己注册的 Spotify 应用（OAuth）— 此按钮会改为在 Spotify 中打开您的播放列表。如果需要更深入的集成，请告诉我。', ja:'このウィジェット内で完全に再生するにはSpotify Premiumアカウントと独自に登録したSpotifyアプリ（OAuth）が必要です — 代わりにこれはSpotifyでプレイリストを開きます。より深い連携が必要な場合はお知らせください。', ko:'이 위젯 안에서 완전히 재생하려면 Spotify Premium 계정과 직접 등록한 Spotify 앱(OAuth)이 필요합니다 — 대신 이 버튼은 Spotify에서 재생목록을 엽니다. 더 깊은 연동이 필요하면 말씀해 주세요.', tl:'Ang buong playback sa loob ng widget na ito ay mangangailangan ng Spotify Premium account at sarili mong nakarehistrong Spotify app (OAuth) — sa halip, bubuksan nito ang playlist mo sa Spotify. Sabihin lang kung gusto mo ng mas malalim na integrasyon.' },

  soundboard:   { en:'Soundboard', vi:'Bảng âm thanh', es:'Tablero de sonidos', fr:'Table des sons', zh:'音效板', ja:'サウンドボード', ko:'사운드보드', tl:'Soundboard' },
  sfx_add:      { en:'Add sound effects (mp3, wav)', vi:'Thêm hiệu ứng âm thanh (mp3, wav)', es:'Añadir efectos de sonido (mp3, wav)', fr:'Ajouter des effets sonores (mp3, wav)', zh:'添加音效（mp3、wav）', ja:'効果音を追加（mp3、wav）', ko:'효과음 추가 (mp3, wav)', tl:'Magdagdag ng Sound Effect (mp3, wav)' },
  sfx_empty:    { en:'No sounds added yet', vi:'Chưa có âm thanh nào được thêm', es:'Aún no se han añadido sonidos', fr:'Aucun son ajouté pour le moment', zh:'尚未添加音效', ja:'まだ効果音が追加されていません', ko:'아직 추가된 소리가 없습니다', tl:'Wala pang naidaragdag na tunog' },
  sfx_stop:     { en:'Stop', vi:'Dừng', es:'Detener', fr:'Arrêter', zh:'停止', ja:'停止', ko:'정지', tl:'Ihinto' },
  sfx_volume:   { en:'Volume', vi:'Âm lượng', es:'Volumen', fr:'Volume', zh:'音量', ja:'音量', ko:'음량', tl:'Lakas ng Tunog' },

  calendar:     { en:'Calendar', vi:'Lịch', es:'Calendario', fr:'Calendrier', zh:'日历', ja:'カレンダー', ko:'캘린더', tl:'Kalendaryo' },
  cal_manage:   { en:'Manage events', vi:'Quản lý sự kiện', es:'Gestionar eventos', fr:'Gérer les événements', zh:'管理活动', ja:'予定を管理', ko:'일정 관리', tl:'Pamahalaan ang mga Event' },
  cal_back:     { en:'Back to calendar', vi:'Quay lại lịch', es:'Volver al calendario', fr:'Retour au calendrier', zh:'返回日历', ja:'カレンダーに戻る', ko:'캘린더로 돌아가기', tl:'Bumalik sa kalendaryo' },
  cal_today:    { en:'Today', vi:'Hôm nay', es:'Hoy', fr:"Aujourd'hui", zh:'今天', ja:'今日', ko:'오늘', tl:'Ngayon' },
  cal_no_events:{ en:'No events on this day', vi:'Không có sự kiện nào trong ngày này', es:'No hay eventos este día', fr:"Aucun événement ce jour-là", zh:'这一天没有活动', ja:'この日に予定はありません', ko:'이 날짜에는 일정이 없습니다', tl:'Walang event sa araw na ito' },
  cal_add_event:{ en:'Add event', vi:'Thêm sự kiện', es:'Añadir evento', fr:'Ajouter un événement', zh:'添加活动', ja:'予定を追加', ko:'일정 추가', tl:'Magdagdag ng Event' },
  cal_edit_event:{ en:'Edit event', vi:'Sửa sự kiện', es:'Editar evento', fr:"Modifier l'événement", zh:'编辑活动', ja:'予定を編集', ko:'일정 수정', tl:'I-edit ang Event' },
  cal_title:    { en:'Title', vi:'Tiêu đề', es:'Título', fr:'Titre', zh:'标题', ja:'タイトル', ko:'제목', tl:'Pamagat' },
  cal_date:     { en:'Date', vi:'Ngày', es:'Fecha', fr:'Date', zh:'日期', ja:'日付', ko:'날짜', tl:'Petsa' },
  cal_time:     { en:'Time (optional)', vi:'Giờ (không bắt buộc)', es:'Hora (opcional)', fr:'Heure (facultatif)', zh:'时间（可选）', ja:'時間（任意）', ko:'시간 (선택사항)', tl:'Oras (opsyonal)' },
  cal_reminder: { en:'Reminder', vi:'Nhắc nhở', es:'Recordatorio', fr:'Rappel', zh:'提醒', ja:'リマインダー', ko:'알림', tl:'Paalala' },
  cal_rem_none: { en:'No reminder', vi:'Không nhắc', es:'Sin recordatorio', fr:'Aucun rappel', zh:'不提醒', ja:'リマインダーなし', ko:'알림 없음', tl:'Walang paalala' },
  cal_rem_at:   { en:'At event time', vi:'Đúng giờ sự kiện', es:'A la hora del evento', fr:"À l'heure de l'événement", zh:'活动开始时', ja:'予定の時刻に', ko:'일정 시각에', tl:'Sa oras ng event' },
  cal_rem_5:    { en:'5 minutes before', vi:'Trước 5 phút', es:'5 minutos antes', fr:'5 minutes avant', zh:'提前5分钟', ja:'5分前', ko:'5분 전', tl:'5 minuto bago' },
  cal_rem_15:   { en:'15 minutes before', vi:'Trước 15 phút', es:'15 minutos antes', fr:'15 minutes avant', zh:'提前15分钟', ja:'15分前', ko:'15분 전', tl:'15 minuto bago' },
  cal_rem_30:   { en:'30 minutes before', vi:'Trước 30 phút', es:'30 minutos antes', fr:'30 minutes avant', zh:'提前30分钟', ja:'30分前', ko:'30분 전', tl:'30 minuto bago' },
  cal_rem_60:   { en:'1 hour before', vi:'Trước 1 giờ', es:'1 hora antes', fr:'1 heure avant', zh:'提前1小时', ja:'1時間前', ko:'1시간 전', tl:'1 oras bago' },
  cal_notes:    { en:'Notes (optional)', vi:'Ghi chú (không bắt buộc)', es:'Notas (opcional)', fr:'Notes (facultatif)', zh:'备注（可选）', ja:'メモ（任意）', ko:'메모 (선택사항)', tl:'Mga Tala (opsyonal)' },
  cal_save:     { en:'Save event', vi:'Lưu sự kiện', es:'Guardar evento', fr:"Enregistrer l'événement", zh:'保存活动', ja:'予定を保存', ko:'일정 저장', tl:'I-save ang Event' },
  cal_cancel:   { en:'Cancel', vi:'Hủy', es:'Cancelar', fr:'Annuler', zh:'取消', ja:'キャンセル', ko:'취소', tl:'Kanselahin' },
  cal_all_events:{ en:'All events', vi:'Tất cả sự kiện', es:'Todos los eventos', fr:'Tous les événements', zh:'所有活动', ja:'すべての予定', ko:'모든 일정', tl:'Lahat ng Event' },
  cal_none_yet: { en:'No events yet', vi:'Chưa có sự kiện nào', es:'Aún no hay eventos', fr:"Pas encore d'événement", zh:'暂无活动', ja:'まだ予定はありません', ko:'아직 일정이 없습니다', tl:'Wala pang event' },
  cal_add_to_google:{ en:'Add to Google Calendar', vi:'Thêm vào Google Calendar', es:'Añadir a Google Calendar', fr:'Ajouter à Google Agenda', zh:'添加到 Google 日历', ja:'Googleカレンダーに追加', ko:'Google 캘린더에 추가', tl:'Idagdag sa Google Calendar' },
  cal_import_ics:{ en:'Import from Google Calendar (.ics file)', vi:'Nhập từ Google Calendar (tệp .ics)', es:'Importar desde Google Calendar (archivo .ics)', fr:'Importer depuis Google Agenda (fichier .ics)', zh:'从 Google 日历导入（.ics 文件）', ja:'Googleカレンダーからインポート（.icsファイル）', ko:'Google 캘린더에서 가져오기 (.ics 파일)', tl:'Mag-import mula sa Google Calendar (.ics file)' },
  cal_import_hint:{ en:'In Google Calendar, export a calendar or event as .ics, then add the file here.', vi:'Trong Google Calendar, xuất lịch hoặc sự kiện dưới dạng .ics, rồi thêm tệp đó vào đây.', es:'En Google Calendar, exporta un calendario o evento como .ics y añádelo aquí.', fr:'Dans Google Agenda, exportez un agenda ou un événement en .ics, puis ajoutez le fichier ici.', zh:'在 Google 日历中将日历或活动导出为 .ics 文件，然后在此处添加。', ja:'Googleカレンダーでカレンダーや予定を.ics形式でエクスポートし、ここに追加してください。', ko:'Google 캘린더에서 캘린더나 일정을 .ics로 내보낸 후 여기에 추가하세요.', tl:'Sa Google Calendar, i-export ang kalendaryo o event bilang .ics, tapos idagdag ang file dito.' },
  cal_import_done:{ en:'Imported {n} event(s)', vi:'Đã nhập {n} sự kiện', es:'Se importaron {n} evento(s)', fr:'{n} événement(s) importé(s)', zh:'已导入 {n} 个活动', ja:'{n}件の予定をインポートしました', ko:'{n}개의 일정을 가져왔습니다', tl:'Na-import ang {n} event' },
  cal_enable_notifs:{ en:'Enable desktop notifications', vi:'Bật thông báo trên máy tính', es:'Activar notificaciones de escritorio', fr:'Activer les notifications', zh:'启用桌面通知', ja:'デスクトップ通知を有効にする', ko:'데스크톱 알림 사용', tl:'I-enable ang desktop notifications' },
  cal_notifs_on:{ en:'Desktop notifications enabled', vi:'Đã bật thông báo trên máy tính', es:'Notificaciones de escritorio activadas', fr:'Notifications activées', zh:'桌面通知已启用', ja:'デスクトップ通知が有効になりました', ko:'데스크톱 알림이 활성화되었습니다', tl:'Na-enable na ang desktop notifications' },
  cal_notifs_denied:{ en:'Notifications are blocked — enable them in your browser settings', vi:'Thông báo đang bị chặn — hãy bật trong cài đặt trình duyệt', es:'Las notificaciones están bloqueadas — actívalas en la configuración del navegador', fr:'Les notifications sont bloquées — activez-les dans les paramètres du navigateur', zh:'通知已被阻止 — 请在浏览器设置中启用', ja:'通知がブロックされています — ブラウザの設定で有効にしてください', ko:'알림이 차단되어 있습니다 — 브라우저 설정에서 활성화하세요', tl:'Naka-block ang mga notification — i-enable ito sa settings ng browser' },
  reminder_popup_title:{ en:'Event reminder', vi:'Nhắc nhở sự kiện', es:'Recordatorio de evento', fr:"Rappel d'événement", zh:'活动提醒', ja:'予定のリマインダー', ko:'일정 알림', tl:'Paalala sa Event' },
  cal_untitled: { en:'(untitled event)', vi:'(sự kiện chưa đặt tên)', es:'(evento sin título)', fr:'(événement sans titre)', zh:'（未命名活动）', ja:'（無題の予定）', ko:'(제목 없는 일정)', tl:'(walang pamagat na event)' },
  dismiss:      { en:'Dismiss', vi:'Đóng thông báo', es:'Descartar', fr:'Ignorer', zh:'关闭提醒', ja:'閉じる', ko:'닫기', tl:'Isara ang paalala' },

  pro_section_title: { en:'TeachersDeck Pro', vi:'TeachersDeck Pro' },
  pro_status_free: { en:'You\'re on the Free plan', vi:'Bạn đang dùng gói Miễn phí' },
  pro_status_pro: { en:'Pro unlocked — thank you!', vi:'Đã mở khóa Pro — cảm ơn bạn!' },
  pro_upgrade_btn: { en:'Upgrade to Pro', vi:'Nâng cấp lên Pro' },
  pro_license_label: { en:'Already purchased? Enter your license key', vi:'Đã mua rồi? Nhập mã bản quyền của bạn' },
  pro_license_placeholder: { en:'TDPRO-XXXX-XXXX-XXXX', vi:'TDPRO-XXXX-XXXX-XXXX' },
  pro_activate_btn: { en:'Activate', vi:'Kích hoạt' },
  pro_license_invalid: { en:'That license key isn\'t valid', vi:'Mã bản quyền không hợp lệ' },
  pro_license_valid: { en:'Pro unlocked on this device', vi:'Đã mở khóa Pro trên thiết bị này' },
  pro_modal_title: { en:'Upgrade to TeachersDeck Pro', vi:'Nâng cấp lên TeachersDeck Pro' },
  pro_modal_subtitle: { en:'One-time payment, no subscription. Unlocks on this browser.', vi:'Thanh toán một lần, không phải trả phí định kỳ. Mở khóa trên trình duyệt này.' },
  pro_close: { en:'Close', vi:'Đóng' },
  plan_free_title: { en:'Free', vi:'Miễn phí' },
  plan_pro_title: { en:'Pro', vi:'Pro' },
  plan_free_f1: { en:'Clock, timer & stopwatch', vi:'Đồng hồ, hẹn giờ & bấm giờ' },
  plan_free_f2: { en:'Built-in calendar', vi:'Lịch tích hợp' },
  plan_free_f3: { en:'Lesson files on this device', vi:'Tệp bài học trên thiết bị này' },
  plan_pro_f1: { en:'Everything in Free', vi:'Tất cả tính năng của gói Miễn phí' },
  plan_pro_f2: { en:'Traffic light, dice, checklist, scoreboard, poll, noise meter', vi:'Đèn giao thông, xúc xắc, danh sách việc, bảng điểm, khảo sát, đo tiếng ồn' },
  plan_pro_f3: { en:'Games, music & video player, soundboard', vi:'Trò chơi, nhạc & video, bảng âm thanh' },
  plan_pro_f4: { en:'Custom background/logo & side drawer customization', vi:'Ảnh nền/logo tùy chỉnh & tùy chỉnh ngăn kéo bên' },
  pay_tab_vietqr: { en:'VietQR (Bank transfer)', vi:'VietQR (Chuyển khoản)' },
  pay_tab_card: { en:'{label}', vi:'{label}' },
  vietqr_instructions: { en:'Scan with any Vietnamese banking app to pay {price}. Include your email in the transfer note so we can send your license key.', vi:'Quét bằng ứng dụng ngân hàng bất kỳ để thanh toán {price}. Ghi email của bạn vào nội dung chuyển khoản để nhận mã bản quyền.' },
  vietqr_not_configured: { en:'VietQR isn\'t set up yet — add your HSBC account number in js/app.js (search HSBC_ACCOUNT_NUMBER).', vi:'VietQR chưa được thiết lập — thêm số tài khoản HSBC của bạn trong js/app.js (tìm HSBC_ACCOUNT_NUMBER).' },
  card_instructions: { en:'Pay {price} securely by card.', vi:'Thanh toán {price} an toàn bằng thẻ.' },
  pay_card_btn: { en:'Pay with {label}', vi:'Thanh toán bằng {label}' },
  card_not_configured: { en:'Card payment isn\'t set up yet — add a payment link in js/app.js (search STRIPE_PAYMENT_LINK).', vi:'Thanh toán bằng thẻ chưa được thiết lập — thêm liên kết thanh toán trong js/app.js (tìm STRIPE_PAYMENT_LINK).' },
  pro_locked_hint: { en:'This is a Pro feature.', vi:'Đây là tính năng của Pro.' },

  /* ---- Wave 1 widgets ---- */
  attendance:   { en:'Attendance Tracker', vi:'Điểm danh' },
  att_present:  { en:'Present', vi:'Có mặt' },
  att_absent:   { en:'Absent', vi:'Vắng' },
  att_late:     { en:'Late', vi:'Trễ' },
  att_export:   { en:'Export day (.csv)', vi:'Xuất ngày (.csv)' },
  att_no_roster:{ en:'Add students under Settings → Class list first.', vi:'Hãy thêm học sinh trong Cài đặt → Danh sách lớp trước.' },
  att_date_label:{ en:'Date', vi:'Ngày' },
  att_summary:  { en:'{present} present · {absent} absent · {late} late', vi:'{present} có mặt · {absent} vắng · {late} trễ' },

  groupmaker:   { en:'Group Maker', vi:'Chia nhóm' },
  gm_mode_groups:{ en:'Number of groups', vi:'Số nhóm' },
  gm_mode_size: { en:'Students per group', vi:'Số học sinh mỗi nhóm' },
  gm_shuffle:   { en:'Shuffle', vi:'Xáo trộn' },
  gm_no_roster: { en:'Add students under Settings → Class list first.', vi:'Hãy thêm học sinh trong Cài đặt → Danh sách lớp trước.' },
  gm_group_label:{ en:'Group {n}', vi:'Nhóm {n}' },

  exitticket:   { en:'Exit Ticket', vi:'Phiếu ra lớp' },
  et_question_placeholder:{ en:'Type today\'s check-in question…', vi:'Nhập câu hỏi kiểm tra nhanh hôm nay…' },
  et_got_it:    { en:'Got it', vi:'Đã hiểu' },
  et_almost:    { en:'Almost', vi:'Gần hiểu' },
  et_need_help: { en:'Need help', vi:'Cần giúp đỡ' },
  et_hint:      { en:'Tap a button once per raised hand', vi:'Chạm một lần cho mỗi tay giơ lên' },
  et_reset:     { en:'Reset tally', vi:'Đặt lại số đếm' },

  agenda:       { en:'Agenda Board', vi:'Bảng chương trình' },
  agenda_schedule_label:{ en:'Today\'s schedule', vi:'Lịch trình hôm nay' },
  agenda_objective_label:{ en:'Objective', vi:'Mục tiêu' },
  agenda_donow_label:{ en:'Do now', vi:'Bắt đầu ngay' },
  agenda_schedule_placeholder:{ en:'e.g. 9:00 warm-up · 9:15 grammar · 9:40 practice', vi:'ví dụ: 9:00 khởi động · 9:15 ngữ pháp · 9:40 luyện tập' },
  agenda_objective_placeholder:{ en:'Students will be able to…', vi:'Học sinh sẽ có thể…' },
  agenda_donow_placeholder:{ en:'Write today\'s date and one new word you know', vi:'Viết ngày hôm nay và một từ mới bạn biết' },

  qrcode:       { en:'QR Code Generator', vi:'Tạo mã QR' },
  qr_placeholder:{ en:'Paste a link or type text…', vi:'Dán liên kết hoặc nhập văn bản…' },
  qr_generate:  { en:'Generate', vi:'Tạo mã' },
  qr_hint:      { en:'Generated entirely on this device — nothing is sent anywhere.', vi:'Được tạo hoàn toàn trên thiết bị này — không gửi đi đâu cả.' },
  qr_download:  { en:'Download PNG', vi:'Tải xuống PNG' },
  qr_empty:     { en:'Enter a link or some text first', vi:'Hãy nhập liên kết hoặc văn bản trước' },

  countdown:    { en:'Days-Until Countdown', vi:'Đếm ngược ngày' },
  cd_label_placeholder:{ en:'What are we counting down to?', vi:'Đếm ngược đến sự kiện nào?' },
  cd_date_label:{ en:'Date', vi:'Ngày' },
  cd_days_left: { en:'{n} days to go', vi:'Còn {n} ngày' },
  cd_one_day:   { en:'1 day to go', vi:'Còn 1 ngày' },
  cd_today:     { en:'Today!', vi:'Hôm nay!' },
  cd_past:      { en:'That date has passed', vi:'Ngày đó đã qua' },
  cd_set_prompt:{ en:'Set a date below to start the countdown', vi:'Chọn ngày bên dưới để bắt đầu đếm ngược' },

  hallpass:     { en:'Hall Pass Tracker', vi:'Theo dõi ra ngoài' },
  hp_student_label:{ en:'Student', vi:'Học sinh' },
  hp_dest_placeholder:{ en:'Destination (restroom, office…)', vi:'Nơi đến (nhà vệ sinh, văn phòng…)' },
  hp_send_out:  { en:'Send out', vi:'Cho ra ngoài' },
  hp_return:    { en:'Mark returned', vi:'Đánh dấu đã về' },
  hp_out_since: { en:'{name} — out to {dest}', vi:'{name} — đang đến {dest}' },
  hp_log_title: { en:'Today\'s log', vi:'Nhật ký hôm nay' },
  hp_no_roster: { en:'Add students under Settings → Class list first.', vi:'Hãy thêm học sinh trong Cài đặt → Danh sách lớp trước.' },
  hp_busy:      { en:'Someone is already out — mark them returned first.', vi:'Đã có học sinh ra ngoài — hãy đánh dấu đã về trước.' },
  hp_clear_log: { en:'Clear log', vi:'Xóa nhật ký' },

  readinglog:   { en:'Reading Timer & Log', vi:'Hẹn giờ & nhật ký đọc sách' },
  rl_minutes_label:{ en:'Silent reading minutes', vi:'Số phút đọc thầm' },
  rl_log_title: { en:'Reading log', vi:'Nhật ký đọc sách' },
  rl_student_placeholder:{ en:'Student name', vi:'Tên học sinh' },
  rl_note_placeholder:{ en:'Book / notes (optional)', vi:'Sách / ghi chú (tuỳ chọn)' },
  rl_log_entry: { en:'{name} — {min} min', vi:'{name} — {min} phút' },
  rl_clear_log: { en:'Clear log', vi:'Xóa nhật ký' },

  ttsreader:    { en:'Text-to-Speech Reader', vi:'Đọc văn bản' },
  tts_placeholder:{ en:'Paste or type text to read aloud…', vi:'Dán hoặc nhập văn bản để đọc to…' },
  tts_play:     { en:'Read aloud', vi:'Đọc to' },
  tts_stop:     { en:'Stop', vi:'Dừng' },
  tts_speed:    { en:'Speed', vi:'Tốc độ' },
  tts_voice:    { en:'Voice', vi:'Giọng đọc' },
  tts_unsupported:{ en:'Text-to-speech isn\'t supported in this browser.', vi:'Trình duyệt này không hỗ trợ đọc văn bản.' },

  unitconverter:{ en:'Unit Converter', vi:'Đổi đơn vị' },
  uc_category:  { en:'Category', vi:'Loại' },
  uc_length:    { en:'Length', vi:'Chiều dài' },
  uc_weight:    { en:'Weight', vi:'Cân nặng' },
  uc_temperature:{ en:'Temperature', vi:'Nhiệt độ' },
  uc_currency:  { en:'Currency', vi:'Tiền tệ' },
  uc_currency_note:{ en:'Approximate fixed rates, not live — for classroom estimates only.', vi:'Tỷ giá cố định gần đúng, không cập nhật trực tiếp — chỉ để ước tính trong lớp.' },

  announcements:{ en:'Announcements Board', vi:'Bảng thông báo' },
  ann_placeholder:{ en:'Write an announcement…', vi:'Viết thông báo…' },
  ann_pin:      { en:'Pin', vi:'Ghim' },
  ann_expiry:   { en:'Auto-expire after', vi:'Tự ẩn sau' },
  ann_no_expiry:{ en:'Never', vi:'Không bao giờ' },
  ann_post:     { en:'Post', vi:'Đăng' },
  ann_empty:    { en:'No announcements yet.', vi:'Chưa có thông báo nào.' },
  ann_pinned_badge:{ en:'Pinned', vi:'Đã ghim' },

  instructions: { en:'Instructions Display', vi:'Bảng hướng dẫn' },
  ins_title_placeholder:{ en:'Activity title (optional)', vi:'Tên hoạt động (tuỳ chọn)' },
  ins_step_placeholder:{ en:'Step text…', vi:'Nội dung bước…' },
  ins_add_step: { en:'Add step', vi:'Thêm bước' },
  ins_step_of:  { en:'Step {cur} of {total}', vi:'Bước {cur} / {total}' },
  ins_prev:     { en:'Previous', vi:'Trước' },
  ins_next:     { en:'Next', vi:'Tiếp theo' },
  ins_edit:     { en:'Edit steps', vi:'Chỉnh sửa các bước' },
  ins_done_editing:{ en:'Done editing', vi:'Xong chỉnh sửa' },
  ins_empty:    { en:'Add steps to build a set of directions.', vi:'Thêm các bước để tạo hướng dẫn.' },

  convocards:   { en:'Conversation Starter Cards', vi:'Thẻ gợi ý hội thoại' },
  cc_topic_label:{ en:'Topic', vi:'Chủ đề' },
  cc_difficulty_label:{ en:'Difficulty', vi:'Độ khó' },
  cc_all:       { en:'All', vi:'Tất cả' },
  cc_next_card: { en:'Next card', vi:'Thẻ tiếp theo' },
  cc_diff_easy: { en:'Easy', vi:'Dễ' },
  cc_diff_medium:{ en:'Medium', vi:'Trung bình' },
  cc_diff_hard: { en:'Hard', vi:'Khó' },

  idiomday:     { en:'Idiom of the Day', vi:'Thành ngữ hôm nay' },
  idiom_meaning:{ en:'Meaning', vi:'Ý nghĩa' },
  idiom_example:{ en:'Example', vi:'Ví dụ' },
  idiom_shuffle:{ en:'Show another', vi:'Xem thành ngữ khác' },
  idiom_back_today:{ en:'Back to today', vi:'Quay lại hôm nay' },

  grammarref:   { en:'Grammar Quick-Reference', vi:'Tra cứu ngữ pháp nhanh' },
  gr_rule:      { en:'Rule', vi:'Quy tắc' },
  gr_examples:  { en:'Examples', vi:'Ví dụ' }
};

function t(key, vars){
  const entry = STRINGS[key];
  let str = (entry && (entry[state.lang] || entry.en)) || key;
  if(vars){
    Object.keys(vars).forEach(k=>{ str = str.replace(`{${k}}`, vars[k]); });
  }
  return str;
}

function localizeNode(root){
  root = root || document;
  root.querySelectorAll('[data-i18n]').forEach(el=>{ el.textContent = t(el.dataset.i18n); });
  root.querySelectorAll('[data-i18n-dyn]').forEach(el=>{ el.textContent = t(el.dataset.key); });
  root.querySelectorAll('[data-i18n-count]').forEach(el=>{ el.textContent = t('roster_count', { n: state.roster.length }); });
  root.querySelectorAll('[data-i18n-placeholder]').forEach(el=>{ el.placeholder = t(el.dataset.i18nPlaceholder); });
  root.querySelectorAll('[data-i18n-aria]').forEach(el=>{ el.setAttribute('aria-label', t(el.dataset.i18nAria)); });
  root.querySelectorAll('[data-i18n-aria-dyn]').forEach(el=>{ el.setAttribute('aria-label', t(el.dataset.key)); });
  root.querySelectorAll('[data-i18n-title]').forEach(el=>{ el.title = t(el.dataset.i18nTitle); });
}

/* ---------------- IndexedDB (files + images) ---------------- */
const idb = {
  _db:null,
  open(){
    if(this._db) return Promise.resolve(this._db);
    return new Promise((resolve,reject)=>{
      if(typeof indexedDB === 'undefined'){
        reject(new Error('indexedDB unavailable in this browsing context'));
        return;
      }
      // Bumped 1 -> 2: earlier builds hardcoded version 1 even as object
      // stores were added over time, so onupgradeneeded never re-ran for
      // anyone whose "TeachersDeck" DB already existed at version 1 without
      // a given store (e.g. a browser profile that first touched this DB
      // before the "images" store existed) — put()/get() on that store then
      // fails silently. The version bump forces onupgradeneeded to run once
      // for everybody; the per-store `contains()` checks below are already
      // idempotent, so this is safe to bump again in the future the same way.
      const req = indexedDB.open('TeachersDeck', 2);
      req.onupgradeneeded = e=>{
        const db = e.target.result;
        if(!db.objectStoreNames.contains('files')) db.createObjectStore('files',{keyPath:'id'});
        if(!db.objectStoreNames.contains('images')) db.createObjectStore('images',{keyPath:'id'});
        if(!db.objectStoreNames.contains('games')) db.createObjectStore('games',{keyPath:'id'});
        if(!db.objectStoreNames.contains('music')) db.createObjectStore('music',{keyPath:'id'});
        if(!db.objectStoreNames.contains('videos')) db.createObjectStore('videos',{keyPath:'id'});
        if(!db.objectStoreNames.contains('sounds')) db.createObjectStore('sounds',{keyPath:'id'});
      };
      req.onsuccess = e=>{
        const db = e.target.result;
        // If another tab (or a newer build) needs to upgrade the DB, let go of
        // our connection instead of blocking it — a blocked upgrade just hangs.
        db.onversionchange = ()=>{ db.close(); if(this._db === db) this._db = null; };
        this._db = db; resolve(db);
      };
      req.onerror = e=> reject(e.target && e.target.error ? e.target.error : e);
      req.onblocked = ()=> reject(new Error('indexedDB upgrade blocked — another tab has this app open'));
    });
  },
  async put(store, record){
    const db = await this.open();
    return new Promise((res,rej)=>{
      const tx = db.transaction(store,'readwrite');
      tx.objectStore(store).put(record);
      tx.oncomplete = ()=>res(true);
      tx.onerror = e=>rej(e);
    });
  },
  async delete(store, id){
    const db = await this.open();
    return new Promise((res,rej)=>{
      const tx = db.transaction(store,'readwrite');
      tx.objectStore(store).delete(id);
      tx.oncomplete = ()=>res(true);
      tx.onerror = e=>rej(e);
    });
  },
  async getAll(store){
    const db = await this.open();
    return new Promise((res,rej)=>{
      const tx = db.transaction(store,'readonly');
      const req = tx.objectStore(store).getAll();
      req.onsuccess = ()=>res(req.result || []);
      req.onerror = e=>rej(e);
    });
  },
  async get(store,id){
    const db = await this.open();
    return new Promise((res,rej)=>{
      const tx = db.transaction(store,'readonly');
      const req = tx.objectStore(store).get(id);
      req.onsuccess = ()=>res(req.result || null);
      req.onerror = e=>rej(e);
    });
  }
};

function toast(msg, ms){
  const el = document.getElementById('toast');
  el.textContent = msg; el.hidden = false;
  clearTimeout(toast._h);
  toast._h = setTimeout(()=> el.hidden = true, ms || 2200);
}

/* ---------------- Icons (inline, stroke-based) ---------------- */
const ICONS = {
  clock:`<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>`,
  timer:`<path d="M10 2h4"/><path d="M12 6v0"/><circle cx="12" cy="14" r="8"/><path d="M12 14V9"/><path d="M18 6l1.5-1.5"/>`,
  stopwatch:`<circle cx="12" cy="13" r="8"/><path d="M12 13V9"/><path d="M9 3h6"/>`,
  traffic:`<rect x="8" y="2" width="8" height="20" rx="4"/><circle cx="12" cy="6.5" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="12" cy="17.5" r="1.4"/>`,
  dice:`<rect x="3" y="3" width="18" height="18" rx="4"/><circle cx="8" cy="8" r="1.3"/><circle cx="16" cy="8" r="1.3"/><circle cx="8" cy="16" r="1.3"/><circle cx="16" cy="16" r="1.3"/><circle cx="12" cy="12" r="1.3"/>`,
  checklist:`<path d="M4 6h1M4 12h1M4 18h1"/><path d="M9 6h11M9 12h11M9 18h11"/><path d="M3.3 6l.7.7L5.3 5.4" stroke-width="0"/>`,
  people:`<circle cx="9" cy="8" r="3"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><circle cx="17" cy="8" r="2.4"/><path d="M15.5 14a5 5 0 0 1 5.5 5"/>`,
  shuffle:`<path d="M3 6h3.5c1.3 0 2.5.7 3.2 1.8l4.6 7.4c.7 1.1 1.9 1.8 3.2 1.8H21"/><path d="M17 4l4 3-4 3"/><path d="M3 18h3.5c1.3 0 2.5-.7 3.2-1.8"/><path d="M17 20l4-3-4-3"/>`,
  files:`<path d="M4 4h6l2 2h8v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z"/>`,
  game:`<rect x="2" y="8" width="20" height="10" rx="5"/><path d="M7 11v4M5 13h4"/><circle cx="16" cy="11.5" r="1"/><circle cx="18.5" cy="14" r="1"/>`,
  trophy:`<path d="M7 3h10v4a5 5 0 0 1-10 0V3Z"/><path d="M7 4H4.5A2.5 2.5 0 0 0 4 8.9L7 11"/><path d="M17 4h2.5A2.5 2.5 0 0 1 20 8.9L17 11"/><path d="M12 12v3.5"/><path d="M9 20h6"/><path d="M9.6 16.5h4.8l.5 3.5H9.1l.5-3.5Z"/>`,
  settings:`<circle cx="12" cy="12" r="3.2"/><path d="M19.4 13a7.6 7.6 0 0 0 0-2l2-1.6-2-3.4-2.4 1a7.5 7.5 0 0 0-1.7-1L15 3h-4l-.3 2.6a7.5 7.5 0 0 0-1.7 1l-2.4-1-2 3.4L6.6 11a7.6 7.6 0 0 0 0 2l-2 1.6 2 3.4 2.4-1a7.5 7.5 0 0 0 1.7 1L11 21h4l.3-2.6a7.5 7.5 0 0 0 1.7-1l2.4 1 2-3.4L19.4 13Z"/>`,
  close:`<path d="M6 6l12 12M18 6L6 18"/>`,
  grip:`<circle cx="9" cy="6.5" r="1.3"/><circle cx="15" cy="6.5" r="1.3"/><circle cx="9" cy="12" r="1.3"/><circle cx="15" cy="12" r="1.3"/><circle cx="9" cy="17.5" r="1.3"/><circle cx="15" cy="17.5" r="1.3"/>`,
  minimize:`<path d="M5 12h14"/>`,
  restore:`<rect x="6" y="6" width="12" height="12" rx="2"/>`,
  calendar:`<rect x="3" y="4.5" width="18" height="16" rx="2.5"/><path d="M3 9.5h18"/><path d="M8 2.5v4M16 2.5v4"/><circle cx="8" cy="14" r="1"/><circle cx="12" cy="14" r="1"/><circle cx="16" cy="14" r="1"/>`,
  chevronLeft:`<path d="M14.5 5 8 12l6.5 7"/>`,
  chevronRight:`<path d="M9.5 5 16 12l-6.5 7"/>`,
  bell:`<path d="M6 10a6 6 0 1 1 12 0c0 4 1.5 5.5 1.5 5.5H4.5S6 14 6 10Z"/><path d="M10 19a2 2 0 0 0 4 0"/>`,
  plus:`<path d="M12 5v14M5 12h14"/>`,
  poll:`<rect x="4" y="11" width="4" height="9" rx="1"/><rect x="10" y="6" width="4" height="14" rx="1"/><rect x="16" y="14" width="4" height="6" rx="1"/>`,
  mic:`<rect x="9" y="2.5" width="6" height="12" rx="3"/><path d="M5.5 10.5a6.5 6.5 0 0 0 13 0"/><path d="M12 17v4"/><path d="M8.5 21h7"/>`,
  musicNote:`<path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/>`,
  videoCam:`<rect x="2" y="6" width="14" height="12" rx="2"/><path d="M16 10l6-4v12l-6-4"/>`,
  speaker:`<path d="M4 9v6h3.5l5 4V5l-5 4H4Z"/><path d="M16 9a4.5 4.5 0 0 1 0 6"/><path d="M18.5 6.5a8 8 0 0 1 0 11"/>`,
  qrcode:`<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM19 14v3M14 19h2M19 19h2"/>`,
  door:`<rect x="5" y="2.5" width="12" height="19" rx="1"/><circle cx="14" cy="12" r="1"/><path d="M17 21.5h4M3 21.5h4"/>`,
  swap:`<path d="M4 8h13"/><path d="M13 4l4 4-4 4"/><path d="M20 16H7"/><path d="M11 12l-4 4 4 4"/>`,
  clipboard:`<rect x="5" y="4" width="14" height="17" rx="2"/><rect x="8.5" y="2" width="7" height="3.5" rx="1"/><path d="M8.5 11h7M8.5 15h7M8.5 19h4"/>`,
  chat:`<path d="M4 5h16v11H9l-4 4V5Z"/><path d="M8 9h8M8 12.5h5"/>`,
  quote:`<path d="M7 8c-2 0-3.3 1.6-3.3 3.7 0 2.2 1.6 3.6 3.2 3.6.2 1.7-.9 3-2.6 3.4l.5 1.6c3-.5 4.6-2.6 4.6-5.8V8H7Zm9 0c-2 0-3.3 1.6-3.3 3.7 0 2.2 1.6 3.6 3.2 3.6.2 1.7-.9 3-2.6 3.4l.5 1.6c3-.5 4.6-2.6 4.6-5.8V8H16Z"/>`,
  book:`<path d="M4 4.5c2.5-1 5.5-1 8 0v15c-2.5-1-5.5-1-8 0v-15Z"/><path d="M20 4.5c-2.5-1-5.5-1-8 0v15c2.5-1 5.5-1 8 0v-15Z"/>`
};
function iconSvg(name, cls=''){
  return `<svg class="${cls}" viewBox="0 0 24 24">${ICONS[name]||''}</svg>`;
}

/* ---------------- Widget registry ---------------- */
/* Each widget: id, label, icon, w/h default, render(body, ctx) */
const WIDGETS = [
  { id:'clock', labelKey:'clock', icon:'clock', w:200, h:222, render:renderClock },
  { id:'timer', labelKey:'timer', icon:'timer', w:220, h:210, render:renderTimer },
  { id:'stopwatch', labelKey:'stopwatch', icon:'stopwatch', w:220, h:280, render:renderStopwatch },
  { id:'traffic', labelKey:'traffic', icon:'traffic', w:180, h:250, render:renderTraffic },
  { id:'dice', labelKey:'dice', icon:'dice', w:200, h:200, render:renderDice },
  { id:'checklist', labelKey:'checklist', icon:'checklist', w:260, h:270, render:renderChecklist },
  { id:'files', labelKey:'files', icon:'files', w:280, h:280, render:renderFiles },
  { id:'games', labelKey:'games', icon:'game', w:280, h:360, render:renderGames, pro:true },
  { id:'scoreboard', labelKey:'scoreboard', icon:'trophy', w:260, h:440, render:renderScoreboard },
  { id:'calendar', labelKey:'calendar', icon:'calendar', w:300, h:440, render:renderCalendar },
  { id:'poll', labelKey:'poll', icon:'poll', w:270, h:320, render:renderPoll },
  { id:'noise', labelKey:'noise', icon:'mic', w:230, h:320, render:renderNoise },
  { id:'music', labelKey:'music', icon:'musicNote', w:290, h:380, render:renderMusic, pro:true },
  { id:'videoplayer', labelKey:'video_player', icon:'videoCam', w:340, h:400, render:renderVideoPlayer, pro:true },
  { id:'soundboard', labelKey:'soundboard', icon:'speaker', w:280, h:320, render:renderSoundboard, pro:true },
  { id:'attendance', labelKey:'attendance', icon:'people', w:260, h:380, render:renderAttendance, pro:true },
  { id:'groupmaker', labelKey:'groupmaker', icon:'shuffle', w:280, h:360, render:renderGroupMaker, pro:true },
  { id:'exitticket', labelKey:'exitticket', icon:'poll', w:260, h:320, render:renderExitTicket, pro:true },
  { id:'agenda', labelKey:'agenda', icon:'clipboard', w:300, h:360, render:renderAgenda, pro:true },
  { id:'qrcode', labelKey:'qrcode', icon:'qrcode', w:260, h:340, render:renderQrCode, pro:true },
  { id:'countdown', labelKey:'countdown', icon:'timer', w:240, h:220, render:renderCountdown, pro:true },
  { id:'hallpass', labelKey:'hallpass', icon:'door', w:260, h:360, render:renderHallPass, pro:true },
  { id:'readinglog', labelKey:'readinglog', icon:'stopwatch', w:270, h:400, render:renderReadingLog, pro:true },
  { id:'ttsreader', labelKey:'ttsreader', icon:'mic', w:300, h:320, render:renderTtsReader, pro:true },
  { id:'unitconverter', labelKey:'unitconverter', icon:'swap', w:270, h:300, render:renderUnitConverter, pro:true },
  { id:'announcements', labelKey:'announcements', icon:'bell', w:280, h:360, render:renderAnnouncements, pro:true },
  { id:'instructions', labelKey:'instructions', icon:'clipboard', w:300, h:340, render:renderInstructions, pro:true },
  { id:'convocards', labelKey:'convocards', icon:'chat', w:280, h:320, render:renderConvoCards, pro:true },
  { id:'idiomday', labelKey:'idiomday', icon:'quote', w:280, h:300, render:renderIdiomDay, pro:true },
  { id:'grammarref', labelKey:'grammarref', icon:'book', w:280, h:340, render:renderGrammarRef, pro:true }
];

const wall = document.getElementById('wall');
const dock = document.getElementById('dock');
const widgetEls = {}; // id -> {el, cleanup}

/* ---------------- Multi-dock placement (bottom/left/right) ----------------
   50+ widgets won't fit in one bar, so each widget lives in exactly one
   launcher: the bottom dock, the left drawer, the right drawer, the top
   dock (icon-only, left-justified right after the brand name), or hidden.
   Bottom holds up to 10, everywhere else holds up to 5. ---------------- */
const DOCK_CAPS = { bottom:10, left:5, right:5, top:5 };

function widgetsFor(loc){
  const list = WIDGETS.filter(w => state.dockPlacement[w.id] === loc);
  // Defensive cap at render time too, not just when a widget is newly
  // assigned — a widget added to the registry before caps existed, or a
  // state migrated before this fix, could otherwise carry more than
  // DOCK_CAPS[loc] entries. Anything past the cap simply doesn't render in
  // that dock; it's still reachable any time via the app tray.
  const cap = DOCK_CAPS[loc];
  return cap ? list.slice(0, cap) : list;
}
function placementCount(loc){ return widgetsFor(loc).length; }

function ensureDockPlacement(){
  const noneAssignedYet = Object.keys(state.dockPlacement).length === 0;
  let changed = false;
  // Track how many widgets have already landed in each capped dock so the
  // very first automatic assignment respects DOCK_CAPS too, instead of
  // splitting every non-bottom widget 50/50 into left/right regardless of
  // their 5-widget caps.
  const counts = { bottom:0, left:0, right:0, top:0 };
  WIDGETS.forEach(w=>{
    const p = state.dockPlacement[w.id];
    if(p && counts[p] !== undefined) counts[p]++;
  });
  let sideToggle = 0;
  WIDGETS.forEach(w=>{
    if(state.dockPlacement[w.id]) return; // already placed
    let target;
    if(noneAssignedYet){
      // First run migrating from the old single bottom-dock build: keep
      // every widget reachable — fill the bottom dock first (up to its own
      // cap), then alternate into the left/right drawers up to their caps.
      // Anything left over once every capped dock is full goes to 'hidden' —
      // still reachable any time via the app tray.
      if(state.dockVisible[w.id] === false){
        target = 'hidden';
      } else if(counts.bottom < DOCK_CAPS.bottom){
        target = 'bottom';
      } else {
        const trySide = (sideToggle % 2 === 0) ? 'left' : 'right';
        const otherSide = trySide === 'left' ? 'right' : 'left';
        if(counts[trySide] < DOCK_CAPS[trySide]) target = trySide;
        else if(counts[otherSide] < DOCK_CAPS[otherSide]) target = otherSide;
        else target = 'hidden';
        sideToggle++;
      }
    } else {
      // A widget added to the registry later than the user's saved state.
      target = 'hidden';
    }
    state.dockPlacement[w.id] = target;
    counts[target] = (counts[target] || 0) + 1;
    changed = true;
  });
  if(changed) saveState();
}

function makeDockButton(w){
  const btn = document.createElement('button');
  btn.className = 'dock-item' + (state.active[w.id] ? ' active' : '');
  btn.dataset.id = w.id;
  btn.innerHTML = `<span class="dock-ic">${iconSvg(w.icon)}</span><span data-i18n="${w.labelKey}">${t(w.labelKey)}</span>`;
  btn.addEventListener('click', ()=> toggleWidget(w.id));
  return btn;
}

function buildDock(){
  dock.innerHTML = '';
  widgetsFor('bottom').forEach(w=> dock.appendChild(makeDockButton(w)));
  // Settings used to live here as the last bottom-dock item; it now lives in
  // the top pill row (see SETTINGS_PILL / buildTopDock()) instead.
  dock.classList.toggle('hover-collapsible', !!state.hoverOpen);
}

/* ---------------- Layout modes ----------------
   Compact/Comfortable are presets that decide dock *visibility* for the
   left/right drawers automatically; Custom hands that decision back to the
   per-drawer toggles in Settings. None of this touches state.dockPlacement —
   a widget's assigned dock is unchanged, only whether that dock is shown. */
const LAYOUT_MODES = ['compact','comfortable','custom'];

function effectiveSideVisible(side){ // 'left' | 'right'
  if(state.layoutMode === 'compact') return false;
  if(state.layoutMode === 'comfortable') return true;
  return state.edgeDock[side].visible;
}

function buildSideDock(side){ // 'left' | 'right'
  const wrapper = document.getElementById(`dock-${side}`);
  const box = document.getElementById(`dock-${side}-items`);
  box.innerHTML = '';
  widgetsFor(side).forEach(w=> box.appendChild(makeDockButton(w)));
  wrapper.hidden = !effectiveSideVisible(side);
  wrapper.classList.toggle('hover-collapsible', !!state.hoverOpen);
}

function buildLayoutModeSelector(){
  const grid = document.getElementById('layout-mode-grid');
  if(!grid) return;
  grid.innerHTML = '';
  LAYOUT_MODES.forEach(mode=>{
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'layout-mode-opt' + (state.layoutMode === mode ? ' active' : '');
    btn.dataset.mode = mode;
    btn.innerHTML = `
      <span class="layout-mode-name" data-i18n="layout_mode_${mode}">${t('layout_mode_'+mode)}</span>
      <span class="layout-mode-desc" data-i18n="layout_mode_${mode}_desc">${t('layout_mode_'+mode+'_desc')}</span>
    `;
    btn.addEventListener('click', ()=>{
      if(state.layoutMode === mode) return;
      state.layoutMode = mode;
      saveState();
      rebuildAllDocks();
      buildLayoutModeSelector();
      buildDrawerSettings();
      buildDockPlacementList();
    });
    grid.appendChild(btn);
  });
}

/* ---------------- App tray (Android-style "show every widget" sheet) ----------------
   Independent of layout mode and dockPlacement — always lists every widget
   in WIDGETS, so it's the one guaranteed way to reach a widget whose dock
   is currently hidden (e.g. everything but the bottom dock in Compact mode). */
function makeAppTrayButton(w){
  const btn = document.createElement('button');
  btn.className = 'app-tray-item' + (state.active[w.id] ? ' active' : '');
  btn.dataset.id = w.id;
  btn.innerHTML = `<span class="dock-ic">${iconSvg(w.icon)}</span><span data-i18n="${w.labelKey}">${t(w.labelKey)}</span>`;
  btn.addEventListener('click', ()=> toggleWidget(w.id));
  return btn;
}

function buildAppTray(){
  const grid = document.getElementById('app-tray-grid');
  if(!grid) return;
  grid.innerHTML = '';
  WIDGETS.forEach(w=> grid.appendChild(makeAppTrayButton(w)));
}

function openAppTray(){
  const backdrop = document.getElementById('app-tray-backdrop');
  const tab = document.getElementById('app-tray-tab');
  if(!backdrop || !tab) return;
  backdrop.hidden = false;
  tab.classList.add('open');
  tab.setAttribute('aria-expanded','true');
}
function closeAppTray(){
  const backdrop = document.getElementById('app-tray-backdrop');
  const tab = document.getElementById('app-tray-tab');
  if(!backdrop || !tab) return;
  backdrop.hidden = true;
  tab.classList.remove('open');
  tab.setAttribute('aria-expanded','false');
}
function wireAppTray(){
  const tab = document.getElementById('app-tray-tab');
  const backdrop = document.getElementById('app-tray-backdrop');
  const handle = document.getElementById('app-tray-handle');
  if(!tab || !backdrop || !handle) return;
  tab.addEventListener('click', ()=>{ backdrop.hidden ? openAppTray() : closeAppTray(); });
  handle.addEventListener('click', closeAppTray);
  backdrop.addEventListener('click', e=>{ if(e.target === backdrop) closeAppTray(); });
  document.addEventListener('keydown', e=>{ if(e.key === 'Escape' && !backdrop.hidden) closeAppTray(); });
}

function makeTopDockButton(w){
  // Icon-only (no label) so it fits the header's height; the widget name
  // shows as a tooltip/aria-label instead. Recreated fresh on every rebuild —
  // unlike the pill drawer, these buttons carry no state of their own, so
  // there's no risk of the "moved singleton" bug that hit the lang/theme pills.
  const btn = document.createElement('button');
  btn.className = 'dock-top-item' + (state.active[w.id] ? ' active' : '');
  btn.dataset.id = w.id;
  btn.title = t(w.labelKey);
  btn.setAttribute('aria-label', t(w.labelKey));
  btn.innerHTML = iconSvg(w.icon);
  btn.addEventListener('click', ()=> toggleWidget(w.id));
  return btn;
}

function buildTopWidgetDock(){
  const box = document.getElementById('dock-top-widgets');
  box.innerHTML = '';
  widgetsFor('top').forEach(w=> box.appendChild(makeTopDockButton(w)));
}

/* ---------------- Top pill drawer (translate / theme / future toggles) ----------------
   A single left-justified row, capped at 5 slots — anchored to the top-right
   so it never sits over the brand mark on the left. ---------------- */
const PILL_CAP = 5;
const PILLS = [
  { id:'classes', el: ()=> document.getElementById('class-pill-wrap') },
  { id:'lang', el: ()=> document.getElementById('lang-toggle') },
  { id:'theme', el: ()=> document.getElementById('btn-theme') }
];
// Settings pill: always shown, always last (far right) in whichever row the
// pills currently live in. Deliberately kept out of PILLS/pillsInTop() so it
// can't be capped out by PILL_CAP or reassigned to 'hidden' from the "Top bar
// pills" picker — Settings needs to always be reachable.
const SETTINGS_PILL = { el: ()=> document.getElementById('btn-settings') };
function pillsInTop(){
  return PILLS.filter(p => (state.pillPlacement[p.id] || 'top') === 'top').slice(0, PILL_CAP);
}

function buildTopDock(){
  // IMPORTANT: the language-toggle and theme-button elements are singletons
  // (they carry their own live click handlers/state) that get *moved* between
  // the header and this drawer, never recreated. Never clear their container
  // with innerHTML — that destroys the actual nodes, and every getElementById
  // lookup after that returns null, permanently disappearing the pills. Just
  // appendChild() each one to wherever it belongs; appendChild moves a node
  // that's already in the document rather than duplicating it.
  const wrapper = document.getElementById('dock-top');
  const box = document.getElementById('pills-top');
  const topActions = document.querySelector('.top-actions');

  const settingsEl = SETTINGS_PILL.el();

  if(!state.edgeDock.top.visible){
    wrapper.hidden = true;
    PILLS.forEach(p=>{ const el = p.el(); if(el) topActions.appendChild(el); });
    if(settingsEl) topActions.appendChild(settingsEl); // appended last = rightmost
    buildClassPill();
    return;
  }
  wrapper.hidden = false;
  wrapper.classList.toggle('hover-collapsible', !!state.hoverOpen);
  const inTop = new Set(pillsInTop().map(p=> p.id));
  PILLS.forEach(p=>{
    const el = p.el();
    if(!el) return;
    if(inTop.has(p.id)) box.appendChild(el);
    else topActions.appendChild(el); // placed 'hidden' — still needs a home in the DOM
  });
  if(settingsEl) box.appendChild(settingsEl); // appended last = rightmost in the pill row
  buildClassPill(); // the class pill may have just moved rows — re-side its menu
}

function rebuildAllDocks(){
  buildDock();
  buildSideDock('left');
  buildSideDock('right');
  buildTopWidgetDock();
  buildTopDock();
  buildAppTray();
}

const PLACEMENT_OPTIONS = ['bottom','left','right','top','hidden'];

function buildDockPlacementList(){
  const box = document.getElementById('dock-vis-list');
  box.innerHTML = '';
  const locked = state.layoutMode !== 'custom';
  const lockHint = document.getElementById('dock-buttons-lock-hint');
  if(lockHint) lockHint.hidden = !locked;
  WIDGETS.forEach(w=>{
    const row = document.createElement('div');
    row.className = 'dock-vis-row placement-row' + (locked ? ' locked' : '');
    row.innerHTML = `<span data-i18n="${w.labelKey}">${t(w.labelKey)}</span>`;
    const sel = document.createElement('select');
    sel.disabled = locked;
    PLACEMENT_OPTIONS.forEach(opt=>{
      const o = document.createElement('option');
      o.value = opt;
      o.setAttribute('data-i18n', 'placement_'+opt);
      o.textContent = t('placement_'+opt);
      sel.appendChild(o);
    });
    sel.value = state.dockPlacement[w.id] || 'hidden';
    sel.addEventListener('change', ()=>{
      const target = sel.value;
      if(target !== 'hidden' && placementCount(target) >= DOCK_CAPS[target]){
        toast(t('drawer_full_toast', { side: t('placement_'+target), max: DOCK_CAPS[target] }));
        sel.value = state.dockPlacement[w.id] || 'hidden';
        return;
      }
      state.dockPlacement[w.id] = target;
      saveState();
      rebuildAllDocks();
    });
    row.appendChild(sel);
    box.appendChild(row);
  });
}

function buildDrawerSettings(){
  // NOTE: unlike buildDockPlacementList (which rebuilds fresh <select>
  // elements every call), these checkboxes/selects are static nodes from
  // index.html that this function now re-visits every time the layout mode
  // changes — so listeners are assigned via .onchange (idempotent) rather
  // than .addEventListener (which would stack a new handler on every call).
  const leftChk = document.getElementById('drawer-left-visible');
  const rightChk = document.getElementById('drawer-right-visible');
  const topChk = document.getElementById('drawer-top-visible');
  const hoverChk = document.getElementById('drawer-hover-open');
  const locked = state.layoutMode !== 'custom';

  leftChk.checked = effectiveSideVisible('left');
  rightChk.checked = effectiveSideVisible('right');
  topChk.checked = state.edgeDock.top.visible;
  hoverChk.checked = state.hoverOpen;

  leftChk.disabled = locked;
  rightChk.disabled = locked;
  leftChk.closest('.switch-row').classList.toggle('locked', locked);
  rightChk.closest('.switch-row').classList.toggle('locked', locked);
  const lockHint = document.getElementById('drawers-lock-hint');
  if(lockHint) lockHint.hidden = !locked;

  leftChk.onchange = e=>{ state.edgeDock.left.visible = e.target.checked; saveState(); rebuildAllDocks(); };
  rightChk.onchange = e=>{ state.edgeDock.right.visible = e.target.checked; saveState(); rebuildAllDocks(); };
  topChk.onchange = e=>{ state.edgeDock.top.visible = e.target.checked; saveState(); rebuildAllDocks(); };
  hoverChk.onchange = e=>{ state.hoverOpen = e.target.checked; saveState(); rebuildAllDocks(); };

  const langSel = document.getElementById('pill-place-lang');
  const themeSel = document.getElementById('pill-place-theme');
  langSel.value = state.pillPlacement.lang || 'top';
  themeSel.value = state.pillPlacement.theme || 'top';
  const classSel = document.getElementById('pill-place-classes');
  classSel.value = state.pillPlacement.classes || 'top';
  [['classes', classSel], ['lang', langSel], ['theme', themeSel]].forEach(([id, sel])=>{
    sel.onchange = ()=>{
      const target = sel.value;
      if(target === 'top' && pillsInTop().length >= PILL_CAP && state.pillPlacement[id] !== 'top'){
        toast(t('drawer_full_toast', { side: t('pills_section'), max: PILL_CAP }));
        sel.value = state.pillPlacement[id] || 'top';
        return;
      }
      state.pillPlacement[id] = target;
      saveState();
      buildTopDock();
      buildClassPill();
    };
  });
}

function rerenderWidget(id){
  const rec = widgetEls[id];
  if(!rec) return;
  const def = WIDGETS.find(w=>w.id===id);
  if(!def) return;
  if(typeof rec.cleanup === 'function') rec.cleanup();
  const body = rec.el.querySelector('.widget-body');
  body.innerHTML = '';
  rec.cleanup = def.render(body, { id, toast });
}

const CAL_SYSTEM_OPTIONS = [
  { value:'gregorian', key:'cal_sys_gregorian' },
  { value:'lunar', key:'cal_sys_lunar' },
  { value:'both', key:'cal_sys_both' }
];

function buildCalendarSystemSelect(){
  const sel = document.getElementById('calendar-system-select');
  sel.innerHTML = CAL_SYSTEM_OPTIONS.map(o=>`<option value="${o.value}" data-i18n="${o.key}">${t(o.key)}</option>`).join('');
  sel.value = state.calendarSystem;
  sel.addEventListener('change', ()=>{
    state.calendarSystem = sel.value;
    saveState();
    rerenderWidget('clock');
    rerenderWidget('calendar');
  });
}

function toggleWidget(id){
  if(!state.active[id] && isProWidget(id) && !isPro()){
    openProModal(id);
    return;
  }
  if(state.active[id]){
    closeWidget(id);
  }else{
    openWidget(id);
  }
  saveState();
  syncDock();
}
function syncDock(){
  document.querySelectorAll('.dock-item[data-id], .dock-top-item[data-id], .app-tray-item[data-id]').forEach(b=>{
    b.classList.toggle('active', !!state.active[b.dataset.id]);
  });
}

function openWidget(id){
  const def = WIDGETS.find(w=>w.id===id);
  if(!def || widgetEls[id]) { state.active[id]=true; return; }
  state.active[id] = true;

  const layout = state.layout[id] || defaultLayout(def);
  state.layout[id] = layout;

  const el = document.createElement('section');
  el.className = 'widget' + (layout.minimized ? ' minimized' : '');
  el.style.left = layout.x+'px';
  el.style.top = layout.y+'px';
  el.style.width = layout.w+'px';
  if(layout.h && !layout.minimized) el.style.height = layout.h+'px';
  el.innerHTML = `
    <div class="widget-head">
      <button class="widget-drag" aria-label="${t('move_action')}" data-i18n-aria="move_action">${iconSvg('grip','wsvg')}</button>
      <span class="widget-title" data-i18n="${def.labelKey}">${t(def.labelKey)}</span>
      <div class="widget-head-actions">
        <button class="widget-min" data-i18n-aria-dyn data-key="${layout.minimized ? 'restore_action' : 'minimize_action'}" aria-label="${t(layout.minimized ? 'restore_action' : 'minimize_action')}">${iconSvg(layout.minimized ? 'restore' : 'minimize','wsvg')}</button>
        <button class="widget-close" aria-label="${t('close')}" data-i18n-aria="close">${iconSvg('close','wsvg')}</button>
      </div>
    </div>
    <div class="widget-body"></div>
    <div class="widget-resize"><svg viewBox="0 0 14 14"><path d="M12 2L2 12M12 7L7 12M12 12h0" stroke="currentColor" stroke-width="1.4"/></svg></div>
  `;
  wall.appendChild(el);
  widgetEls[id] = { el, cleanup:null };

  makeDraggable(el, id);
  makeResizable(el, id);
  el.querySelector('.widget-close').addEventListener('click', ()=>{
    toggleWidget(id);
  });
  el.querySelector('.widget-min').addEventListener('click', ()=>{
    toggleMinimize(id);
  });

  const body = el.querySelector('.widget-body');
  const cleanup = def.render(body, { id, toast });
  widgetEls[id].cleanup = cleanup;
}

function toggleMinimize(id){
  const rec = widgetEls[id];
  const layout = state.layout[id];
  if(!rec || !layout) return;
  const minBtn = rec.el.querySelector('.widget-min');
  if(!layout.minimized){
    layout.prevH = rec.el.offsetHeight;
    layout.minimized = true;
    rec.el.classList.add('minimized');
    rec.el.style.height = '';
  } else {
    layout.minimized = false;
    rec.el.classList.remove('minimized');
    rec.el.style.height = (layout.prevH || layout.h || 200) + 'px';
  }
  minBtn.innerHTML = iconSvg(layout.minimized ? 'restore' : 'minimize','wsvg');
  minBtn.dataset.key = layout.minimized ? 'restore_action' : 'minimize_action';
  minBtn.setAttribute('aria-label', t(minBtn.dataset.key));
  saveState();
}

function closeWidget(id){
  state.active[id] = false;
  const rec = widgetEls[id];
  if(rec){
    if(typeof rec.cleanup === 'function') rec.cleanup();
    rec.el.remove();
    delete widgetEls[id];
  }
}

function defaultLayout(def){
  const usedCount = Object.keys(state.layout).length;
  return {
    x: 24 + (usedCount % 4) * 40,
    y: 90 + (usedCount % 4) * 34,
    w: def.w, h: def.h
  };
}

/* ---------------- Drag + resize ----------------
   Dragging used to stop after a pixel or two: the pointerdown handler called
   wall.appendChild(el) to bring the panel to the front, which removes and
   re-inserts the node — and re-inserting the element holding the pointer
   capture makes the browser release that capture and fire pointercancel, so
   the drag ended immediately. Fixed by bringing panels forward with a z-index
   counter instead (no DOM move), tracking the gesture in one window-level
   handler so a lost capture can't strand it, and making the whole title bar
   draggable rather than just the small grip.
   ---------------------------------------------------------------- */
let topZ = 10;
function bringToFront(el){ el.style.zIndex = ++topZ; }

// One gesture at a time, tracked here; the window listeners below are the only
// ones, so closing a widget can't leave handlers behind.
let gesture = null;   // { kind:'move'|'size', el, id, pointerId, sx, sy, ox, oy }

function startGesture(g){
  gesture = g;
  bringToFront(g.el);
  if(g.kind === 'move') g.el.classList.add('dragging');
}

function moveGesture(e){
  if(!gesture || e.pointerId !== gesture.pointerId) return;
  const g = gesture;
  const dx = e.clientX - g.sx, dy = e.clientY - g.sy;
  if(g.kind === 'move'){
    // Keep the panel reachable: never past the top or left edge, and always
    // leave enough of the title bar on screen (roughly the grip and the start
    // of the title) that it can be grabbed and dragged back.
    const maxX = Math.max(0, wall.clientWidth - 150);
    const maxY = Math.max(0, wall.clientHeight - 44);
    g.el.style.left = Math.min(maxX, Math.max(0, g.ox + dx)) + 'px';
    g.el.style.top  = Math.min(maxY, Math.max(0, g.oy + dy)) + 'px';
  } else {
    g.el.style.width  = Math.max(180, g.ox + dx) + 'px';
    g.el.style.height = Math.max(140, g.oy + dy) + 'px';
  }
}

function endGesture(e){
  if(!gesture) return;
  if(e && e.pointerId !== undefined && e.pointerId !== gesture.pointerId) return;
  const g = gesture;
  gesture = null;
  g.el.classList.remove('dragging');
  const layout = state.layout[g.id];
  if(layout){
    if(g.kind === 'move'){
      // offsetLeft/Top are relative to the wall, the same frame the saved
      // left/top are written in — getBoundingClientRect would be viewport-based.
      layout.x = g.el.offsetLeft;
      layout.y = g.el.offsetTop;
    } else {
      layout.w = g.el.offsetWidth;
      layout.h = g.el.offsetHeight;
    }
    saveState();
  }
}

window.addEventListener('pointermove', moveGesture);
window.addEventListener('pointerup', endGesture);
window.addEventListener('pointercancel', endGesture);
window.addEventListener('blur', ()=> endGesture());

function makeDraggable(el, id){
  const head = el.querySelector('.widget-head');
  head.addEventListener('pointerdown', e=>{
    if(e.button != null && e.button !== 0) return;         // left button or touch only
    if(e.target.closest('.widget-head-actions')) return;    // minimise + close stay clickable
    startGesture({ kind:'move', el, id, pointerId:e.pointerId, sx:e.clientX, sy:e.clientY, ox:el.offsetLeft, oy:el.offsetTop });
    try{ head.setPointerCapture(e.pointerId); }catch(err){ /* capture is a nicety, not a requirement */ }
    e.preventDefault();
  });
  // Touching a panel anywhere raises it, so the one you're using sits on top.
  el.addEventListener('pointerdown', ()=> bringToFront(el));
}

function makeResizable(el, id){
  const handle = el.querySelector('.widget-resize');
  handle.addEventListener('pointerdown', e=>{
    if(e.button != null && e.button !== 0) return;
    startGesture({ kind:'size', el, id, pointerId:e.pointerId, sx:e.clientX, sy:e.clientY, ox:el.offsetWidth, oy:el.offsetHeight });
    try{ handle.setPointerCapture(e.pointerId); }catch(err){}
    e.preventDefault();
    e.stopPropagation();
  });
}

/* ---------------- Widget implementations ---------------- */

function renderClock(body){
  body.innerHTML = `
    <div class="clock-face">
      <div class="clock-hand hr"></div>
      <div class="clock-hand min"></div>
      <div class="clock-hand sec"></div>
      <div class="clock-dot"></div>
    </div>
    <div class="clock-digital">--:--</div>
    <div class="clock-date">--</div>
    <div class="clock-lunar"></div>
  `;
  const hr = body.querySelector('.hr'), min = body.querySelector('.min'), sec = body.querySelector('.sec');
  const digital = body.querySelector('.clock-digital'), dateEl = body.querySelector('.clock-date');
  const lunarEl = body.querySelector('.clock-lunar');
  function tick(){
    const d = new Date();
    const h = d.getHours()%12, m = d.getMinutes(), s = d.getSeconds();
    hr.style.transform = `rotate(${h*30 + m*0.5}deg)`;
    min.style.transform = `rotate(${m*6}deg)`;
    sec.style.transform = `rotate(${s*6}deg)`;
    let hh = d.getHours()%12; if(hh===0) hh=12;
    digital.textContent = `${hh}:${String(m).padStart(2,'0')} ${d.getHours()>=12?'PM':'AM'}`;
    if(state.calendarSystem === 'lunar'){
      dateEl.textContent = lunarFullLabel(d);
      lunarEl.textContent = '';
    } else {
      dateEl.textContent = d.toLocaleDateString(LOCALE_MAP[state.lang] || 'en-US', {weekday:'short', month:'short', day:'numeric'});
      lunarEl.textContent = state.calendarSystem === 'both' ? lunarFullLabel(d) : '';
    }
  }
  tick();
  const iv = setInterval(tick, 1000);
  return ()=>clearInterval(iv);
}

function renderTimer(body){
  body.innerHTML = `
    <div class="big-readout">05:00</div>
    <div class="btn-row" style="margin-bottom:10px">
      <button class="wbtn" data-m="-1">-1m</button>
      <button class="wbtn" data-m="1">+1m</button>
      <button class="wbtn" data-m="5">+5m</button>
    </div>
    <div class="btn-row">
      <button class="wbtn primary" id="t-start" data-i18n-dyn data-key="start">${t('start')}</button>
      <button class="wbtn" id="t-reset" data-i18n="reset_btn">${t('reset_btn')}</button>
    </div>
  `;
  let total = 300, remaining = 300, running=false, iv=null;
  const readout = body.querySelector('.big-readout');
  function render(){
    const m = Math.floor(remaining/60), s = remaining%60;
    readout.textContent = `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  }
  body.querySelectorAll('[data-m]').forEach(b=>{
    b.addEventListener('click', ()=>{
      const delta = parseInt(b.dataset.m)*60;
      total = Math.max(60, total+delta);
      if(!running) remaining = total;
      render();
    });
  });
  const startBtn = body.querySelector('#t-start');
  function setRunning(isRunning){
    running = isRunning;
    startBtn.dataset.key = running ? 'pause' : 'start';
    startBtn.textContent = t(startBtn.dataset.key);
  }
  startBtn.addEventListener('click', ()=>{
    if(!running){
      if(total<=0){ toast(t('timer_add_time')); return; }
      if(remaining<=0) remaining = total;
    }
    setRunning(!running);
    if(running){
      iv = setInterval(()=>{
        remaining--;
        if(remaining<=0){ remaining=0; setRunning(false); clearInterval(iv); toast(t('time_up')); }
        render();
      },1000);
    } else clearInterval(iv);
  });
  body.querySelector('#t-reset').addEventListener('click', ()=>{
    // Fully clear the cached duration, not just the countdown — otherwise
    // hitting Start again silently resumes the old number instead of
    // requiring a fresh +1m/+5m before it can run.
    clearInterval(iv); setRunning(false); total = 0; remaining = 0; render();
  });
  render();
  return ()=>clearInterval(iv);
}

function renderStopwatch(body){
  body.innerHTML = `
    <div class="big-readout">00:00.0</div>
    <div class="btn-row">
      <button class="wbtn primary" id="s-start" data-i18n-dyn data-key="start">${t('start')}</button>
      <button class="wbtn" id="s-lap" data-i18n="lap">${t('lap')}</button>
      <button class="wbtn" id="s-reset" data-i18n="reset_btn">${t('reset_btn')}</button>
    </div>
    <ul class="lap-list" id="s-laps"></ul>
  `;
  let elapsed=0, running=false, iv=null, last=0, laps=[];
  const readout = body.querySelector('.big-readout');
  const lapsEl = body.querySelector('#s-laps');
  function fmt(ms){
    const cs = Math.floor(ms/100);
    const m = Math.floor(cs/600), s = Math.floor(cs/10)%60, d = cs%10;
    return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}.${d}`;
  }
  function render(){ readout.textContent = fmt(elapsed); }
  function renderLaps(){
    lapsEl.innerHTML = laps.map((lapMs, i)=>{
      const prev = i>0 ? laps[i-1] : 0;
      return `<li><span>${t('lap')} ${i+1}</span><span>${fmt(lapMs-prev)}</span><span class="lap-total">${fmt(lapMs)}</span></li>`;
    }).reverse().join('');
  }
  const startBtn = body.querySelector('#s-start');
  const lapBtn = body.querySelector('#s-lap');
  function setRunning(isRunning){
    running = isRunning;
    startBtn.dataset.key = running ? 'stop' : 'start';
    startBtn.textContent = t(startBtn.dataset.key);
    lapBtn.disabled = !running;
  }
  startBtn.addEventListener('click', ()=>{
    setRunning(!running);
    if(running){
      last = Date.now();
      iv = setInterval(()=>{
        const now = Date.now();
        elapsed += now-last; last = now;
        render();
      },100);
    } else clearInterval(iv);
  });
  lapBtn.addEventListener('click', ()=>{
    if(!running) return;
    laps.push(elapsed);
    renderLaps();
  });
  body.querySelector('#s-reset').addEventListener('click', ()=>{
    clearInterval(iv); setRunning(false); elapsed=0; laps=[]; render(); renderLaps();
  });
  setRunning(false);
  render();
  renderLaps();
  return ()=>clearInterval(iv);
}

function renderTraffic(body){
  body.innerHTML = `
    <div class="traffic-housing">
      <div class="traffic-hood"></div>
      <div class="traffic-lamp red" data-c="red"></div>
      <div class="traffic-lamp yellow" data-c="yellow"></div>
      <div class="traffic-lamp green" data-c="green"></div>
      <div class="traffic-base"></div>
    </div>
    <p class="traffic-hint" data-i18n="traffic_hint">${t('traffic_hint')}</p>
  `;
  const lamps = body.querySelectorAll('.traffic-lamp');
  lamps.forEach(l=>{
    l.addEventListener('click', ()=>{
      lamps.forEach(x=>x.classList.remove('on'));
      l.classList.add('on');
    });
  });
  return null;
}

/* ---- Dice graphics ---- */
const PIP_LAYOUTS = {
  1:[[50,50]],
  2:[[26,26],[74,74]],
  3:[[26,26],[50,50],[74,74]],
  4:[[26,26],[74,26],[26,74],[74,74]],
  5:[[26,26],[74,26],[50,50],[26,74],[74,74]],
  6:[[26,22],[74,22],[26,50],[74,50],[26,78],[74,78]]
};
function d6Svg(value){
  const pips = PIP_LAYOUTS[value] || PIP_LAYOUTS[1];
  const dots = pips.map(([x,y])=>`<circle cx="${x}" cy="${y}" r="7.5" fill="#20242b"/>`).join('');
  return `<svg viewBox="0 0 100 100" class="die-face">
    <rect x="6" y="6" width="88" height="88" rx="16" fill="#F4F1EA" stroke="#cfc9b8" stroke-width="2"/>
    ${dots}
  </svg>`;
}
function d20Svg(value){
  // 10-point star-ish faceted outline standing in for a d20, with facet lines to center
  const cx=50, cy=52, R=42;
  const pts = [];
  for(let i=0;i<10;i++){
    const ang = (Math.PI*2*i/10) - Math.PI/2;
    const r = i%2===0 ? R : R*0.82;
    pts.push([cx+r*Math.cos(ang), cy+r*Math.sin(ang)]);
  }
  const outline = pts.map(p=>p.join(',')).join(' ');
  const facets = pts.map(p=>`<line x1="${cx}" y1="${cy}" x2="${p[0]}" y2="${p[1]}" stroke="#c78a2e" stroke-width="1"/>`).join('');
  return `<svg viewBox="0 0 100 104" class="die-face">
    <polygon points="${outline}" fill="#E8A33D" stroke="#8a5a1a" stroke-width="2.5" stroke-linejoin="round"/>
    ${facets}
    <text x="${cx}" y="${cy+8}" text-anchor="middle" font-family="Quicksand, sans-serif" font-weight="700" font-size="30" fill="#231604">${value}</text>
  </svg>`;
}
function diceFace(sides, value){ return sides===20 ? d20Svg(value) : d6Svg(value); }

function renderDice(body){
  body.innerHTML = `
    <div class="dice-stage" id="dice-stage"></div>
    <div class="btn-row">
      <button class="wbtn" data-sides="6">d6</button>
      <button class="wbtn" data-sides="20">d20</button>
      <button class="wbtn primary" id="dice-roll" data-i18n="roll">${t('roll')}</button>
    </div>
  `;
  let sides = 6;
  const stage = body.querySelector('#dice-stage');
  stage.innerHTML = diceFace(sides, 1);

  body.querySelectorAll('[data-sides]').forEach(b=>{
    b.addEventListener('click', ()=>{
      sides = parseInt(b.dataset.sides);
      stage.innerHTML = diceFace(sides, 1);
    });
  });
  body.querySelector('#dice-roll').addEventListener('click', ()=>{
    let n = 0;
    const iv = setInterval(()=>{
      const val = 1 + Math.floor(Math.random()*sides);
      stage.innerHTML = diceFace(sides, val);
      n++;
      if(n>10) clearInterval(iv);
    }, 60);
  });
  return null;
}

function renderChecklist(body){
  function draw(){
    body.innerHTML = `
      <div class="checklist-row">
        <input type="text" id="cl-input" placeholder="${t('add_placeholder')}" data-i18n-placeholder="add_placeholder">
        <button class="wbtn primary" id="cl-add" data-i18n="add_btn">${t('add_btn')}</button>
      </div>
      <ul class="check-items"></ul>
    `;
    const ul = body.querySelector('.check-items');
    state.checklist.forEach(item=>{
      const li = document.createElement('li');
      li.className = item.done ? 'done' : '';
      li.innerHTML = `<input type="checkbox" ${item.done?'checked':''}> <span></span><button aria-label="${t('remove')}">${iconSvg('close','wsvg')}</button>`;
      li.querySelector('span').textContent = item.text;
      li.querySelector('input').addEventListener('change', e=>{
        item.done = e.target.checked; saveState(); draw();
      });
      li.querySelector('button').addEventListener('click', ()=>{
        state.checklist = state.checklist.filter(x=>x.id!==item.id);
        saveState(); draw();
      });
      ul.appendChild(li);
    });
    body.querySelector('#cl-add').addEventListener('click', addItem);
    body.querySelector('#cl-input').addEventListener('keydown', e=>{ if(e.key==='Enter') addItem(); });
    function addItem(){
      const input = body.querySelector('#cl-input');
      const text = input.value.trim();
      if(!text) return;
      state.checklist.push({ id:cid(), text, done:false });
      saveState(); draw();
    }
  }
  draw();
  return null;
}

function renderNamePicker(body){
  body.innerHTML = `
    <div class="picker-name" data-i18n="tap_pick">${t('tap_pick')}</div>
    <div class="btn-row">
      <button class="wbtn primary" id="np-pick" data-i18n="pick_student">${t('pick_student')}</button>
    </div>
    <p class="picker-count" data-i18n-count></p>
  `;
  const nameEl = body.querySelector('.picker-name');
  const countEl = body.querySelector('.picker-count');
  function refreshCount(){
    countEl.textContent = t('roster_count', { n: state.roster.length });
  }
  body.querySelector('#np-pick').addEventListener('click', ()=>{
    if(!state.roster.length){
      nameEl.removeAttribute('data-i18n');
      nameEl.textContent = t('add_students_prompt');
      return;
    }
    let n=0;
    const iv = setInterval(()=>{
      nameEl.removeAttribute('data-i18n');
      nameEl.textContent = state.roster[Math.floor(Math.random()*state.roster.length)];
      n++;
      if(n>10) clearInterval(iv);
    }, 60);
  });
  refreshCount();
  return null;
}

const EXT_LABEL = { pdf:'PDF', ppt:'PPT', pptx:'PPT', doc:'DOC', docx:'DOC', xls:'XLS', xlsx:'XLS' };
function extOf(name){
  const m = /\.([a-z0-9]+)$/i.exec(name);
  return m ? m[1].toLowerCase() : '';
}

function renderFiles(body){
  body.innerHTML = `
    <div class="file-drop"><button type="button" class="file-drop-browse" id="file-browse">${iconSvg('plus','wsvg')}<span data-i18n="browse_btn">${t('browse_btn')}</span></button></div>
    <input type="file" id="file-input" hidden multiple accept=".pdf,.ppt,.pptx,.doc,.docx,.xls,.xlsx">
    <ul class="file-list"></ul>
  `;
  const list = body.querySelector('.file-list');
  const input = body.querySelector('#file-input');
  body.querySelector('#file-browse').addEventListener('click', ()=> input.click());

  async function draw(){
    const files = await idb.getAll('files');
    list.innerHTML = '';
    if(!files.length){
      list.innerHTML = `<li class="file-empty" data-i18n="files_empty">${t('files_empty')}</li>`;
      return;
    }
    files.forEach(f=>{
      const li = document.createElement('li');
      const label = EXT_LABEL[extOf(f.name)] || extOf(f.name).toUpperCase() || 'FILE';
      li.innerHTML = `<span class="ftype">${label}</span><span class="fname"></span><button aria-label="${t('open_action')}">↗</button><button aria-label="${t('remove')}">${iconSvg('close','wsvg')}</button>`;
      li.querySelector('.fname').textContent = f.name;
      const [openBtn, delBtn] = li.querySelectorAll('button');
      openBtn.addEventListener('click', ()=>{
        const url = URL.createObjectURL(f.blob);
        window.open(url, '_blank');
      });
      delBtn.addEventListener('click', async ()=>{
        await idb.delete('files', f.id);
        draw();
      });
      list.appendChild(li);
    });
  }

  input.addEventListener('change', async ()=>{
    for(const file of input.files){
      await idb.put('files', { id:cid(), name:file.name, blob:file, added:Date.now() });
    }
    input.value = '';
    draw();
    toast(t('file_added'));
  });

  draw();
  return null;
}

function renderGames(body){
  body.innerHTML = `
    <div class="file-drop"><button type="button" class="file-drop-browse" id="game-browse">${iconSvg('plus','wsvg')}<span data-i18n="browse_btn">${t('browse_btn')}</span></button></div>
    <input type="file" id="game-input" hidden multiple accept=".html,.htm">
    <p class="drawer-label" data-i18n="games_mine">${t('games_mine')}</p>
    <div class="game-grid"></div>
    <p class="file-empty" style="margin-top:6px" data-i18n="games_note">${t('games_note')}</p>
    <div class="games-builtin-section" hidden>
      <p class="drawer-label" data-i18n="games_builtin">${t('games_builtin')}</p>
      <div class="game-grid builtin-game-grid"></div>
    </div>
  `;
  const grid = body.querySelector('.game-grid:not(.builtin-game-grid)');
  const input = body.querySelector('#game-input');
  body.querySelector('#game-browse').addEventListener('click', ()=> input.click());
  const builtinSection = body.querySelector('.games-builtin-section');
  const builtinGrid = body.querySelector('.builtin-game-grid');

  function launch(g){
    const url = URL.createObjectURL(g.blob);
    window.open(url, '_blank');
  }

  // Built-in games: static files dropped into the games/ folder (see
  // games/README.md), listed in games/games.json. Fetched relative to the
  // app's own location, so this only works when served over http(s) or
  // loaded as the Chrome extension — same requirement as the rest of the
  // app. Fails silently (and just shows nothing) when opened as a bare
  // double-clicked index.html file, since the browser blocks that fetch.
  async function drawBuiltin(){
    let list = [];
    try{
      const res = await fetch('games/games.json');
      if(res.ok) list = await res.json();
    }catch(e){ /* not served over http(s)/extension — no built-in games section */ }
    if(!Array.isArray(list) || !list.length){ builtinSection.hidden = true; return; }
    builtinSection.hidden = false;
    builtinGrid.innerHTML = '';
    list.forEach(g=>{
      if(!g || !g.folder || !g.entry) return;
      const tile = document.createElement('button');
      tile.className = 'game-tile';
      tile.title = `${t('play')} ${g.name || g.folder}`;
      tile.innerHTML = `
        ${g.instructions ? `<span class="game-tile-help" aria-label="${t('how_to_play')} ${g.name || g.folder}">?</span>` : ''}
        <span class="game-tile-play">${iconSvg('game')}</span>
        <span class="game-tile-name"></span>
      `;
      tile.querySelector('.game-tile-name').textContent = g.name || g.folder;
      tile.addEventListener('click', async ()=>{
        const url = `games/${g.folder}/${g.entry}`;
        // Verify the file is actually reachable before opening a new tab —
        // window.open() itself can't report a 404, so without this check a
        // bad hosting context (single-file artifact, opened via file://,
        // wrong server root) just opens a blank/broken tab with no
        // explanation. See games_unreachable_toast below.
        try{
          const res = await fetch(url, { method:'HEAD' });
          if(!res.ok) throw new Error('not ok');
          window.open(url, '_blank');
        }catch(e){
          toast(t('games_unreachable_toast'));
        }
      });
      const helpBtn = tile.querySelector('.game-tile-help');
      if(helpBtn){
        helpBtn.addEventListener('click', async e=>{
          e.stopPropagation();
          const url = `games/${g.folder}/${g.instructions}`;
          try{
            const res = await fetch(url, { method:'HEAD' });
            if(!res.ok) throw new Error('not ok');
            window.open(url, '_blank');
          }catch(err){
            toast(t('games_unreachable_toast'));
          }
        });
      }
      builtinGrid.appendChild(tile);
    });
  }

  async function draw(){
    const games = await idb.getAll('games');
    grid.innerHTML = '';
    if(!games.length){
      grid.innerHTML = `<p class="file-empty" data-i18n="games_empty">${t('games_empty')}</p>`;
      return;
    }
    games.forEach(g=>{
      const tile = document.createElement('button');
      tile.className = 'game-tile';
      tile.title = `${t('play')} ${g.name}`;
      tile.innerHTML = `
        <span class="game-tile-remove" aria-label="${t('remove')} ${g.name}">${iconSvg('close','wsvg')}</span>
        <span class="game-tile-play">${iconSvg('game')}</span>
        <span class="game-tile-name"></span>
      `;
      tile.querySelector('.game-tile-name').textContent = g.name.replace(/\.(html?|HTML?)$/,'');
      tile.addEventListener('click', ()=> launch(g));
      tile.querySelector('.game-tile-remove').addEventListener('click', async e=>{
        e.stopPropagation();
        await idb.delete('games', g.id);
        draw();
      });
      grid.appendChild(tile);
    });
  }

  input.addEventListener('change', async ()=>{
    let firstAdded = null;
    for(const file of input.files){
      const rec = { id:cid(), name:file.name, blob:file, added:Date.now() };
      await idb.put('games', rec);
      if(!firstAdded) firstAdded = rec;
    }
    input.value = '';
    draw();
    if(firstAdded){
      toast(t('game_saved'));
      launch(firstAdded);
    }
  });

  draw();
  drawBuiltin();
  return null;
}

const SB_COLORS = ['#E4572E','#3B82C4','#D9A82E','#5C9A63'];

// ---------------- Scoreboard transfer (from games like Classroom Word Wheel) ----------------
// A game living in games/<folder>/ is same-origin with the app, so it can hand off
// scores via localStorage — the 'storage' event fires in this tab the instant another
// same-origin tab writes it, and checkScoreboardTransfer() catches anything sent while
// this tab wasn't open yet, the next time it loads.
const SB_TRANSFER_KEY = 'td_scoreboard_transfer';

function refreshScoreboardWidget(){
  const rec = widgetEls['scoreboard'];
  if(!rec) return;
  if(typeof rec.cleanup === 'function') rec.cleanup();
  const body = rec.el.querySelector('.widget-body');
  rec.cleanup = renderScoreboard(body);
}

function applyScoreboardTransfer(payload){
  if(!payload || !Array.isArray(payload.teams) || !payload.teams.length) return;
  state.scoreboard = payload.teams.map(team=>({
    name: String((team && team.name) || '').trim().slice(0,18) || 'Team',
    score: Number(team && team.score) || 0
  }));
  saveState();
  if(!state.active.scoreboard){
    openWidget('scoreboard');
  } else {
    refreshScoreboardWidget();
  }
  toast(t('sb_transfer_received') + (payload.from ? ` — ${payload.from}` : ''));
}

function checkScoreboardTransfer(){
  let raw;
  try{ raw = localStorage.getItem(SB_TRANSFER_KEY); }catch(e){ return; }
  if(!raw) return;
  try{ localStorage.removeItem(SB_TRANSFER_KEY); }catch(e){}
  try{ applyScoreboardTransfer(JSON.parse(raw)); }catch(e){ /* malformed payload — ignore */ }
}

window.addEventListener('storage', e=>{
  if(e.key === SB_TRANSFER_KEY && e.newValue) checkScoreboardTransfer();
});

function renderScoreboard(body){
  body.innerHTML = `
    <div class="sb">
      <p class="sb-sub" data-i18n="sb_sub">${t('sb_sub')}</p>
      <div class="sb-board"></div>
      <button class="sb-reset" data-i18n="sb_reset">${t('sb_reset')}</button>
    </div>
  `;
  const boardEl = body.querySelector('.sb-board');

  function draw(){
    const maxScore = Math.max(...state.scoreboard.map(team=>team.score));
    boardEl.innerHTML = '';
    state.scoreboard.forEach((team, i)=>{
      const card = document.createElement('div');
      const leading = maxScore > 0 && team.score === maxScore;
      card.className = 'sb-card' + (leading ? ' leading' : '');
      card.style.setProperty('--accent', SB_COLORS[i % SB_COLORS.length]);
      card.innerHTML = `
        <div class="sb-bar"></div>
        <div class="sb-row">
          <input class="sb-name" maxlength="18">
          <div class="sb-score"></div>
        </div>
        <div class="sb-btns">
          <button class="sb-btn minus" data-delta="-1">−1</button>
          <button class="sb-btn plus" data-delta="1">+1</button>
        </div>
      `;
      const nameInput = card.querySelector('.sb-name');
      const scoreEl = card.querySelector('.sb-score');
      nameInput.value = team.name;
      scoreEl.textContent = team.score;

      nameInput.addEventListener('change', ()=>{
        team.name = nameInput.value.trim() || team.name;
        saveState();
      });
      card.querySelectorAll('.sb-btn').forEach(btn=>{
        btn.addEventListener('click', ()=>{
          const delta = parseInt(btn.dataset.delta, 10);
          team.score = Math.max(0, team.score + delta);
          saveState();
          draw();
          const bumpEl = boardEl.children[i].querySelector('.sb-score');
          bumpEl.classList.remove('bump');
          void bumpEl.offsetWidth;
          bumpEl.classList.add('bump');
        });
      });
      boardEl.appendChild(card);
    });
  }

  body.querySelector('.sb-reset').addEventListener('click', ()=>{
    state.scoreboard.forEach(t=> t.score = 0);
    saveState();
    draw();
  });

  draw();
  return null;
}

/* ---------------- Lunar calendar conversion (Vietnamese/Chinese lunisolar, UTC+7) ---------------- */
const LUNAR_TZ = 7;
function INT(d){ return Math.floor(d); }

function jdFromDate(dd, mm, yy){
  const a = INT((14-mm)/12);
  const y = yy + 4800 - a;
  const m = mm + 12*a - 3;
  let jd = dd + INT((153*m+2)/5) + 365*y + INT(y/4) - INT(y/100) + INT(y/400) - 32045;
  if(jd < 2299161){
    jd = dd + INT((153*m+2)/5) + 365*y + INT(y/4) - 32083;
  }
  return jd;
}

function NewMoon(k){
  const T = k/1236.85, T2 = T*T, T3 = T2*T, dr = Math.PI/180;
  let Jd1 = 2415020.75933 + 29.53058868*k + 0.0001178*T2 - 0.000000155*T3;
  Jd1 += 0.00033*Math.sin((166.56+132.87*T-0.009173*T2)*dr);
  const M = 359.2242 + 29.10535608*k - 0.0000333*T2 - 0.00000347*T3;
  const Mpr = 306.0253 + 385.81691806*k + 0.0107306*T2 + 0.00001236*T3;
  const F = 21.2964 + 390.67050646*k - 0.0016528*T2 - 0.00000239*T3;
  let C1 = (0.1734-0.000393*T)*Math.sin(M*dr) + 0.0021*Math.sin(2*dr*M);
  C1 -= 0.4068*Math.sin(Mpr*dr) + 0.0161*Math.sin(dr*2*Mpr);
  C1 -= 0.0004*Math.sin(dr*3*Mpr);
  C1 += 0.0104*Math.sin(dr*2*F) - 0.0051*Math.sin(dr*(M+Mpr));
  C1 -= 0.0074*Math.sin(dr*(M-Mpr)) + 0.0004*Math.sin(dr*(2*F+M));
  C1 -= 0.0004*Math.sin(dr*(2*F-M)) - 0.0006*Math.sin(dr*(2*F+Mpr));
  C1 += 0.0010*Math.sin(dr*(2*F-Mpr)) + 0.0005*Math.sin(dr*(2*Mpr+M));
  let deltaT;
  if(T < -11) deltaT = 0.001 + 0.000839*T + 0.0002261*T2 - 0.00000845*T3 - 0.000000081*T*T3;
  else deltaT = -0.000278 + 0.000265*T + 0.000262*T2;
  return Jd1 + C1 - deltaT;
}

function sunLongitude(jdn){
  const T = (jdn - 2451545.0)/36525, T2 = T*T, dr = Math.PI/180;
  const M = 357.52910 + 35999.05030*T - 0.0001559*T2 - 0.00000048*T*T2;
  const L0 = 280.46645 + 36000.76983*T + 0.0003032*T2;
  let DL = (1.914600-0.004817*T-0.000014*T2)*Math.sin(dr*M);
  DL += (0.019993-0.000101*T)*Math.sin(dr*2*M) + 0.000290*Math.sin(dr*3*M);
  let L = (L0+DL)*dr;
  L -= Math.PI*2*INT(L/(Math.PI*2));
  return L;
}

function getSunLongitude(dayNumber, tz){ return INT(sunLongitude(dayNumber - 0.5 - tz/24) / Math.PI * 6); }
function getNewMoonDay(k, tz){ return INT(NewMoon(k) + 0.5 + tz/24); }

function getLunarMonth11(yy, tz){
  const off = jdFromDate(31,12,yy) - 2415021;
  const k = INT(off/29.530588853);
  let nm = getNewMoonDay(k, tz);
  if(getSunLongitude(nm, tz) >= 9) nm = getNewMoonDay(k-1, tz);
  return nm;
}

function getLeapMonthOffset(a11, tz){
  const k = INT((a11 - 2415021.076998695)/29.530588853 + 0.5);
  let last = 0, i = 1;
  let arc = getSunLongitude(getNewMoonDay(k+i, tz), tz);
  do{
    last = arc; i++;
    arc = getSunLongitude(getNewMoonDay(k+i, tz), tz);
  } while(arc !== last && i < 14);
  return i-1;
}

function convertSolar2Lunar(dd, mm, yy, tz){
  const dayNumber = jdFromDate(dd, mm, yy);
  const k = INT((dayNumber - 2415021.076998695)/29.530588853);
  let monthStart = getNewMoonDay(k+1, tz);
  if(monthStart > dayNumber) monthStart = getNewMoonDay(k, tz);
  let a11 = getLunarMonth11(yy, tz);
  let b11 = a11;
  let lunarYear;
  if(a11 >= monthStart){ lunarYear = yy; a11 = getLunarMonth11(yy-1, tz); }
  else { lunarYear = yy+1; b11 = getLunarMonth11(yy+1, tz); }
  const lunarDay = dayNumber - monthStart + 1;
  const diff = INT((monthStart - a11)/29);
  let lunarLeap = 0, lunarMonth = diff + 11;
  if(b11 - a11 > 365){
    const leapOff = getLeapMonthOffset(a11, tz);
    if(diff >= leapOff){ lunarMonth = diff + 10; if(diff === leapOff) lunarLeap = 1; }
  }
  if(lunarMonth > 12) lunarMonth -= 12;
  if(lunarMonth >= 11 && diff < 4) lunarYear -= 1;
  return { day:lunarDay, month:lunarMonth, year:lunarYear, leap: lunarLeap===1 };
}

function lunarOf(dateObj){
  return convertSolar2Lunar(dateObj.getDate(), dateObj.getMonth()+1, dateObj.getFullYear(), LUNAR_TZ);
}
function lunarShortLabel(dateObj){
  const l = lunarOf(dateObj);
  return `${l.day}/${l.month}${l.leap ? t('leap_suffix') : ''}`;
}
function lunarFullLabel(dateObj){
  const l = lunarOf(dateObj);
  return `${t('lunar_prefix')} ${l.day}/${l.month}${l.leap ? ' '+t('leap_suffix') : ''}`;
}

/* ---------------- Calendar helpers ---------------- */
function pad2(n){ return String(n).padStart(2,'0'); }
function isoDate(y,m,d){ return `${y}-${pad2(m)}-${pad2(d)}`; }
function todayISO(){ const d = new Date(); return isoDate(d.getFullYear(), d.getMonth()+1, d.getDate()); }

function buildGoogleCalUrl(ev){
  let datesParam;
  if(ev.time){
    const start = new Date(`${ev.date}T${ev.time}:00`);
    const end = new Date(start.getTime() + 60*60000);
    const fmt = d => `${d.getUTCFullYear()}${pad2(d.getUTCMonth()+1)}${pad2(d.getUTCDate())}T${pad2(d.getUTCHours())}${pad2(d.getUTCMinutes())}00Z`;
    datesParam = `${fmt(start)}/${fmt(end)}`;
  } else {
    const start = new Date(`${ev.date}T00:00:00`);
    const end = new Date(start.getTime() + 24*3600000);
    const fmtDate = d => `${d.getFullYear()}${pad2(d.getMonth()+1)}${pad2(d.getDate())}`;
    datesParam = `${fmtDate(start)}/${fmtDate(end)}`;
  }
  const params = new URLSearchParams({ action:'TEMPLATE', text: ev.title || '', dates: datesParam, details: ev.notes || '' });
  return `https://calendar.google.com/calendar/render?${params.toString()}`;
}

function unescapeICS(s){ return (s||'').replace(/\\n/gi,' ').replace(/\\,/g,',').replace(/\\;/g,';').replace(/\\\\/g,'\\'); }

function parseICSDate(value, rawKey){
  const isAllDay = /VALUE=DATE/i.test(rawKey) || !/T/.test(value);
  const m = value.match(/(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2})(\d{2})(Z)?)?/);
  if(!m) return { date: todayISO(), time:'' };
  const [, y, mo, d, hh, mi, ss, z] = m;
  if(isAllDay || !hh) return { date:`${y}-${mo}-${d}`, time:'' };
  if(z){
    const utc = new Date(Date.UTC(+y, +mo-1, +d, +hh, +mi, +(ss||0)));
    return { date: isoDate(utc.getFullYear(), utc.getMonth()+1, utc.getDate()), time:`${pad2(utc.getHours())}:${pad2(utc.getMinutes())}` };
  }
  return { date:`${y}-${mo}-${d}`, time:`${hh}:${mi}` };
}

function parseICS(text){
  const rawLines = text.split(/\r\n|\n|\r/);
  const lines = [];
  rawLines.forEach(line=>{
    if(/^[ \t]/.test(line) && lines.length) lines[lines.length-1] += line.slice(1);
    else lines.push(line);
  });
  const events = [];
  let cur = null;
  lines.forEach(line=>{
    if(/^BEGIN:VEVENT/.test(line)){ cur = {}; }
    else if(/^END:VEVENT/.test(line)){ if(cur && cur.date) events.push(cur); cur = null; }
    else if(cur){
      const idx = line.indexOf(':');
      if(idx < 0) return;
      const rawKey = line.slice(0, idx);
      const value = line.slice(idx+1);
      const key = rawKey.split(';')[0].toUpperCase();
      if(key === 'SUMMARY') cur.title = unescapeICS(value);
      else if(key === 'DESCRIPTION') cur.notes = unescapeICS(value);
      else if(key === 'DTSTART'){
        const parsed = parseICSDate(value, rawKey);
        cur.date = parsed.date; cur.time = parsed.time;
      }
    }
  });
  return events;
}

const REMINDER_OPTIONS = [
  { value:'none', key:'cal_rem_none' },
  { value:'at',   key:'cal_rem_at' },
  { value:'5',    key:'cal_rem_5' },
  { value:'15',   key:'cal_rem_15' },
  { value:'30',   key:'cal_rem_30' },
  { value:'60',   key:'cal_rem_60' }
];

function renderCalendar(body){
  const today = new Date();
  let viewYear = today.getFullYear();
  let viewMonth = today.getMonth();
  let selectedDate = todayISO();
  let mode = 'calendar';
  let editingId = null;

  function eventsOn(dateStr){
    return state.calendarEvents.filter(e=>e.date===dateStr).sort((a,b)=>(a.time||'').localeCompare(b.time||''));
  }

  function draw(){
    body.innerHTML = mode === 'manage' ? manageMarkup() : calendarMarkup();
    if(mode === 'manage') wireManage(); else wireCalendar();
  }

  function calendarMarkup(){
    const monthLabel = new Date(viewYear, viewMonth, 1).toLocaleDateString(LOCALE_MAP[state.lang]||'en-US', { month:'long', year:'numeric' });
    const firstDow = new Date(viewYear, viewMonth, 1).getDay();
    const daysInMonth = new Date(viewYear, viewMonth+1, 0).getDate();
    const weekdayFmt = new Intl.DateTimeFormat(LOCALE_MAP[state.lang]||'en-US', { weekday:'narrow' });
    let weekdayRow = '';
    for(let i=0;i<7;i++){ weekdayRow += `<span>${weekdayFmt.format(new Date(2023,0,1+i))}</span>`; }

    let cells = '';
    for(let i=0;i<firstDow;i++) cells += `<button class="cal-cell empty" disabled></button>`;
    const showLunar = state.calendarSystem === 'lunar' || state.calendarSystem === 'both';
    for(let d=1; d<=daysInMonth; d++){
      const dateStr = isoDate(viewYear, viewMonth+1, d);
      const hasEvents = eventsOn(dateStr).length > 0;
      const isToday = dateStr === todayISO();
      const isSel = dateStr === selectedDate;
      const lunarTag = showLunar ? `<span class="cal-lunar-day">${lunarShortLabel(new Date(viewYear, viewMonth, d))}</span>` : '';
      cells += `<button class="cal-cell${isToday?' today':''}${isSel?' selected':''}" data-date="${dateStr}">${d}${lunarTag}${hasEvents?'<span class="cal-dot"></span>':''}</button>`;
    }

    const dayEvents = eventsOn(selectedDate);
    let dayLabel = new Date(selectedDate+'T00:00:00').toLocaleDateString(LOCALE_MAP[state.lang]||'en-US', { weekday:'long', month:'long', day:'numeric' });
    if(state.calendarSystem === 'lunar'){
      dayLabel = lunarFullLabel(new Date(selectedDate+'T00:00:00'));
    } else if(state.calendarSystem === 'both'){
      dayLabel += ` · ${lunarFullLabel(new Date(selectedDate+'T00:00:00'))}`;
    }
    const listHtml = dayEvents.length
      ? dayEvents.map(ev=>`
          <li class="cal-ev-row" data-id="${ev.id}">
            ${ev.time ? `<span class="cal-ev-time">${ev.time}</span>` : ''}
            <span class="cal-ev-title"></span>
            <button class="cal-ev-edit" aria-label="${t('cal_edit_event')}">${iconSvg('settings','wsvg')}</button>
            <button class="cal-ev-del" aria-label="${t('remove')}">${iconSvg('close','wsvg')}</button>
          </li>`).join('')
      : `<li class="file-empty" data-i18n="cal_no_events">${t('cal_no_events')}</li>`;

    return `
      <div class="cal-head">
        <button class="cal-nav" id="cal-prev">${iconSvg('chevronLeft','wsvg')}</button>
        <span class="cal-month"></span>
        <button class="cal-nav" id="cal-next">${iconSvg('chevronRight','wsvg')}</button>
        <button class="cal-gear" id="cal-gear" aria-label="${t('cal_manage')}">${iconSvg('settings','wsvg')}</button>
      </div>
      <div class="cal-weekdays">${weekdayRow}</div>
      <div class="cal-grid">${cells}</div>
      <div class="cal-day-head">
        <span class="cal-day-label"></span>
        <button class="cal-add-inline" id="cal-add-inline" aria-label="${t('cal_add_event')}">${iconSvg('plus','wsvg')}</button>
      </div>
      <ul class="cal-ev-list">${listHtml}</ul>
    `.replace('<span class="cal-month"></span>', `<span class="cal-month">${monthLabel}</span>`)
     .replace('<span class="cal-day-label"></span>', `<span class="cal-day-label">${dayLabel}</span>`);
  }

  function wireCalendar(){
    // fill event titles safely (avoid HTML injection from user text via innerHTML above)
    body.querySelectorAll('.cal-ev-row').forEach(row=>{
      const ev = state.calendarEvents.find(e=>e.id===row.dataset.id);
      if(ev) row.querySelector('.cal-ev-title').textContent = ev.title || t('cal_untitled');
    });
    body.querySelector('#cal-prev').addEventListener('click', ()=>{
      viewMonth--; if(viewMonth<0){ viewMonth=11; viewYear--; } draw();
    });
    body.querySelector('#cal-next').addEventListener('click', ()=>{
      viewMonth++; if(viewMonth>11){ viewMonth=0; viewYear++; } draw();
    });
    body.querySelector('#cal-gear').addEventListener('click', ()=>{ mode='manage'; editingId=null; draw(); });
    body.querySelectorAll('.cal-cell[data-date]').forEach(cell=>{
      cell.addEventListener('click', ()=>{ selectedDate = cell.dataset.date; draw(); });
    });
    body.querySelector('#cal-add-inline').addEventListener('click', ()=>{
      mode='manage'; editingId=null; draw();
    });
    body.querySelectorAll('.cal-ev-edit').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        editingId = btn.closest('.cal-ev-row').dataset.id;
        mode = 'manage'; draw();
      });
    });
    body.querySelectorAll('.cal-ev-del').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const id = btn.closest('.cal-ev-row').dataset.id;
        state.calendarEvents = state.calendarEvents.filter(e=>e.id!==id);
        saveState(); draw();
      });
    });
  }

  function manageMarkup(){
    const editing = editingId ? state.calendarEvents.find(e=>e.id===editingId) : null;
    const f = editing || { title:'', date:selectedDate, time:'', reminder:'none', notes:'' };
    const allEvents = [...state.calendarEvents].sort((a,b)=> (a.date+a.time).localeCompare(b.date+b.time));
    const allHtml = allEvents.length
      ? allEvents.map(ev=>`
          <li class="cal-all-row" data-id="${ev.id}">
            <div class="cal-all-meta">
              <span class="cal-all-date">${ev.date}${ev.time ? ' · '+ev.time : ''}</span>
              <span class="cal-all-title"></span>
            </div>
            <button class="cal-all-google" title="${t('cal_add_to_google')}">${iconSvg('calendar','wsvg')}</button>
            <button class="cal-all-edit" aria-label="${t('cal_edit_event')}">${iconSvg('settings','wsvg')}</button>
            <button class="cal-all-del" aria-label="${t('remove')}">${iconSvg('close','wsvg')}</button>
          </li>`).join('')
      : `<li class="file-empty" data-i18n="cal_none_yet">${t('cal_none_yet')}</li>`;

    return `
      <div class="cal-head">
        <button class="cal-nav" id="cal-back">${iconSvg('chevronLeft','wsvg')}</button>
        <span class="cal-month" data-i18n="cal_manage">${t('cal_manage')}</span>
      </div>
      <form class="cal-form" id="cal-form">
        <label class="cal-field">
          <span data-i18n="cal_title">${t('cal_title')}</span>
          <input type="text" id="cf-title" value="${(f.title||'').replace(/"/g,'&quot;')}" maxlength="60">
        </label>
        <div class="cal-field-row">
          <label class="cal-field">
            <span data-i18n="cal_date">${t('cal_date')}</span>
            <input type="date" id="cf-date" value="${f.date}">
          </label>
          <label class="cal-field">
            <span data-i18n="cal_time">${t('cal_time')}</span>
            <input type="time" id="cf-time" value="${f.time||''}">
          </label>
        </div>
        <label class="cal-field" id="cf-reminder-wrap" ${f.time ? '' : 'hidden'}>
          <span data-i18n="cal_reminder">${t('cal_reminder')}</span>
          <select id="cf-reminder">
            ${REMINDER_OPTIONS.map(o=>`<option value="${o.value}" ${((f.reminder||'none')===o.value)?'selected':''}>${t(o.key)}</option>`).join('')}
          </select>
        </label>
        <label class="cal-field">
          <span data-i18n="cal_notes">${t('cal_notes')}</span>
          <textarea id="cf-notes" rows="2">${(f.notes||'')}</textarea>
        </label>
        <div class="btn-row">
          <button type="submit" class="wbtn primary" data-i18n="cal_save">${t('cal_save')}</button>
          <button type="button" class="wbtn" id="cf-cancel" data-i18n="cal_cancel">${t('cal_cancel')}</button>
        </div>
      </form>

      <p class="drawer-label" style="margin-top:14px" data-i18n="cal_all_events">${t('cal_all_events')}</p>
      <ul class="cal-all-list">${allHtml}</ul>

      <p class="drawer-label" style="margin-top:14px" data-i18n="cal_import_ics">${t('cal_import_ics')}</p>
      <p class="dock-vis-hint" data-i18n="cal_import_hint">${t('cal_import_hint')}</p>
      <label class="file-drop" for="cf-ics"><span class="file-drop-btn" aria-hidden="true">+</span><span class="file-drop-text">${t('cal_import_ics')}</span></label>
      <input type="file" id="cf-ics" accept=".ics,text/calendar" hidden>

      <button class="ghost-btn" id="cf-notif" style="margin-top:14px" data-i18n="cal_enable_notifs">${t('cal_enable_notifs')}</button>
    `;
  }

  function wireManage(){
    body.querySelectorAll('.cal-all-row').forEach(row=>{
      const ev = state.calendarEvents.find(e=>e.id===row.dataset.id);
      if(ev) row.querySelector('.cal-all-title').textContent = ev.title || t('cal_untitled');
    });
    body.querySelector('#cal-back').addEventListener('click', ()=>{ mode='calendar'; editingId=null; draw(); });

    const timeInput = body.querySelector('#cf-time');
    const remWrap = body.querySelector('#cf-reminder-wrap');
    timeInput.addEventListener('input', ()=>{ remWrap.hidden = !timeInput.value; });

    body.querySelector('#cf-cancel').addEventListener('click', ()=>{ mode='calendar'; editingId=null; draw(); });

    body.querySelector('#cal-form').addEventListener('submit', e=>{
      e.preventDefault();
      const title = body.querySelector('#cf-title').value.trim();
      const date = body.querySelector('#cf-date').value || selectedDate;
      const time = timeInput.value || '';
      const reminder = time ? body.querySelector('#cf-reminder').value : 'none';
      const notes = body.querySelector('#cf-notes').value.trim();
      if(editingId){
        const ev = state.calendarEvents.find(x=>x.id===editingId);
        if(ev){ ev.title=title; ev.date=date; ev.time=time; ev.reminder=reminder; ev.notes=notes; ev.fired=false; }
      } else {
        state.calendarEvents.push({ id:cid(), title, date, time, reminder, notes, fired:false });
      }
      saveState();
      selectedDate = date;
      mode = 'calendar'; editingId = null;
      draw();
    });

    body.querySelectorAll('.cal-all-edit').forEach(btn=>{
      btn.addEventListener('click', ()=>{ editingId = btn.closest('.cal-all-row').dataset.id; draw(); });
    });
    body.querySelectorAll('.cal-all-del').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const id = btn.closest('.cal-all-row').dataset.id;
        state.calendarEvents = state.calendarEvents.filter(e=>e.id!==id);
        if(editingId===id) editingId=null;
        saveState(); draw();
      });
    });
    body.querySelectorAll('.cal-all-google').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const id = btn.closest('.cal-all-row').dataset.id;
        const ev = state.calendarEvents.find(e=>e.id===id);
        if(ev) window.open(buildGoogleCalUrl(ev), '_blank');
      });
    });

    body.querySelector('#cf-ics').addEventListener('change', async e=>{
      const file = e.target.files[0];
      if(!file) return;
      const text = await file.text();
      const imported = parseICS(text);
      imported.forEach(ev=>{
        state.calendarEvents.push({ id:cid(), title:ev.title||'', date:ev.date, time:ev.time||'', reminder:'none', notes:ev.notes||'', fired:false });
      });
      saveState();
      e.target.value = '';
      toast(t('cal_import_done', { n: imported.length }));
      draw();
    });

    body.querySelector('#cf-notif').addEventListener('click', ()=>{
      if(!('Notification' in window)){ return; }
      Notification.requestPermission().then(perm=>{
        if(perm === 'granted'){ state.notifsEnabled = true; saveState(); toast(t('cal_notifs_on')); }
        else { state.notifsEnabled = false; saveState(); toast(t('cal_notifs_denied')); }
      });
    });
  }

  draw();
  return null;
}

/* ---------------- Reminder engine (runs regardless of whether the widget is open) ---------------- */
function showReminderPopup(ev){
  const overlay = document.createElement('div');
  overlay.className = 'reminder-overlay';
  const when = new Date(`${ev.date}T${ev.time||'00:00'}:00`)
    .toLocaleString(LOCALE_MAP[state.lang]||'en-US', { weekday:'short', month:'short', day:'numeric', hour:'numeric', minute:'2-digit' });
  overlay.innerHTML = `
    <div class="reminder-card">
      <p class="reminder-kicker">${t('reminder_popup_title')}</p>
      <h3></h3>
      <p class="reminder-meta"></p>
      <p class="reminder-notes"></p>
      <button class="wbtn primary">${t('dismiss')}</button>
    </div>
  `;
  overlay.querySelector('h3').textContent = ev.title || t('cal_untitled');
  overlay.querySelector('.reminder-meta').textContent = when;
  overlay.querySelector('.reminder-notes').textContent = ev.notes || '';
  overlay.querySelector('button').addEventListener('click', ()=> overlay.remove());
  document.body.appendChild(overlay);

  if(state.notifsEnabled && 'Notification' in window && Notification.permission === 'granted'){
    try{ new Notification(ev.title || t('cal_untitled'), { body: ev.notes || when }); }catch(err){}
  }
}

function checkReminders(){
  const now = new Date();
  let changed = false;
  state.calendarEvents.forEach(ev=>{
    if(ev.fired || !ev.time || !ev.reminder || ev.reminder === 'none') return;
    const evDate = new Date(`${ev.date}T${ev.time}:00`);
    const remindMinutes = ev.reminder === 'at' ? 0 : parseInt(ev.reminder, 10) || 0;
    const remindAt = new Date(evDate.getTime() - remindMinutes*60000);
    const graceMs = 60*60000;
    if(now >= remindAt && (evDate.getTime() - now.getTime()) > -graceMs){
      showReminderPopup(ev);
      ev.fired = true;
      changed = true;
    }
  });
  if(changed) saveState();
}

/* ---------------- Poll widget ---------------- */
function renderPoll(body){
  let mode = 'view';

  function draw(){
    body.innerHTML = mode === 'manage' ? manageMarkup() : viewMarkup();
    if(mode === 'manage') wireManage(); else wireView();
  }

  function viewMarkup(){
    const total = state.poll.options.reduce((s,o)=>s+o.votes, 0);
    const optsHtml = state.poll.options.map((o,i)=>{
      const pct = total > 0 ? Math.round((o.votes/total)*100) : 0;
      const color = SB_COLORS[i % SB_COLORS.length];
      return `
        <button class="poll-opt" data-id="${o.id}">
          <span class="poll-opt-bar" style="width:${pct}%; background:${color}"></span>
          <span class="poll-opt-label"></span>
          <span class="poll-opt-count">${o.votes}</span>
        </button>`;
    }).join('');
    return `
      <div class="cal-head">
        <span class="poll-q"></span>
        <button class="cal-gear" id="poll-gear" aria-label="${t('poll_manage')}">${iconSvg('settings','wsvg')}</button>
      </div>
      <p class="poll-hint" data-i18n="poll_tap_hint">${t('poll_tap_hint')}</p>
      <div class="poll-opts">${optsHtml}</div>
      <p class="poll-total"></p>
      <button class="ghost-btn" id="poll-reset" data-i18n="poll_reset_votes">${t('poll_reset_votes')}</button>
    `.replace('<p class="poll-total"></p>', `<p class="poll-total">${t('poll_total_votes', { n: total })}</p>`);
  }

  function wireView(){
    body.querySelector('.poll-q').textContent = state.poll.question || t('poll_question_label');
    body.querySelectorAll('.poll-opt').forEach(btn=>{
      const o = state.poll.options.find(x=>x.id===btn.dataset.id);
      if(o) btn.querySelector('.poll-opt-label').textContent = o.text || t('poll_option_label');
      btn.addEventListener('click', ()=>{
        if(o){ o.votes++; saveState(); draw(); }
      });
    });
    body.querySelector('#poll-gear').addEventListener('click', ()=>{ mode='manage'; draw(); });
    body.querySelector('#poll-reset').addEventListener('click', ()=>{
      state.poll.options.forEach(o=> o.votes = 0);
      saveState(); draw();
    });
  }

  function manageMarkup(){
    const rowsHtml = state.poll.options.map(o=>`
      <li class="poll-edit-row" data-id="${o.id}">
        <input type="text" class="poll-edit-input" value="${(o.text||'').replace(/"/g,'&quot;')}" placeholder="${t('poll_option_label')}">
        <button class="poll-edit-remove" aria-label="${t('remove')}">${iconSvg('close','wsvg')}</button>
      </li>`).join('');
    return `
      <div class="cal-head">
        <button class="cal-nav" id="poll-back">${iconSvg('chevronLeft','wsvg')}</button>
        <span class="cal-month" data-i18n="poll_manage">${t('poll_manage')}</span>
      </div>
      <label class="cal-field" style="margin-bottom:10px">
        <span data-i18n="poll_question_label">${t('poll_question_label')}</span>
        <input type="text" id="poll-q-input" value="${(state.poll.question||'').replace(/"/g,'&quot;')}" maxlength="80">
      </label>
      <ul class="poll-edit-list">${rowsHtml}</ul>
      <button class="ghost-btn" id="poll-add-opt" data-i18n="poll_add_option">${t('poll_add_option')}</button>
    `;
  }

  function wireManage(){
    body.querySelector('#poll-back').addEventListener('click', ()=>{ mode='view'; draw(); });
    body.querySelector('#poll-q-input').addEventListener('change', e=>{
      state.poll.question = e.target.value.trim();
      saveState();
    });
    body.querySelectorAll('.poll-edit-row').forEach(row=>{
      const o = state.poll.options.find(x=>x.id===row.dataset.id);
      row.querySelector('.poll-edit-input').addEventListener('change', e=>{
        if(o){ o.text = e.target.value.trim(); saveState(); }
      });
      row.querySelector('.poll-edit-remove').addEventListener('click', ()=>{
        if(state.poll.options.length <= 2){ toast(t('poll_min_options')); return; }
        state.poll.options = state.poll.options.filter(x=>x.id!==row.dataset.id);
        saveState(); draw();
      });
    });
    body.querySelector('#poll-add-opt').addEventListener('click', ()=>{
      if(state.poll.options.length >= 8) return;
      state.poll.options.push({ id:cid(), text:'', votes:0 });
      saveState(); draw();
    });
  }

  draw();
  return null;
}

/* ---------------- Noise Meter widget (microphone access) ---------------- */
function renderNoise(body){
  let audioCtx = null, analyser = null, source = null, stream = null, rafId = null, running = false;

  function idleMarkup(){
    if(!window.isSecureContext){
      return `<p class="noise-msg" data-i18n="noise_insecure">${t('noise_insecure')}</p>`;
    }
    return `
      <div class="noise-gauge">
        <div class="noise-db">--</div>
        <div class="noise-unit">dB</div>
      </div>
      <p class="noise-level-label">&nbsp;</p>
      <p class="noise-approx-note" data-i18n="noise_approx_note">${t('noise_approx_note')}</p>
      <button class="wbtn primary" id="noise-toggle" data-i18n-dyn data-key="noise_enable">${t('noise_enable')}</button>
      <p class="noise-msg" id="noise-msg"></p>
    `;
  }

  function wire(){
    const btn = body.querySelector('#noise-toggle');
    if(!btn) return;
    btn.addEventListener('click', ()=>{ running ? stop() : start(); });
  }

  async function start(){
    const msgEl = body.querySelector('#noise-msg');
    if(msgEl) msgEl.textContent = '';
    try{
      stream = await navigator.mediaDevices.getUserMedia({ audio:true });
    }catch(err){
      if(msgEl) msgEl.textContent = err.name === 'NotFoundError' ? t('noise_no_mic') : t('noise_denied');
      return;
    }
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    source = audioCtx.createMediaStreamSource(stream);
    analyser = audioCtx.createAnalyser();
    analyser.fftSize = 1024;
    source.connect(analyser);
    running = true;
    const btn = body.querySelector('#noise-toggle');
    if(btn){ btn.dataset.key = 'noise_stop'; btn.textContent = t('noise_stop'); }
    loop();
  }

  function loop(){
    if(!running || !analyser) return;
    const data = new Uint8Array(analyser.fftSize);
    analyser.getByteTimeDomainData(data);
    let sum = 0;
    for(let i=0;i<data.length;i++){
      const v = (data[i]-128)/128;
      sum += v*v;
    }
    const rms = Math.sqrt(sum/data.length);
    const dbfs = rms > 0 ? 20*Math.log10(rms) : -100;
    const display = Math.max(0, Math.min(120, Math.round(dbfs + 100)));
    updateGauge(display);
    rafId = requestAnimationFrame(loop);
  }

  function updateGauge(db){
    const dbEl = body.querySelector('.noise-db');
    const labelEl = body.querySelector('.noise-level-label');
    const gauge = body.querySelector('.noise-gauge');
    if(!dbEl || !gauge) return;
    dbEl.textContent = db;
    let key, cls;
    if(db < 50){ key='noise_quiet'; cls='quiet'; }
    else if(db < 70){ key='noise_ok'; cls='ok'; }
    else { key='noise_loud'; cls='loud'; }
    if(labelEl) labelEl.textContent = t(key);
    gauge.className = 'noise-gauge ' + cls;
  }

  function stop(){
    running = false;
    if(rafId) cancelAnimationFrame(rafId);
    if(source) try{ source.disconnect(); }catch(e){}
    if(audioCtx) try{ audioCtx.close(); }catch(e){}
    if(stream) stream.getTracks().forEach(tr=>tr.stop());
    audioCtx = null; analyser = null; source = null; stream = null; rafId = null;
    const btn = body.querySelector('#noise-toggle');
    if(btn){ btn.dataset.key = 'noise_enable'; btn.textContent = t('noise_enable'); }
    const dbEl = body.querySelector('.noise-db');
    if(dbEl) dbEl.textContent = '--';
    const labelEl = body.querySelector('.noise-level-label');
    if(labelEl) labelEl.innerHTML = '&nbsp;';
    const gauge = body.querySelector('.noise-gauge');
    if(gauge) gauge.className = 'noise-gauge';
  }

  body.innerHTML = idleMarkup();
  wire();

  return ()=>{ stop(); };
}

/* ---------------- Streaming URL helpers (no API key needed) ---------------- */
function parseYouTube(url){
  try{
    const u = new URL(url);
    const host = u.hostname.replace(/^www\./,'');
    if(host === 'youtu.be'){
      return { type:'video', id: u.pathname.slice(1) };
    }
    if(host === 'youtube.com' || host === 'm.youtube.com' || host === 'music.youtube.com'){
      if(u.pathname.startsWith('/playlist')){
        const list = u.searchParams.get('list');
        return list ? { type:'playlist', id:list } : null;
      }
      const v = u.searchParams.get('v');
      const list = u.searchParams.get('list');
      if(v) return { type:'video', id:v, list };
      if(list) return { type:'playlist', id:list };
      if(u.pathname.startsWith('/embed/')){
        return { type:'video', id: u.pathname.split('/')[2] };
      }
    }
  }catch(e){}
  return null;
}
function youtubeWatchUrl(parsed){
  // YouTube links are opened in a real browser tab rather than embedded in an
  // iframe — YouTube's own embed rules (a real HTTP referer, no ad-blockers
  // stripping it, no plain-file:// origin) make in-widget embedding fragile
  // (see "Error 153" in past versions), and a full new tab always just works.
  if(!parsed) return '';
  if(parsed.type === 'playlist') return `https://www.youtube.com/playlist?list=${parsed.id}`;
  let src = `https://www.youtube.com/watch?v=${parsed.id}`;
  if(parsed.list) src += `&list=${parsed.list}`;
  return src;
}
function isSoundCloudUrl(url){
  try{ return new URL(url).hostname.replace(/^www\./,'') === 'soundcloud.com'; }
  catch(e){ return false; }
}
function soundcloudEmbedUrl(url){
  return `https://w.soundcloud.com/player/?url=${encodeURIComponent(url)}&color=%23e8a33d&auto_play=false&show_comments=false&visual=false`;
}

/* ---------------- Music Player widget ---------------- */
function renderMusic(body){
  body.innerHTML = `
    <div class="tabs">
      <button class="tab-btn active" data-tab="files" data-i18n="tab_my_files">${t('tab_my_files')}</button>
      <button class="tab-btn" data-tab="stream" data-i18n="tab_stream">${t('tab_stream')}</button>
      <button class="tab-btn" data-tab="spotify" data-i18n="tab_spotify">${t('tab_spotify')}</button>
    </div>

    <div class="tab-panel" data-panel="files">
      <audio id="mp-audio" controls style="width:100%; margin-bottom:8px;"></audio>
      <p class="mp-now" id="mp-now">&nbsp;</p>
      <div class="file-drop"><button type="button" class="file-drop-browse" id="mp-browse">${iconSvg('plus','wsvg')}<span data-i18n="browse_btn">${t('browse_btn')}</span></button></div>
      <input type="file" id="mp-input" hidden multiple accept="audio/*,.mp3,.m4a,.wav,.ogg,.flac,.aac">
      <ul class="file-list" id="mp-list"></ul>
    </div>

    <div class="tab-panel" data-panel="stream" hidden>
      <div class="stream-row">
        <input type="text" id="mp-stream-input" placeholder="${t('stream_placeholder')}" data-i18n-placeholder="stream_placeholder">
        <button class="wbtn primary" id="mp-stream-go">${t('play')}</button>
      </div>
      <p class="stream-msg" id="mp-stream-msg"></p>
      <div class="stream-embed" id="mp-stream-embed"></div>
    </div>

    <div class="tab-panel" data-panel="spotify" hidden>
      <div class="stream-row">
        <input type="text" id="mp-spotify-input" placeholder="${t('spotify_placeholder')}" data-i18n-placeholder="spotify_placeholder" value="${(state.spotifyUrl||'').replace(/"/g,'&quot;')}">
      </div>
      <button class="wbtn primary" id="mp-spotify-open" style="width:100%; margin-bottom:10px" data-i18n="spotify_open">${t('spotify_open')}</button>
      <p class="dock-vis-hint" data-i18n="spotify_note">${t('spotify_note')}</p>
    </div>
  `;

  wireTabs(body);

  const audio = body.querySelector('#mp-audio');
  const nowEl = body.querySelector('#mp-now');
  const list = body.querySelector('#mp-list');
  const input = body.querySelector('#mp-input');
  body.querySelector('#mp-browse').addEventListener('click', ()=> input.click());
  let tracks = [];
  let currentIdx = -1;

  async function draw(){
    tracks = (await idb.getAll('music')).sort((a,b)=>a.added-b.added);
    list.innerHTML = '';
    if(!tracks.length){
      list.innerHTML = `<li class="file-empty" data-i18n="mp_empty">${t('mp_empty')}</li>`;
      return;
    }
    tracks.forEach((tr,i)=>{
      const li = document.createElement('li');
      li.className = i===currentIdx ? 'playing' : '';
      li.innerHTML = `<span class="ftype">${i+1}</span><span class="fname"></span><button aria-label="${t('play')}">▶</button><button class="wminus" aria-label="${t('remove')}">−</button>`;
      li.querySelector('.fname').textContent = tr.name;
      const [playBtn, delBtn] = li.querySelectorAll('button');
      playBtn.addEventListener('click', ()=> playTrack(i));
      delBtn.addEventListener('click', async ()=>{
        await idb.delete('music', tr.id);
        if(i===currentIdx){ audio.pause(); audio.removeAttribute('src'); currentIdx=-1; nowEl.textContent='\u00A0'; }
        draw();
      });
      list.appendChild(li);
    });
  }

  function playTrack(i){
    if(i<0 || i>=tracks.length) return;
    currentIdx = i;
    audio.src = URL.createObjectURL(tracks[i].blob);
    audio.play();
    nowEl.textContent = tracks[i].name;
    draw();
  }

  audio.addEventListener('ended', ()=>{
    if(currentIdx+1 < tracks.length) playTrack(currentIdx+1);
  });

  input.addEventListener('change', async ()=>{
    for(const file of input.files){
      await idb.put('music', { id:cid(), name:file.name, blob:file, added:Date.now() });
    }
    input.value = '';
    draw();
  });

  // Stream tab (YouTube / SoundCloud)
  const streamInput = body.querySelector('#mp-stream-input');
  const streamEmbed = body.querySelector('#mp-stream-embed');
  const streamMsg = body.querySelector('#mp-stream-msg');
  function loadStream(url, userInitiated){
    const yt = parseYouTube(url);
    if(yt){
      state.musicStream = { type:'youtube', url };
      saveState();
      streamMsg.textContent = '';
      const watchUrl = youtubeWatchUrl(yt);
      if(userInitiated) window.open(watchUrl, '_blank', 'noopener');
      streamEmbed.innerHTML = `<div class="yt-external"><p>${t('youtube_external_msg')}</p><a class="wbtn primary" href="${watchUrl}" target="_blank" rel="noopener">${t('open_in_youtube')}</a></div>`;
      return;
    }
    if(isSoundCloudUrl(url)){
      state.musicStream = { type:'soundcloud', url };
      saveState();
      streamMsg.textContent = '';
      streamEmbed.innerHTML = `<iframe src="${soundcloudEmbedUrl(url)}" allow="autoplay"></iframe>`;
      return;
    }
    streamMsg.textContent = t('stream_invalid');
  }
  body.querySelector('#mp-stream-go').addEventListener('click', ()=>{
    const url = streamInput.value.trim();
    if(url) loadStream(url, true);
  });
  if(state.musicStream.url){
    streamInput.value = state.musicStream.url;
    loadStream(state.musicStream.url, false); // restoring saved state — show the card, don't pop a tab
  }

  // Spotify tab
  const spotifyInput = body.querySelector('#mp-spotify-input');
  body.querySelector('#mp-spotify-open').addEventListener('click', ()=>{
    const url = spotifyInput.value.trim();
    if(!url) return;
    state.spotifyUrl = url;
    saveState();
    window.open(url, '_blank');
  });

  draw();
  return null;
}

function wireTabs(body){
  const tabs = body.querySelectorAll('.tab-btn');
  tabs.forEach(btn=>{
    btn.addEventListener('click', ()=>{
      tabs.forEach(b=> b.classList.remove('active'));
      btn.classList.add('active');
      body.querySelectorAll('.tab-panel').forEach(p=>{
        p.hidden = p.dataset.panel !== btn.dataset.tab;
      });
    });
  });
}

/* ---------------- Video Player widget ---------------- */
function renderVideoPlayer(body){
  body.innerHTML = `
    <div class="tabs">
      <button class="tab-btn active" data-tab="files" data-i18n="tab_my_files">${t('tab_my_files')}</button>
      <button class="tab-btn" data-tab="youtube" data-i18n="tab_youtube">${t('tab_youtube')}</button>
    </div>

    <div class="tab-panel" data-panel="files">
      <video id="vp-video" controls style="width:100%; border-radius:8px; background:#000; margin-bottom:8px;"></video>
      <p class="mp-now" id="vp-now">&nbsp;</p>
      <div class="file-drop"><button type="button" class="file-drop-browse" id="vp-browse">${iconSvg('plus','wsvg')}<span data-i18n="browse_btn">${t('browse_btn')}</span></button></div>
      <input type="file" id="vp-input" hidden multiple accept="video/*,.mp4,.webm,.mov,.mkv">
      <ul class="file-list" id="vp-list"></ul>
    </div>

    <div class="tab-panel" data-panel="youtube" hidden>
      <div class="stream-row">
        <input type="text" id="vp-yt-input" placeholder="${t('youtube_placeholder')}" data-i18n-placeholder="youtube_placeholder">
        <button class="wbtn primary" id="vp-yt-go">${t('play')}</button>
      </div>
      <p class="stream-msg" id="vp-yt-msg"></p>
      <div class="stream-embed video-embed" id="vp-yt-embed"></div>
    </div>
  `;

  wireTabs(body);

  const video = body.querySelector('#vp-video');
  const nowEl = body.querySelector('#vp-now');
  const list = body.querySelector('#vp-list');
  const input = body.querySelector('#vp-input');
  body.querySelector('#vp-browse').addEventListener('click', ()=> input.click());
  let clips = [];
  let currentIdx = -1;

  async function draw(){
    clips = (await idb.getAll('videos')).sort((a,b)=>a.added-b.added);
    list.innerHTML = '';
    if(!clips.length){
      list.innerHTML = `<li class="file-empty" data-i18n="vp_empty">${t('vp_empty')}</li>`;
      return;
    }
    clips.forEach((c,i)=>{
      const li = document.createElement('li');
      li.className = i===currentIdx ? 'playing' : '';
      li.innerHTML = `<span class="ftype">${i+1}</span><span class="fname"></span><button aria-label="${t('play')}">▶</button><button class="wminus" aria-label="${t('remove')}">−</button>`;
      li.querySelector('.fname').textContent = c.name;
      const [playBtn, delBtn] = li.querySelectorAll('button');
      playBtn.addEventListener('click', ()=> playClip(i));
      delBtn.addEventListener('click', async ()=>{
        await idb.delete('videos', c.id);
        if(i===currentIdx){ video.pause(); video.removeAttribute('src'); currentIdx=-1; nowEl.textContent='\u00A0'; }
        draw();
      });
      list.appendChild(li);
    });
  }

  function playClip(i){
    if(i<0 || i>=clips.length) return;
    currentIdx = i;
    video.src = URL.createObjectURL(clips[i].blob);
    video.play();
    nowEl.textContent = clips[i].name;
    draw();
  }

  video.addEventListener('ended', ()=>{
    if(currentIdx+1 < clips.length) playClip(currentIdx+1);
  });

  input.addEventListener('change', async ()=>{
    for(const file of input.files){
      await idb.put('videos', { id:cid(), name:file.name, blob:file, added:Date.now() });
    }
    input.value = '';
    draw();
  });

  const ytInput = body.querySelector('#vp-yt-input');
  const ytEmbed = body.querySelector('#vp-yt-embed');
  const ytMsg = body.querySelector('#vp-yt-msg');
  function loadYoutube(url, userInitiated){
    const yt = parseYouTube(url);
    if(!yt){ ytMsg.textContent = t('stream_invalid'); return; }
    state.videoStream = { type:'youtube', url };
    saveState();
    ytMsg.textContent = '';
    const watchUrl = youtubeWatchUrl(yt);
    if(userInitiated) window.open(watchUrl, '_blank', 'noopener');
    ytEmbed.innerHTML = `<div class="yt-external"><p>${t('youtube_external_msg')}</p><a class="wbtn primary" href="${watchUrl}" target="_blank" rel="noopener">${t('open_in_youtube')}</a></div>`;
  }
  body.querySelector('#vp-yt-go').addEventListener('click', ()=>{
    const url = ytInput.value.trim();
    if(url) loadYoutube(url, true);
  });
  if(state.videoStream.url){
    ytInput.value = state.videoStream.url;
    loadYoutube(state.videoStream.url, false); // restoring saved state — show the card, don't pop a tab
  }

  draw();
  return null;
}

/* ---------------- Soundboard widget (attention-getter sound effects) ---------------- */
function renderSoundboard(body){
  body.innerHTML = `
    <div class="sfx-controls">
      <button class="wbtn" id="sfx-stop" data-i18n="sfx_stop">${t('sfx_stop')}</button>
      <label class="sfx-volume-row">
        <span data-i18n="sfx_volume">${t('sfx_volume')}</span>
        <input type="range" id="sfx-volume" min="0" max="1" step="0.05" value="${state.sfxVolume}">
      </label>
    </div>
    <div class="file-drop"><button type="button" class="file-drop-browse" id="sfx-browse">${iconSvg('plus','wsvg')}<span data-i18n="browse_btn">${t('browse_btn')}</span></button></div>
    <input type="file" id="sfx-input" hidden multiple accept="audio/*,.mp3,.wav,.m4a,.ogg">
    <div class="game-grid sfx-grid"></div>
    <audio id="sfx-audio"></audio>
  `;

  const grid = body.querySelector('.sfx-grid');
  const input = body.querySelector('#sfx-input');
  body.querySelector('#sfx-browse').addEventListener('click', ()=> input.click());
  const audio = body.querySelector('#sfx-audio');
  const volumeSlider = body.querySelector('#sfx-volume');
  let sounds = [];
  let playingId = null;

  audio.volume = state.sfxVolume;
  volumeSlider.addEventListener('input', ()=>{
    state.sfxVolume = parseFloat(volumeSlider.value);
    audio.volume = state.sfxVolume;
    saveState();
  });

  function play(snd){
    audio.pause();
    audio.src = URL.createObjectURL(snd.blob);
    audio.currentTime = 0;
    audio.play();
    playingId = snd.id;
    highlight();
  }
  audio.addEventListener('ended', ()=>{ playingId = null; highlight(); });
  body.querySelector('#sfx-stop').addEventListener('click', ()=>{
    audio.pause(); audio.currentTime = 0; playingId = null; highlight();
  });

  function highlight(){
    grid.querySelectorAll('.game-tile').forEach(tile=>{
      tile.classList.toggle('playing-sfx', tile.dataset.id === playingId);
    });
  }

  async function draw(){
    sounds = (await idb.getAll('sounds')).sort((a,b)=>a.added-b.added);
    grid.innerHTML = '';
    if(!sounds.length){
      grid.innerHTML = `<p class="file-empty" data-i18n="sfx_empty">${t('sfx_empty')}</p>`;
      return;
    }
    sounds.forEach(snd=>{
      const tile = document.createElement('button');
      tile.className = 'game-tile';
      tile.dataset.id = snd.id;
      tile.title = snd.name;
      tile.innerHTML = `
        <span class="game-tile-remove" aria-label="${t('remove')} ${snd.name}">${iconSvg('close','wsvg')}</span>
        <span class="game-tile-play">${iconSvg('speaker','wsvg')}</span>
        <span class="game-tile-name"></span>
      `;
      tile.querySelector('.game-tile-name').textContent = snd.name.replace(/\.[^.]+$/,'');
      tile.addEventListener('click', ()=> play(snd));
      tile.querySelector('.game-tile-remove').addEventListener('click', async e=>{
        e.stopPropagation();
        await idb.delete('sounds', snd.id);
        if(playingId === snd.id){ audio.pause(); playingId = null; }
        draw();
      });
      grid.appendChild(tile);
    });
    highlight();
  }

  input.addEventListener('change', async ()=>{
    for(const file of input.files){
      await idb.put('sounds', { id:cid(), name:file.name, blob:file, added:Date.now() });
    }
    input.value = '';
    draw();
  });

  draw();
  return ()=>{ audio.pause(); };
}

/* ---------------- Wave 1 widgets ---------------- */

function renderAttendance(body){
  function todayKey(d){ d = d||new Date(); return d.toISOString().slice(0,10); }
  let curDate = todayKey();
  function dayRecord(){
    if(!state.attendance[curDate]) state.attendance[curDate] = {};
    return state.attendance[curDate];
  }
  function draw(){
    if(!state.roster.length){
      body.innerHTML = `<p class="small-hint" data-i18n="att_no_roster">${t('att_no_roster')}</p>`;
      return;
    }
    const rec = dayRecord();
    body.innerHTML = `
      <div class="att-date-row">
        <span class="field-label" data-i18n="att_date_label" style="margin:0">${t('att_date_label')}</span>
        <input type="date" id="att-date" value="${curDate}">
      </div>
      <div class="scroll-list" id="att-list"></div>
      <p class="att-summary" id="att-summary"></p>
      <div class="btn-row"><button class="wbtn" id="att-export" data-i18n="att_export">${t('att_export')}</button></div>
    `;
    const list = body.querySelector('#att-list');
    state.roster.forEach(name=>{
      const status = rec[name] || '';
      const row = document.createElement('div');
      row.className = 'att-row';
      row.innerHTML = `
        <span class="att-name"></span>
        <div class="att-toggle">
          <button class="att-btn present ${status==='present'?'on':''}" data-status="present">P</button>
          <button class="att-btn late ${status==='late'?'on':''}" data-status="late">L</button>
          <button class="att-btn absent ${status==='absent'?'on':''}" data-status="absent">A</button>
        </div>
      `;
      row.querySelector('.att-name').textContent = name;
      row.querySelectorAll('[data-status]').forEach(btn=>{
        btn.addEventListener('click', ()=>{
          const s = btn.dataset.status;
          rec[name] = rec[name] === s ? undefined : s;
          if(rec[name] === undefined) delete rec[name];
          saveState();
          draw();
        });
      });
      list.appendChild(row);
    });
    const counts = { present:0, absent:0, late:0 };
    Object.values(rec).forEach(s=>{ if(counts[s]!==undefined) counts[s]++; });
    body.querySelector('#att-summary').textContent = t('att_summary', counts);
    body.querySelector('#att-date').addEventListener('change', e=>{
      curDate = e.target.value || todayKey();
      draw();
    });
    body.querySelector('#att-export').addEventListener('click', ()=>{
      const rows = [['Student','Status'], ...state.roster.map(n=>[n, rec[n]||''])];
      const csv = rows.map(r=> r.map(c=> `"${String(c).replace(/"/g,'""')}"`).join(',')).join('\n');
      const blob = new Blob([csv], { type:'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = `attendance-${curDate}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    });
  }
  draw();
  return null;
}

function renderGroupMaker(body){
  function draw(){
    if(!state.roster.length){
      body.innerHTML = `<p class="small-hint" data-i18n="gm_no_roster">${t('gm_no_roster')}</p>`;
      return;
    }
    const gm = state.groupMaker;
    body.innerHTML = `
      <div class="gm-controls">
        <div class="field-block">
          <span class="field-label" data-i18n="gm_mode_groups">${t('gm_mode_groups')}</span>
          <input type="number" id="gm-count" min="2" max="${Math.max(2,state.roster.length)}" value="${gm.count}">
        </div>
        <button class="wbtn primary" id="gm-shuffle" data-i18n="gm_shuffle">${t('gm_shuffle')}</button>
      </div>
      <div class="gm-groups" id="gm-groups"></div>
    `;
    body.querySelector('#gm-count').addEventListener('change', e=>{
      gm.count = Math.max(2, parseInt(e.target.value)||2);
      saveState();
    });
    body.querySelector('#gm-shuffle').addEventListener('click', shuffle);
    renderGroups(gm.lastGroups);
  }
  function shuffle(){
    const gm = state.groupMaker;
    let names = state.roster.slice();
    let key;
    let attempt = 0;
    let groups;
    do{
      names = shuffleArray(state.roster.slice());
      groups = splitIntoGroups(names, gm.count);
      key = groups.map(g=>g.join(',')).join('|');
      attempt++;
    } while(key === gm.lastKey && attempt < 8 && state.roster.length > gm.count);
    gm.lastKey = key;
    gm.lastGroups = groups;
    saveState();
    renderGroups(groups);
  }
  function shuffleArray(arr){
    for(let i=arr.length-1;i>0;i--){
      const j = Math.floor(Math.random()*(i+1));
      [arr[i],arr[j]] = [arr[j],arr[i]];
    }
    return arr;
  }
  function splitIntoGroups(names, count){
    count = Math.min(count, names.length);
    const groups = Array.from({length:count}, ()=>[]);
    names.forEach((n,i)=> groups[i%count].push(n));
    return groups;
  }
  function renderGroups(groups){
    const wrap = body.querySelector('#gm-groups');
    if(!wrap) return;
    wrap.innerHTML = '';
    (groups||[]).forEach((g,i)=>{
      const div = document.createElement('div');
      div.className = 'gm-group';
      div.innerHTML = `<h4></h4><p></p>`;
      div.querySelector('h4').textContent = t('gm_group_label', { n:i+1 });
      div.querySelector('p').textContent = g.join(', ');
      wrap.appendChild(div);
    });
  }
  draw();
  return null;
}

function renderExitTicket(body){
  function draw(){
    const et = state.exitTicket;
    body.innerHTML = `
      <input type="text" class="et-q-input" id="et-q" placeholder="${t('et_question_placeholder')}" data-i18n-placeholder="et_question_placeholder" value="${et.question ? et.question.replace(/"/g,'&quot;') : ''}">
      <div class="et-tally-row">
        <div class="et-tally" data-k="got_it"><span class="et-tally-count">${et.tallies.got_it}</span><span class="et-tally-label" data-i18n="et_got_it">${t('et_got_it')}</span></div>
        <div class="et-tally" data-k="almost"><span class="et-tally-count">${et.tallies.almost}</span><span class="et-tally-label" data-i18n="et_almost">${t('et_almost')}</span></div>
        <div class="et-tally" data-k="need_help"><span class="et-tally-count">${et.tallies.need_help}</span><span class="et-tally-label" data-i18n="et_need_help">${t('et_need_help')}</span></div>
      </div>
      <p class="small-hint" data-i18n="et_hint">${t('et_hint')}</p>
      <div class="btn-row"><button class="wbtn" id="et-reset" data-i18n="et_reset">${t('et_reset')}</button></div>
    `;
    body.querySelector('#et-q').addEventListener('input', e=>{ et.question = e.target.value; saveState(); });
    body.querySelectorAll('.et-tally').forEach(el=>{
      el.addEventListener('click', ()=>{
        et.tallies[el.dataset.k]++;
        saveState();
        el.querySelector('.et-tally-count').textContent = et.tallies[el.dataset.k];
      });
    });
    body.querySelector('#et-reset').addEventListener('click', ()=>{
      et.tallies = { got_it:0, almost:0, need_help:0 };
      saveState(); draw();
    });
  }
  draw();
  return null;
}

function renderAgenda(body){
  function draw(){
    const ag = state.agenda;
    body.innerHTML = `
      <div class="agenda-board">
        <div class="field-block">
          <span class="field-label" data-i18n="agenda_schedule_label">${t('agenda_schedule_label')}</span>
          <textarea id="ag-schedule" placeholder="${t('agenda_schedule_placeholder')}" data-i18n-placeholder="agenda_schedule_placeholder">${ag.schedule}</textarea>
        </div>
        <div class="field-block">
          <span class="field-label" data-i18n="agenda_objective_label">${t('agenda_objective_label')}</span>
          <textarea id="ag-objective" placeholder="${t('agenda_objective_placeholder')}" data-i18n-placeholder="agenda_objective_placeholder">${ag.objective}</textarea>
        </div>
        <div class="field-block">
          <span class="field-label" data-i18n="agenda_donow_label">${t('agenda_donow_label')}</span>
          <textarea id="ag-donow" placeholder="${t('agenda_donow_placeholder')}" data-i18n-placeholder="agenda_donow_placeholder">${ag.doNow}</textarea>
        </div>
      </div>
    `;
    ['schedule','objective','doNow'].forEach((key,i)=>{
      const idMap = ['ag-schedule','ag-objective','ag-donow'];
      body.querySelector('#'+idMap[i]).addEventListener('input', e=>{
        ag[key] = e.target.value; saveState();
      });
    });
  }
  draw();
  return null;
}

function renderQrCode(body){
  function draw(){
    body.innerHTML = `
      <input type="text" id="qr-input" placeholder="${t('qr_placeholder')}" data-i18n-placeholder="qr_placeholder" style="width:100%">
      <div class="btn-row" style="margin-top:8px"><button class="wbtn primary" id="qr-go" data-i18n="qr_generate">${t('qr_generate')}</button></div>
      <div class="qr-canvas-wrap" id="qr-out"></div>
      <div class="btn-row" id="qr-dl-row" hidden><button class="wbtn" id="qr-download" data-i18n="qr_download">${t('qr_download')}</button></div>
      <p class="small-hint" data-i18n="qr_hint">${t('qr_hint')}</p>
    `;
    function generate(){
      const val = body.querySelector('#qr-input').value.trim();
      const out = body.querySelector('#qr-out');
      const dlRow = body.querySelector('#qr-dl-row');
      if(!val){ toast(t('qr_empty')); return; }
      if(typeof qrcode !== 'function'){ toast('QR library not loaded'); return; }
      const qr = qrcode(0, 'M');
      qr.addData(val);
      qr.make();
      out.innerHTML = qr.createSvgTag(6, 8);
      dlRow.hidden = false;
      const svgEl = out.querySelector('svg');
      body.querySelector('#qr-download').onclick = ()=>{
        const svgData = new XMLSerializer().serializeToString(svgEl);
        const canvas = document.createElement('canvas');
        const size = 400;
        canvas.width = size; canvas.height = size;
        const ctx2d = canvas.getContext('2d');
        const img = new Image();
        const svgBlob = new Blob([svgData], { type:'image/svg+xml;charset=utf-8' });
        const url = URL.createObjectURL(svgBlob);
        img.onload = ()=>{
          ctx2d.fillStyle = '#fff'; ctx2d.fillRect(0,0,size,size);
          ctx2d.drawImage(img,0,0,size,size);
          URL.revokeObjectURL(url);
          canvas.toBlob(blob=>{
            const a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = 'qrcode.png';
            a.click();
          });
        };
        img.src = url;
      };
    }
    body.querySelector('#qr-go').addEventListener('click', generate);
    body.querySelector('#qr-input').addEventListener('keydown', e=>{ if(e.key==='Enter') generate(); });
  }
  draw();
  return null;
}

function renderCountdown(body){
  let iv;
  function draw(){
    const cd = state.countdown;
    body.innerHTML = `
      <div class="cd-days" id="cd-days">—</div>
      <div class="cd-label" id="cd-label"></div>
      <div class="field-block">
        <input type="text" id="cd-label-input" placeholder="${t('cd_label_placeholder')}" data-i18n-placeholder="cd_label_placeholder" value="${cd.label ? cd.label.replace(/"/g,'&quot;') : ''}" style="width:100%; margin-bottom:8px">
        <span class="field-label" data-i18n="cd_date_label">${t('cd_date_label')}</span>
        <input type="date" id="cd-date-input" value="${cd.date||''}">
      </div>
    `;
    body.querySelector('#cd-label-input').addEventListener('input', e=>{ cd.label = e.target.value; saveState(); tick(); });
    body.querySelector('#cd-date-input').addEventListener('change', e=>{ cd.date = e.target.value; saveState(); tick(); });
    tick();
  }
  function tick(){
    const cd = state.countdown;
    const daysEl = body.querySelector('#cd-days');
    const labelEl = body.querySelector('#cd-label');
    if(!daysEl) return;
    if(!cd.date){
      daysEl.textContent = '—';
      labelEl.textContent = t('cd_set_prompt');
      return;
    }
    const target = new Date(cd.date + 'T00:00:00');
    const now = new Date();
    const todayMid = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const diffDays = Math.round((target - todayMid) / 86400000);
    if(diffDays < 0){
      daysEl.textContent = '0';
      labelEl.textContent = t('cd_past');
    } else if(diffDays === 0){
      daysEl.textContent = '🎉';
      labelEl.textContent = (cd.label || t('cd_today'));
    } else {
      daysEl.textContent = String(diffDays);
      labelEl.textContent = (cd.label ? cd.label + ' — ' : '') + (diffDays===1 ? t('cd_one_day') : t('cd_days_left', {n:diffDays}));
    }
  }
  draw();
  iv = setInterval(tick, 60000);
  return ()=>clearInterval(iv);
}

function renderHallPass(body){
  function draw(){
    if(!state.roster.length){
      body.innerHTML = `<p class="small-hint" data-i18n="hp_no_roster">${t('hp_no_roster')}</p>`;
      return;
    }
    const hp = state.hallPass;
    let formHtml = '';
    if(hp.current){
      const mins = Math.max(0, Math.floor((Date.now() - hp.current.start)/60000));
      formHtml = `
        <div class="hp-current">
          <span></span>
          <button class="wbtn primary" id="hp-return" data-i18n="hp_return">${t('hp_return')}</button>
        </div>
      `;
    } else {
      formHtml = `
        <div class="hp-form">
          <select id="hp-student">${state.roster.map(n=>`<option value="${n}">${n}</option>`).join('')}</select>
          <input type="text" id="hp-dest" placeholder="${t('hp_dest_placeholder')}" data-i18n-placeholder="hp_dest_placeholder">
          <button class="wbtn primary" id="hp-send" data-i18n="hp_send_out">${t('hp_send_out')}</button>
        </div>
      `;
    }
    body.innerHTML = `
      ${formHtml}
      <p class="field-label" data-i18n="hp_log_title" style="margin-top:6px">${t('hp_log_title')}</p>
      <div class="scroll-list" id="hp-log"></div>
      <div class="btn-row" style="margin-top:8px"><button class="wbtn" id="hp-clear" data-i18n="hp_clear_log">${t('hp_clear_log')}</button></div>
    `;
    if(hp.current){
      const mins = Math.max(0, Math.floor((Date.now() - hp.current.start)/60000));
      body.querySelector('.hp-current span').textContent = t('hp_out_since', { name:hp.current.name, dest:hp.current.dest || '' }) + ` (${mins}m)`;
      body.querySelector('#hp-return').addEventListener('click', ()=>{
        const durMin = Math.max(0, Math.round((Date.now() - hp.current.start)/60000));
        hp.log.unshift({ name:hp.current.name, dest:hp.current.dest, minutes:durMin, at:Date.now() });
        hp.current = null;
        saveState(); draw();
      });
    } else {
      body.querySelector('#hp-send').addEventListener('click', ()=>{
        const name = body.querySelector('#hp-student').value;
        const dest = body.querySelector('#hp-dest').value.trim();
        hp.current = { name, dest, start:Date.now() };
        saveState(); draw();
      });
    }
    const logEl = body.querySelector('#hp-log');
    hp.log.slice(0,20).forEach(entry=>{
      const div = document.createElement('div');
      div.className = 'hp-log-item';
      const time = new Date(entry.at).toLocaleTimeString(LOCALE_MAP[state.lang]||'en-US', {hour:'2-digit',minute:'2-digit'});
      div.textContent = `${time} — ${entry.name} (${entry.dest||'—'}) · ${entry.minutes}m`;
      logEl.appendChild(div);
    });
    body.querySelector('#hp-clear').addEventListener('click', ()=>{
      hp.log = []; saveState(); draw();
    });
  }
  draw();
  const iv = setInterval(()=>{ if(state.hallPass.current) draw(); }, 30000);
  return ()=>clearInterval(iv);
}

function renderReadingLog(body){
  let total, remaining, running=false, iv=null;
  function draw(){
    const rl = state.readingLog;
    total = (rl.minutes||15) * 60;
    remaining = total;
    body.innerHTML = `
      <div class="big-readout" id="rl-readout">--:--</div>
      <div class="btn-row" style="margin-bottom:8px">
        <button class="wbtn" data-m="-5">-5m</button>
        <span class="field-label" style="margin:0; align-self:center" id="rl-mins-label"></span>
        <button class="wbtn" data-m="5">+5m</button>
      </div>
      <div class="btn-row" style="margin-bottom:12px">
        <button class="wbtn primary" id="rl-start" data-i18n-dyn data-key="start">${t('start')}</button>
        <button class="wbtn" id="rl-reset" data-i18n="reset_btn">${t('reset_btn')}</button>
      </div>
      <p class="field-label" data-i18n="rl_log_title">${t('rl_log_title')}</p>
      <div class="btn-row">
        <input type="text" id="rl-student" placeholder="${t('rl_student_placeholder')}" data-i18n-placeholder="rl_student_placeholder" style="flex:1">
        <input type="number" id="rl-log-min" value="${rl.minutes||15}" min="1" style="width:60px">
        <button class="wbtn" id="rl-add" data-i18n="add_btn">${t('add_btn')}</button>
      </div>
      <div class="scroll-list" id="rl-list" style="margin-top:8px"></div>
      <div class="btn-row" style="margin-top:8px"><button class="wbtn" id="rl-clear" data-i18n="rl_clear_log">${t('rl_clear_log')}</button></div>
    `;
    updateReadout();
    body.querySelectorAll('[data-m]').forEach(b=>{
      b.addEventListener('click', ()=>{
        rl.minutes = Math.max(1, (rl.minutes||15) + parseInt(b.dataset.m));
        saveState();
        if(!running){ total = rl.minutes*60; remaining = total; }
        updateReadout();
      });
    });
    const startBtn = body.querySelector('#rl-start');
    startBtn.addEventListener('click', ()=>{
      running = !running;
      startBtn.dataset.key = running ? 'pause' : 'start';
      startBtn.textContent = t(startBtn.dataset.key);
      if(running){
        iv = setInterval(()=>{
          remaining--;
          if(remaining<=0){ remaining=0; running=false; clearInterval(iv); startBtn.dataset.key='start'; startBtn.textContent=t('start'); toast(t('time_up')); }
          updateReadout();
        },1000);
      } else clearInterval(iv);
    });
    body.querySelector('#rl-reset').addEventListener('click', ()=>{
      clearInterval(iv); running=false; startBtn.dataset.key='start'; startBtn.textContent=t('start');
      remaining = total; updateReadout();
    });
    body.querySelector('#rl-add').addEventListener('click', ()=>{
      const name = body.querySelector('#rl-student').value.trim();
      const min = parseInt(body.querySelector('#rl-log-min').value)||0;
      if(!name || !min) return;
      rl.entries.unshift({ id:cid(), name, minutes:min, at:Date.now() });
      body.querySelector('#rl-student').value = '';
      saveState(); renderList();
    });
    body.querySelector('#rl-clear').addEventListener('click', ()=>{
      rl.entries = []; saveState(); renderList();
    });
    renderList();
  }
  function updateReadout(){
    const el = body.querySelector('#rl-readout');
    const lbl = body.querySelector('#rl-mins-label');
    if(!el) return;
    const m = Math.floor(remaining/60), s = remaining%60;
    el.textContent = `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
    if(lbl) lbl.textContent = (state.readingLog.minutes||15) + 'm';
  }
  function renderList(){
    const list = body.querySelector('#rl-list');
    if(!list) return;
    list.innerHTML = '';
    state.readingLog.entries.slice(0,30).forEach(e=>{
      const div = document.createElement('div');
      div.className = 'rl-log-item';
      div.innerHTML = `<span></span><button>${iconSvg('close','wsvg')}</button>`;
      div.querySelector('span').textContent = t('rl_log_entry', { name:e.name, min:e.minutes });
      div.querySelector('button').addEventListener('click', ()=>{
        state.readingLog.entries = state.readingLog.entries.filter(x=>x.id!==e.id);
        saveState(); renderList();
      });
      list.appendChild(div);
    });
  }
  draw();
  return ()=>clearInterval(iv);
}

function renderTtsReader(body){
  const supported = 'speechSynthesis' in window;
  function draw(){
    if(!supported){
      body.innerHTML = `<p class="small-hint" data-i18n="tts_unsupported">${t('tts_unsupported')}</p>`;
      return;
    }
    body.innerHTML = `
      <textarea id="tts-text" placeholder="${t('tts_placeholder')}" data-i18n-placeholder="tts_placeholder" style="width:100%; min-height:80px">${state.ttsText||''}</textarea>
      <div class="tts-row">
        <select id="tts-voice"></select>
      </div>
      <div class="tts-row">
        <span class="field-label" style="margin:0" data-i18n="tts_speed">${t('tts_speed')}</span>
        <input type="range" id="tts-rate" min="0.5" max="1.8" step="0.1" value="1">
      </div>
      <div class="btn-row">
        <button class="wbtn primary" id="tts-play" data-i18n="tts_play">${t('tts_play')}</button>
        <button class="wbtn" id="tts-stop" data-i18n="tts_stop">${t('tts_stop')}</button>
      </div>
    `;
    const textEl = body.querySelector('#tts-text');
    textEl.addEventListener('input', ()=>{ state.ttsText = textEl.value; saveState(); });
    const voiceSel = body.querySelector('#tts-voice');
    function loadVoices(){
      const voices = speechSynthesis.getVoices();
      voiceSel.innerHTML = voices.map((v,i)=>`<option value="${i}">${v.name} (${v.lang})</option>`).join('');
    }
    loadVoices();
    speechSynthesis.onvoiceschanged = loadVoices;
    body.querySelector('#tts-play').addEventListener('click', ()=>{
      speechSynthesis.cancel();
      const text = textEl.value.trim();
      if(!text) return;
      const utter = new SpeechSynthesisUtterance(text);
      const voices = speechSynthesis.getVoices();
      const idx = parseInt(voiceSel.value);
      if(voices[idx]) utter.voice = voices[idx];
      utter.rate = parseFloat(body.querySelector('#tts-rate').value);
      speechSynthesis.speak(utter);
    });
    body.querySelector('#tts-stop').addEventListener('click', ()=> speechSynthesis.cancel());
  }
  draw();
  return ()=>{ if(supported) speechSynthesis.cancel(); };
}

const UC_LENGTH = { m:1, km:1000, cm:0.01, mm:0.001, mi:1609.344, yd:0.9144, ft:0.3048, in:0.0254 };
const UC_WEIGHT = { kg:1, g:0.001, mg:0.000001, lb:0.45359237, oz:0.028349523125 };
const UC_CURRENCY = { USD:1, VND:25400, EUR:0.92, GBP:0.79, JPY:149, KRW:1330 };

function renderUnitConverter(body){
  function draw(){
    body.innerHTML = `
      <div class="field-block">
        <span class="field-label" data-i18n="uc_category">${t('uc_category')}</span>
        <select id="uc-cat">
          <option value="length" data-i18n="uc_length">${t('uc_length')}</option>
          <option value="weight" data-i18n="uc_weight">${t('uc_weight')}</option>
          <option value="temperature" data-i18n="uc_temperature">${t('uc_temperature')}</option>
          <option value="currency" data-i18n="uc_currency">${t('uc_currency')}</option>
        </select>
      </div>
      <div class="uc-row">
        <input type="number" id="uc-from-val" value="1">
        <select id="uc-from-unit"></select>
      </div>
      <div class="uc-row" style="justify-content:center">
        <button class="uc-swap-btn" id="uc-swap">${iconSvg('swap','wsvg')}</button>
      </div>
      <div class="uc-row">
        <input type="number" id="uc-to-val" readonly>
        <select id="uc-to-unit"></select>
      </div>
      <p class="small-hint" id="uc-note"></p>
    `;
    const catSel = body.querySelector('#uc-cat');
    const fromUnit = body.querySelector('#uc-from-unit');
    const toUnit = body.querySelector('#uc-to-unit');
    const fromVal = body.querySelector('#uc-from-val');
    const toVal = body.querySelector('#uc-to-val');
    const note = body.querySelector('#uc-note');

    function unitsFor(cat){
      if(cat==='length') return Object.keys(UC_LENGTH);
      if(cat==='weight') return Object.keys(UC_WEIGHT);
      if(cat==='currency') return Object.keys(UC_CURRENCY);
      return ['C','F'];
    }
    function populateUnits(){
      const cat = catSel.value;
      const units = unitsFor(cat);
      fromUnit.innerHTML = units.map(u=>`<option value="${u}">${u}</option>`).join('');
      toUnit.innerHTML = units.map(u=>`<option value="${u}">${u}</option>`).join('');
      if(units.length>1) toUnit.value = units[1];
      note.textContent = cat==='currency' ? t('uc_currency_note') : '';
      note.hidden = cat!=='currency';
      convert();
    }
    function convert(){
      const cat = catSel.value;
      const val = parseFloat(fromVal.value);
      if(isNaN(val)){ toVal.value=''; return; }
      let result;
      if(cat==='length'){
        result = val * UC_LENGTH[fromUnit.value] / UC_LENGTH[toUnit.value];
      } else if(cat==='weight'){
        result = val * UC_WEIGHT[fromUnit.value] / UC_WEIGHT[toUnit.value];
      } else if(cat==='currency'){
        result = val / UC_CURRENCY[fromUnit.value] * UC_CURRENCY[toUnit.value];
      } else {
        if(fromUnit.value===toUnit.value) result = val;
        else if(fromUnit.value==='C') result = val*9/5+32;
        else result = (val-32)*5/9;
      }
      toVal.value = Math.round(result*10000)/10000;
    }
    catSel.addEventListener('change', populateUnits);
    [fromUnit,toUnit,fromVal].forEach(el=> el.addEventListener('input', convert));
    body.querySelector('#uc-swap').addEventListener('click', ()=>{
      const fu = fromUnit.value, tu = toUnit.value;
      fromUnit.value = tu; toUnit.value = fu;
      convert();
    });
    populateUnits();
  }
  draw();
  return null;
}

function renderAnnouncements(body){
  function draw(){
    const now = Date.now();
    state.announcements = state.announcements.filter(a=> !a.expiresAt || a.expiresAt > now);
    const items = state.announcements.slice().sort((a,b)=> (b.pinned - a.pinned) || (b.createdAt - a.createdAt));
    body.innerHTML = `
      <div class="ann-form">
        <textarea id="ann-text" placeholder="${t('ann_placeholder')}" data-i18n-placeholder="ann_placeholder"></textarea>
        <div class="ann-form-row">
          <label style="font-size:12px; display:flex; align-items:center; gap:4px"><input type="checkbox" id="ann-pin"> <span data-i18n="ann_pin">${t('ann_pin')}</span></label>
          <select id="ann-expiry" style="flex:1">
            <option value="0" data-i18n="ann_no_expiry">${t('ann_no_expiry')}</option>
            <option value="1">1d</option>
            <option value="3">3d</option>
            <option value="7">7d</option>
          </select>
          <button class="wbtn primary" id="ann-post" data-i18n="ann_post">${t('ann_post')}</button>
        </div>
      </div>
      <div class="scroll-list" id="ann-list"></div>
    `;
    const list = body.querySelector('#ann-list');
    if(!items.length){
      list.innerHTML = `<p class="small-hint" data-i18n="ann_empty">${t('ann_empty')}</p>`;
    }
    items.forEach(a=>{
      const div = document.createElement('div');
      div.className = 'ann-item' + (a.pinned ? ' pinned' : '');
      div.innerHTML = `
        <div class="ann-item-top">
          ${a.pinned ? `<span class="ann-badge" data-i18n="ann_pinned_badge">${t('ann_pinned_badge')}</span>` : '<span></span>'}
          <button aria-label="${t('remove')}">${iconSvg('close','wsvg')}</button>
        </div>
        <p style="margin:0"></p>
      `;
      div.querySelector('p').textContent = a.text;
      div.querySelector('button').addEventListener('click', ()=>{
        state.announcements = state.announcements.filter(x=>x.id!==a.id);
        saveState(); draw();
      });
      list.appendChild(div);
    });
    body.querySelector('#ann-post').addEventListener('click', ()=>{
      const text = body.querySelector('#ann-text').value.trim();
      if(!text) return;
      const days = parseInt(body.querySelector('#ann-expiry').value)||0;
      state.announcements.push({
        id:cid(), text,
        pinned: body.querySelector('#ann-pin').checked,
        createdAt: Date.now(),
        expiresAt: days ? Date.now() + days*86400000 : null
      });
      saveState(); draw();
    });
  }
  draw();
  return null;
}

function renderInstructions(body){
  let editing = false;
  function draw(){
    const ib = state.instructionsBoard;
    if(ib.current >= ib.steps.length) ib.current = Math.max(0, ib.steps.length-1);
    if(editing){
      body.innerHTML = `
        <input type="text" id="ins-title" placeholder="${t('ins_title_placeholder')}" data-i18n-placeholder="ins_title_placeholder" value="${ib.title?ib.title.replace(/"/g,'&quot;'):''}" style="width:100%; margin-bottom:8px">
        <div class="scroll-list" id="ins-edit-list"></div>
        <div class="btn-row" style="margin:8px 0">
          <input type="text" id="ins-new-step" placeholder="${t('ins_step_placeholder')}" data-i18n-placeholder="ins_step_placeholder" style="flex:1">
          <button class="wbtn" id="ins-add" data-i18n="ins_add_step">${t('ins_add_step')}</button>
        </div>
        <div class="btn-row"><button class="wbtn primary" id="ins-done" data-i18n="ins_done_editing">${t('ins_done_editing')}</button></div>
      `;
      body.querySelector('#ins-title').addEventListener('input', e=>{ ib.title = e.target.value; saveState(); });
      const editList = body.querySelector('#ins-edit-list');
      ib.steps.forEach((s,i)=>{
        const row = document.createElement('div');
        row.className = 'ins-edit-row';
        row.innerHTML = `<span></span><button>${iconSvg('close','wsvg')}</button>`;
        row.querySelector('span').textContent = `${i+1}. ${s.text}`;
        row.querySelector('button').addEventListener('click', ()=>{
          ib.steps.splice(i,1); saveState(); draw();
        });
        editList.appendChild(row);
      });
      function addStep(){
        const input = body.querySelector('#ins-new-step');
        const text = input.value.trim();
        if(!text) return;
        ib.steps.push({ id:cid(), text });
        saveState(); draw();
      }
      body.querySelector('#ins-add').addEventListener('click', addStep);
      body.querySelector('#ins-new-step').addEventListener('keydown', e=>{ if(e.key==='Enter') addStep(); });
      body.querySelector('#ins-done').addEventListener('click', ()=>{ editing = false; draw(); });
    } else {
      if(!ib.steps.length){
        body.innerHTML = `
          <p class="small-hint" data-i18n="ins_empty">${t('ins_empty')}</p>
          <div class="btn-row" style="margin-top:8px"><button class="wbtn primary" id="ins-edit" data-i18n="ins_edit">${t('ins_edit')}</button></div>
        `;
        body.querySelector('#ins-edit').addEventListener('click', ()=>{ editing = true; draw(); });
        return;
      }
      const step = ib.steps[ib.current];
      body.innerHTML = `
        ${ib.title ? `<p class="field-label" style="text-align:center; font-size:13px; margin-bottom:6px">${ib.title}</p>` : ''}
        <p class="ins-step-count"></p>
        <div class="ins-panel"><p></p></div>
        <div class="btn-row">
          <button class="wbtn" id="ins-prev" data-i18n="ins_prev">${t('ins_prev')}</button>
          <button class="wbtn" id="ins-next" data-i18n="ins_next">${t('ins_next')}</button>
        </div>
        <div class="btn-row" style="margin-top:8px"><button class="wbtn" id="ins-edit" data-i18n="ins_edit">${t('ins_edit')}</button></div>
      `;
      body.querySelector('.ins-step-count').textContent = t('ins_step_of', { cur: ib.current+1, total: ib.steps.length });
      body.querySelector('.ins-panel p').textContent = step.text;
      body.querySelector('#ins-prev').disabled = ib.current===0;
      body.querySelector('#ins-next').disabled = ib.current>=ib.steps.length-1;
      body.querySelector('#ins-prev').addEventListener('click', ()=>{ ib.current = Math.max(0, ib.current-1); saveState(); draw(); });
      body.querySelector('#ins-next').addEventListener('click', ()=>{ ib.current = Math.min(ib.steps.length-1, ib.current+1); saveState(); draw(); });
      body.querySelector('#ins-edit').addEventListener('click', ()=>{ editing = true; draw(); });
    }
  }
  draw();
  return null;
}

const CONVO_CARDS = [
  { text:"What's the best trip you've ever taken?", topic:'travel', diff:'easy' },
  { text:"If you could visit any country, where would you go and why?", topic:'travel', diff:'medium' },
  { text:"Describe a place you'd love to live someday.", topic:'travel', diff:'medium' },
  { text:"What's your favorite food, and how is it made?", topic:'food', diff:'easy' },
  { text:"Describe a meal you'll never forget.", topic:'food', diff:'medium' },
  { text:"Is street food better than restaurant food? Why or why not?", topic:'food', diff:'hard' },
  { text:"What's a hobby you'd like to start?", topic:'hobbies', diff:'easy' },
  { text:"Teach your partner one thing about your favorite hobby.", topic:'hobbies', diff:'medium' },
  { text:"If you had an extra 3 hours every day, what would you do with them?", topic:'hobbies', diff:'hard' },
  { text:"Who is someone you admire, and why?", topic:'people', diff:'medium' },
  { text:"Describe your best friend without saying their name.", topic:'people', diff:'easy' },
  { text:"What makes a good leader?", topic:'people', diff:'hard' },
  { text:"What's your morning routine like?", topic:'daily-life', diff:'easy' },
  { text:"What's the hardest part of your week?", topic:'daily-life', diff:'medium' },
  { text:"How has your daily life changed in the last five years?", topic:'daily-life', diff:'hard' },
  { text:"What's a movie or show everyone should watch?", topic:'entertainment', diff:'easy' },
  { text:"Do you prefer books or movies? Why?", topic:'entertainment', diff:'medium' },
  { text:"How do you think entertainment will change in the future?", topic:'entertainment', diff:'hard' },
  { text:"What's one thing you're grateful for today?", topic:'reflection', diff:'easy' },
  { text:"What's a mistake you learned something important from?", topic:'reflection', diff:'hard' }
];
const CC_TOPICS = ['travel','food','hobbies','people','daily-life','entertainment','reflection'];

function renderConvoCards(body){
  let idx = 0;
  function pool(){
    const topic = body.querySelector('#cc-topic')?.value || 'all';
    const diff = body.querySelector('#cc-diff')?.value || 'all';
    return CONVO_CARDS.filter(c=> (topic==='all'||c.topic===topic) && (diff==='all'||c.diff===diff));
  }
  function draw(){
    body.innerHTML = `
      <div class="cc-filters">
        <select id="cc-topic">
          <option value="all" data-i18n="cc_all">${t('cc_all')}</option>
          ${CC_TOPICS.map(tp=>`<option value="${tp}">${tp.replace('-',' ')}</option>`).join('')}
        </select>
        <select id="cc-diff">
          <option value="all" data-i18n="cc_all">${t('cc_all')}</option>
          <option value="easy" data-i18n="cc_diff_easy">${t('cc_diff_easy')}</option>
          <option value="medium" data-i18n="cc_diff_medium">${t('cc_diff_medium')}</option>
          <option value="hard" data-i18n="cc_diff_hard">${t('cc_diff_hard')}</option>
        </select>
      </div>
      <div class="cc-card" id="cc-text"></div>
      <div class="cc-card-tags" id="cc-tags"></div>
      <div class="btn-row"><button class="wbtn primary" id="cc-next" data-i18n="cc_next_card">${t('cc_next_card')}</button></div>
    `;
    body.querySelector('#cc-topic').addEventListener('change', next);
    body.querySelector('#cc-diff').addEventListener('change', next);
    body.querySelector('#cc-next').addEventListener('click', next);
    next();
  }
  function next(){
    const p = pool();
    const textEl = body.querySelector('#cc-text');
    const tagsEl = body.querySelector('#cc-tags');
    if(!p.length){ textEl.textContent = '—'; tagsEl.textContent=''; return; }
    idx = Math.floor(Math.random()*p.length);
    const card = p[idx];
    textEl.textContent = card.text;
    tagsEl.textContent = `${card.topic} · ${card.diff}`;
  }
  draw();
  return null;
}

const IDIOM_BANK = [
  { phrase:"Break the ice", meaning:"To start a conversation in a friendly way, especially with new people.", example:"She told a joke to break the ice on the first day of class." },
  { phrase:"Hit the books", meaning:"To study, especially seriously.", example:"I have a big test tomorrow, so I need to hit the books tonight." },
  { phrase:"Piece of cake", meaning:"Something very easy to do.", example:"Don't worry about the quiz — it's a piece of cake." },
  { phrase:"Under the weather", meaning:"Feeling slightly ill.", example:"I'm feeling a bit under the weather, so I might stay home today." },
  { phrase:"Cost an arm and a leg", meaning:"To be very expensive.", example:"That new phone cost an arm and a leg." },
  { phrase:"Once in a blue moon", meaning:"Something that happens very rarely.", example:"We only eat out once in a blue moon." },
  { phrase:"Bite the bullet", meaning:"To do something difficult or unpleasant that you've been avoiding.", example:"I finally bit the bullet and booked the dentist appointment." },
  { phrase:"Speak of the devil", meaning:"Said when the person you were just talking about arrives.", example:"Speak of the devil — here comes Maria now!" },
  { phrase:"Hit the nail on the head", meaning:"To describe exactly what is causing a situation or problem.", example:"You hit the nail on the head — that's exactly the issue." },
  { phrase:"Let the cat out of the bag", meaning:"To accidentally reveal a secret.", example:"I let the cat out of the bag about the surprise party." },
  { phrase:"On the same page", meaning:"To agree with or understand each other.", example:"Let's make sure we're on the same page before the meeting." },
  { phrase:"Better late than never", meaning:"It's better to do or arrive at something late than not at all.", example:"He finally sent the report — better late than never." },
  { phrase:"Call it a day", meaning:"To stop working on something, usually for the rest of the day.", example:"We've done a lot today — let's call it a day." },
  { phrase:"Cut corners", meaning:"To do something in the easiest or cheapest way, often lowering quality.", example:"The company cut corners on safety to save money." },
  { phrase:"Give someone the benefit of the doubt", meaning:"To trust what someone says even though you're not completely sure.", example:"I'll give him the benefit of the doubt this time." }
];

function dayOfYear(d){
  const start = new Date(d.getFullYear(),0,0);
  const diff = d - start;
  return Math.floor(diff / 86400000);
}

function renderIdiomDay(body){
  let showingToday = true;
  const todayIdx = dayOfYear(new Date()) % IDIOM_BANK.length;
  function draw(idx){
    const idiom = IDIOM_BANK[idx];
    body.innerHTML = `
      <div class="idiom-card">
        <p class="idiom-phrase"></p>
        <p><strong data-i18n="idiom_meaning">${t('idiom_meaning')}:</strong> <span id="idiom-meaning"></span></p>
        <p><strong data-i18n="idiom_example">${t('idiom_example')}:</strong> <span id="idiom-example"></span></p>
      </div>
      <div class="btn-row">
        <button class="wbtn" id="idiom-shuffle" data-i18n="idiom_shuffle">${t('idiom_shuffle')}</button>
        ${!showingToday ? `<button class="wbtn primary" id="idiom-today" data-i18n="idiom_back_today">${t('idiom_back_today')}</button>` : ''}
      </div>
    `;
    body.querySelector('.idiom-phrase').textContent = idiom.phrase;
    body.querySelector('#idiom-meaning').textContent = idiom.meaning;
    body.querySelector('#idiom-example').textContent = idiom.example;
    body.querySelector('#idiom-shuffle').addEventListener('click', ()=>{
      showingToday = false;
      draw(Math.floor(Math.random()*IDIOM_BANK.length));
    });
    const todayBtn = body.querySelector('#idiom-today');
    if(todayBtn) todayBtn.addEventListener('click', ()=>{ showingToday = true; draw(todayIdx); });
  }
  draw(todayIdx);
  return null;
}

const GRAMMAR_TOPICS = [
  { id:'present-simple', label:'Present Simple', rule:"Use for habits, facts, and routines. Add -s/-es for he/she/it.", examples:["I work every day.","She works on Mondays.","Water boils at 100°C."] },
  { id:'past-simple', label:'Past Simple', rule:"Use for finished actions at a specific past time. Regular verbs add -ed; many common verbs are irregular.", examples:["I walked to school.","She went to the store.","They didn't see the movie."] },
  { id:'present-continuous', label:'Present Continuous', rule:"Use am/is/are + verb-ing for actions happening now or temporary situations.", examples:["I am studying right now.","He is living in Hanoi this year.","They are not listening."] },
  { id:'articles', label:'Articles (a/an/the)', rule:"Use 'a/an' for a non-specific, singular, countable noun. Use 'the' for a specific noun both speakers know.", examples:["I saw a dog. The dog was brown.","She is an engineer.","Please close the door."] },
  { id:'plurals', label:'Plurals', rule:"Most nouns add -s. Nouns ending in -s, -x, -ch, -sh add -es. Nouns ending in consonant+y change y to i and add -es.", examples:["book → books","box → boxes","city → cities","child → children (irregular)"] },
  { id:'prepositions-time', label:'Prepositions of Time', rule:"Use 'at' for exact times, 'on' for days/dates, 'in' for months/years/longer periods.", examples:["at 7:00","on Monday","in July","in 2024"] },
  { id:'comparatives', label:'Comparatives & Superlatives', rule:"Short adjectives: add -er/-est. Long adjectives: use more/most.", examples:["fast → faster → fastest","beautiful → more beautiful → most beautiful","good → better → best (irregular)"] },
  { id:'modals', label:'Modal Verbs', rule:"Modals (can, could, should, must, may) are followed by the base form of the verb, with no 'to' and no -s.", examples:["She can swim.","You should study.","He must leave now."] }
];

function renderGrammarRef(body){
  let activeId = GRAMMAR_TOPICS[0].id;
  function draw(){
    body.innerHTML = `
      <div class="gr-topics">
        ${GRAMMAR_TOPICS.map(g=>`<button class="gr-topic-btn ${g.id===activeId?'active':''}" data-id="${g.id}">${g.label}</button>`).join('')}
      </div>
      <div class="gr-card"><h4></h4><p id="gr-rule"></p><p style="margin-top:8px"><strong data-i18n="gr_examples">${t('gr_examples')}:</strong></p><p id="gr-examples"></p></div>
    `;
    const topic = GRAMMAR_TOPICS.find(g=>g.id===activeId);
    body.querySelector('.gr-card h4').textContent = topic.label;
    body.querySelector('#gr-rule').textContent = topic.rule;
    body.querySelector('#gr-examples').innerHTML = topic.examples.map(e=>`• ${e}`).join('<br>');
    body.querySelectorAll('.gr-topic-btn').forEach(btn=>{
      btn.addEventListener('click', ()=>{ activeId = btn.dataset.id; draw(); });
    });
  }
  draw();
  return null;
}


/* ---------------- Theme drawer ---------------- */
const PRESETS = [
  { id:'dusk',  css:'linear-gradient(180deg,#1a2740 0%, #2c3b57 38%, #3f4f68 62%, #263248 100%)' },
  { id:'chalk', css:'linear-gradient(180deg,#2b2f26 0%, #3a4032 60%, #23261e 100%)' },
  { id:'ocean', css:'linear-gradient(180deg,#0e2f3f 0%, #164a5c 55%, #0c2733 100%)' },
  { id:'sunrise', css:'linear-gradient(180deg,#3a2140 0%, #7a4a55 45%, #c98a5e 100%)' },
  { id:'slate', css:'linear-gradient(180deg,#20242c 0%, #2b3038 100%)' },
  { id:'plain', css:'#12161C' }
];

const bgLayer = document.getElementById('bg-layer');
const bgOverlay = document.getElementById('bg-overlay');
let logoImgEl = null;
// Object URL of a background that was applied from the picked file but could
// NOT be saved (e.g. storage blocked in an embedded/sandboxed preview). It
// shows for this session only; null whenever the background is saved/preset.
let sessionBgUrl = null;

function paintPreset(){
  const p = PRESETS.find(p=>p.id===state.theme) || PRESETS[0];
  bgLayer.style.background = p.css;
  bgLayer.style.backgroundSize = 'cover';
}

function applyTheme(){
  if(sessionBgUrl){
    bgLayer.style.background = `center/cover no-repeat url(${sessionBgUrl})`;
  } else if(state.customBg){
    // custom image is applied async from IDB (see initCustomBg)
  } else {
    paintPreset();
  }
  bgOverlay.classList.toggle('no-dim', !state.dim);
}

async function initCustomBg(){
  if(state.customBg){
    try{
      const rec = await idb.get('images', state.activeBgId || 'background');
      if(rec){
        const url = URL.createObjectURL(rec.blob);
        bgLayer.style.background = `center/cover no-repeat url(${url})`;
      } else if(!sessionBgUrl){
        paintPreset();   // saved image is gone — show the theme instead of a blank layer
      }
    }catch(err){
      console.error('TeachersDeck: failed to load custom background', err);
      if(!sessionBgUrl) paintPreset();
    }
  }
  if(state.logo){
    try{
      const rec = await idb.get('images','logo');
      if(rec){
        const url = URL.createObjectURL(rec.blob);
        if(!logoImgEl){
          logoImgEl = document.createElement('img');
          logoImgEl.className = 'bg-logo-mark';
          document.body.appendChild(logoImgEl);
        }
        logoImgEl.src = url;
        document.getElementById('logo-preview').src = url;
        document.getElementById('logo-preview-row').hidden = false;
      }
    }catch(err){ console.error('TeachersDeck: failed to load logo', err); }
  }
}

function buildPresetSwatches(){
  const grid = document.getElementById('theme-presets');
  grid.innerHTML = '';
  PRESETS.forEach(p=>{
    const sw = document.createElement('div');
    sw.className = 'swatch' + ((!state.customBg && !sessionBgUrl && state.theme===p.id) ? ' active' : '');
    sw.style.background = p.css;
    sw.title = p.id;
    sw.addEventListener('click', ()=>{
      state.theme = p.id; state.customBg = false;
      if(sessionBgUrl){ URL.revokeObjectURL(sessionBgUrl); sessionBgUrl = null; }
      saveState(); applyTheme(); buildPresetSwatches();
    });
    grid.appendChild(sw);
  });
}

document.querySelector('label[for="bg-upload"]').addEventListener('click', e=>{
  if(!isPro()){ e.preventDefault(); openProModal('bg'); }
});
document.getElementById('bg-upload').addEventListener('change', async e=>{
  const file = e.target.files[0];
  e.target.value = '';   // lets the same file be picked again later
  if(!file) return;
  // 1) Show it right away, straight from the picked file — this doesn't depend
  //    on any browser storage, so the background always changes.
  if(sessionBgUrl) URL.revokeObjectURL(sessionBgUrl);
  sessionBgUrl = URL.createObjectURL(file);
  applyTheme();
  buildPresetSwatches();
  // 2) Then try to remember it (single slot, id 'background', as before). If
  //    storage is unavailable or stalls, the background still stays for this
  //    session and we say it won't be remembered.
  try{
    await Promise.race([
      idb.put('images', { id:bgIdForClass(), blob:file }),
      new Promise((_,rej)=> setTimeout(()=> rej(new Error('timed out saving background')), 6000))
    ]);
    state.activeBgId = bgIdForClass();
    state.customBg = true;
    saveState();
    sessionBgUrl = null;      // saved: from here on it loads from storage like any custom background
    buildPresetSwatches();
    toast(t('bg_updated'));
  }catch(err){
    console.error('TeachersDeck: background applied but could not be saved', err);
    toast(t('bg_not_saved'), 5000);
  }
});

document.querySelector('label[for="logo-upload"]').addEventListener('click', e=>{
  if(!isPro()){ e.preventDefault(); openProModal('logo'); }
});
document.getElementById('logo-upload').addEventListener('change', async e=>{
  const file = e.target.files[0];
  e.target.value = '';
  if(!file) return;
  try{
    await idb.put('images', { id:'logo', blob:file });
  }catch(err){
    console.error('TeachersDeck: logo upload failed', err);
    toast(t('bg_upload_failed'), 5000);
    return;
  }
  state.logo = true;
  saveState();
  initCustomBg();
  toast(t('logo_updated'));
});

document.getElementById('logo-remove').addEventListener('click', async ()=>{
  await idb.delete('images','logo');
  state.logo = false; saveState();
  if(logoImgEl) logoImgEl.remove();
  logoImgEl = null;
  document.getElementById('logo-preview-row').hidden = true;
  toast(t('logo_removed'));
});

document.getElementById('dim-toggle').addEventListener('change', e=>{
  state.dim = e.target.checked; saveState(); applyTheme();
});

/* ---------------- Classes: top-bar switcher + Settings manager ----------------
   The pill shows the class that's open; its menu switches class. Switching
   saves the current class, points the index at the new one and reloads, so
   every widget comes back up from that class's own saved state. ------------ */
function classDisplayName(c){
  return (c && c.name && c.name.trim()) ? c.name.trim() : t('class_default_name');
}

function buildClassPill(){
  const wrap = document.getElementById('class-pill-wrap');
  const nameEl = document.getElementById('class-pill-name');
  if(!wrap || !nameEl) return;
  nameEl.textContent = classDisplayName(activeClass());
  wrap.querySelector('.class-pill').title = t('class_switch_label');
  // In the top pill row the pill sits on the left, so drop the menu leftwards;
  // in the header's right-hand actions it drops rightwards.
  wrap.classList.toggle('align-left', wrap.parentElement && wrap.parentElement.id === 'pills-top');
}

function buildClassMenu(){
  const menu = document.getElementById('class-menu');
  if(!menu) return;
  menu.innerHTML = '';
  classes.list.forEach(c=>{
    const btn = document.createElement('button');
    btn.className = 'class-menu-item' + (c.id === activeClassId() ? ' active' : '');
    btn.innerHTML = `<span class="class-menu-name"></span><span class="class-menu-tick">${c.id === activeClassId() ? '✓' : ''}</span>`;
    btn.querySelector('.class-menu-name').textContent = classDisplayName(c);
    btn.addEventListener('click', ()=> switchClass(c.id));
    menu.appendChild(btn);
  });
  const sep = document.createElement('div');
  sep.className = 'class-menu-sep';
  menu.appendChild(sep);
  const manage = document.createElement('button');
  manage.className = 'class-menu-item manage';
  manage.textContent = t('class_manage');
  manage.addEventListener('click', ()=>{
    closeClassMenu();
    const drawer = document.getElementById('settings-drawer');
    drawer.hidden = false;
    const sec = document.getElementById('classes-section');
    if(sec) sec.scrollIntoView({ block:'start' });
    const input = document.getElementById('class-new-input');
    if(input) input.focus();
  });
  menu.appendChild(manage);
}

function openClassMenu(){
  buildClassMenu();
  document.getElementById('class-menu').hidden = false;
  document.getElementById('class-pill').setAttribute('aria-expanded','true');
}
function closeClassMenu(){
  const menu = document.getElementById('class-menu');
  if(menu) menu.hidden = true;
  const pill = document.getElementById('class-pill');
  if(pill) pill.setAttribute('aria-expanded','false');
}

function switchClass(id){
  closeClassMenu();
  if(id === activeClassId()) return;
  if(!classes.list.some(c=> c.id === id)) return;
  saveState();            // flush the class we're leaving (its key is still the active one)
  classes.active = id;
  saveClasses();
  location.reload();      // reopen as that class's own instance
}

function newClassId(){ return 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2,6); }

function addClass(name, copyCurrent){
  if(classes.list.length >= MAX_CLASSES){ toast(t('class_max', { max: MAX_CLASSES })); return; }
  const id = newClassId();
  saveState();            // make sure the class we're leaving is on disk first
  if(copyCurrent){
    try{ localStorage.setItem(classStateKey(id), JSON.stringify(state)); }catch(e){}
  }
  classes.list.push({ id, name: (name || '').trim() });
  classes.active = id;
  saveClasses();
  location.reload();
}

function renameClass(id, name){
  const c = classes.list.find(x=> x.id === id);
  if(!c) return;
  c.name = (name || '').trim();
  saveClasses();
  buildClassPill();
}

async function deleteClass(id){
  if(classes.list.length <= 1){ toast(t('class_last')); return; }
  const c = classes.list.find(x=> x.id === id);
  if(!c) return;
  if(!confirm(t('class_delete_confirm', { name: classDisplayName(c) }))) return;
  const wasActive = id === activeClassId();
  // its own saved state, and its own background image
  try{ localStorage.removeItem(classStateKey(id)); }catch(e){}
  const bgId = id === DEFAULT_CLASS_ID ? 'background' : `background::${id}`;
  try{ await idb.delete('images', bgId); }catch(e){ /* nothing saved, or storage blocked */ }
  classes.list = classes.list.filter(x=> x.id !== id);
  if(wasActive){
    classes.active = classes.list[0].id;
    saveClasses();
    location.reload();    // the open class just went away — open the next one
    return;
  }
  saveClasses();
  buildClassList();
  buildClassPill();
  toast(t('class_deleted'));
}

function buildClassList(){
  const box = document.getElementById('class-list');
  if(!box) return;
  box.innerHTML = '';
  classes.list.forEach(c=>{
    const row = document.createElement('div');
    row.className = 'class-row' + (c.id === activeClassId() ? ' current' : '');
    row.innerHTML = `
      <input type="text" class="class-row-name" value="">
      <button class="class-row-btn open" type="button"></button>
      <button class="class-row-btn del" type="button" aria-label="">×</button>
    `;
    const input = row.querySelector('.class-row-name');
    input.value = c.name || '';
    input.placeholder = t('class_default_name');
    input.addEventListener('change', ()=> renameClass(c.id, input.value));
    input.addEventListener('blur', ()=> renameClass(c.id, input.value));
    const openBtn = row.querySelector('.class-row-btn.open');
    openBtn.textContent = c.id === activeClassId() ? t('class_current') : t('class_switch_to');
    openBtn.disabled = c.id === activeClassId();
    openBtn.addEventListener('click', ()=>{
      renameClass(c.id, input.value);
      switchClass(c.id);
    });
    const delBtn = row.querySelector('.class-row-btn.del');
    delBtn.setAttribute('aria-label', t('class_delete'));
    delBtn.title = t('class_delete');
    delBtn.addEventListener('click', ()=> deleteClass(c.id));
    box.appendChild(row);
  });
}

function wireClasses(){
  const pill = document.getElementById('class-pill');
  if(!pill) return;
  pill.addEventListener('click', e=>{
    e.stopPropagation();
    const menu = document.getElementById('class-menu');
    if(menu.hidden) openClassMenu(); else closeClassMenu();
  });
  document.addEventListener('click', e=>{
    const wrap = document.getElementById('class-pill-wrap');
    if(wrap && !wrap.contains(e.target)) closeClassMenu();
  });
  document.addEventListener('keydown', e=>{ if(e.key === 'Escape') closeClassMenu(); });

  const input = document.getElementById('class-new-input');
  const addBtn = document.getElementById('class-add-btn');
  const copyBtn = document.getElementById('class-copy-btn');
  addBtn.addEventListener('click', ()=> addClass(input.value, false));
  input.addEventListener('keydown', e=>{ if(e.key === 'Enter') addClass(input.value, false); });
  copyBtn.addEventListener('click', ()=>{
    const base = classDisplayName(activeClass());
    addClass(`${base} (${t('class_copy_suffix')})`, true);
  });
  buildClassList();
  buildClassPill();
}

/* ---------------- Drawers open/close ---------------- */
function wireDrawer(btnId, drawerId, closeId){
  const drawer = document.getElementById(drawerId);
  document.getElementById(btnId).addEventListener('click', ()=>{ drawer.hidden = false; });
  document.getElementById(closeId).addEventListener('click', ()=>{ drawer.hidden = true; });
}
wireDrawer('btn-theme','theme-drawer','theme-close');
wireDrawer('btn-settings','settings-drawer','settings-close');

/* ---------------- TeachersDeck Pro ---------------- */
function fmtPrice(){
  return `$${PRO_PRICE_USD} / ${PRO_PRICE_VND.toLocaleString('vi-VN')}₫`;
}
function buildProStatus(){
  const badge = document.getElementById('pro-badge');
  const text = document.getElementById('pro-status-text');
  const licenseRow = document.getElementById('pro-license-row');
  const upgradeBtn = document.getElementById('pro-upgrade-open');
  if(isPro()){
    badge.textContent = 'PRO'; badge.classList.add('is-pro');
    text.textContent = t('pro_status_pro'); text.removeAttribute('data-i18n');
    licenseRow.hidden = true;
    upgradeBtn.hidden = true;
  } else {
    badge.textContent = 'FREE'; badge.classList.remove('is-pro');
    text.textContent = t('pro_status_free'); text.setAttribute('data-i18n','pro_status_free');
    licenseRow.hidden = false;
    upgradeBtn.hidden = false;
  }
}

function buildVietQRPanel(){
  const box = document.getElementById('vietqr-qr-box');
  document.getElementById('vietqr-copy').textContent = t('vietqr_instructions', { price: fmtPrice() });
  if(!HSBC_ACCOUNT_NUMBER){
    box.innerHTML = `<div class="qr-missing">${t('vietqr_not_configured')}</div>`;
    return;
  }
  const addInfo = encodeURIComponent('TeachersDeck Pro');
  const acctName = encodeURIComponent(HSBC_ACCOUNT_NAME || '');
  const url = `https://img.vietqr.io/image/${HSBC_VIETQR_BIN}-${HSBC_ACCOUNT_NUMBER}-compact2.png?amount=${PRO_PRICE_VND}&addInfo=${addInfo}&accountName=${acctName}`;
  box.innerHTML = `<img src="${url}" alt="VietQR payment code">`;
}
function buildCardPanel(){
  document.getElementById('card-copy').textContent = t('card_instructions', { price: fmtPrice() });
  const link = document.getElementById('pay-card-link');
  if(!STRIPE_PAYMENT_LINK){
    link.removeAttribute('href');
    link.textContent = t('card_not_configured');
    link.style.opacity = .6; link.style.pointerEvents = 'none';
  } else {
    link.href = STRIPE_PAYMENT_LINK;
    link.textContent = t('pay_card_btn', { label: CARD_PROCESSOR_LABEL });
    link.style.opacity = 1; link.style.pointerEvents = 'auto';
  }
}
function buildPayTabs(){
  document.getElementById('pay-tab-card').dataset.key = 'pay_tab_card';
  document.getElementById('pay-tab-card').textContent = t('pay_tab_card', { label: CARD_PROCESSOR_LABEL });
}

const proModalBackdrop = document.getElementById('pro-modal-backdrop');
function openProModal(){
  buildVietQRPanel();
  buildCardPanel();
  buildPayTabs();
  proModalBackdrop.hidden = false;
}
function closeProModal(){ proModalBackdrop.hidden = true; }
document.getElementById('pro-upgrade-open').addEventListener('click', ()=> openProModal());
document.getElementById('pro-modal-close').addEventListener('click', closeProModal);
proModalBackdrop.addEventListener('click', e=>{ if(e.target === proModalBackdrop) closeProModal(); });

document.getElementById('pay-tab-vietqr').addEventListener('click', ()=>{
  document.getElementById('pay-tab-vietqr').classList.add('active');
  document.getElementById('pay-tab-card').classList.remove('active');
  document.getElementById('pay-panel-vietqr').hidden = false;
  document.getElementById('pay-panel-card').hidden = true;
});
document.getElementById('pay-tab-card').addEventListener('click', ()=>{
  document.getElementById('pay-tab-card').classList.add('active');
  document.getElementById('pay-tab-vietqr').classList.remove('active');
  document.getElementById('pay-panel-card').hidden = false;
  document.getElementById('pay-panel-vietqr').hidden = true;
});

document.getElementById('pro-license-activate').addEventListener('click', ()=>{
  const input = document.getElementById('pro-license-input');
  if(activateLicense(input.value)){
    toast(t('pro_license_valid'));
    buildProStatus();
    closeProModal();
  } else {
    toast(t('pro_license_invalid'));
  }
});

/* ---------------- Settings: reset ---------------- */
document.getElementById('reset-layout').addEventListener('click', ()=>{
  state.layout = {};
  Object.keys(state.active).filter(id=>state.active[id]).forEach(id=>{
    closeWidget(id); openWidget(id);
  });
  saveState();
  toast(t('layout_reset_toast'));
  document.getElementById('settings-drawer').hidden = true;
});
document.getElementById('reset-all').addEventListener('click', ()=>{
  if(!confirm(t('reset_all_confirm'))) return;
  // every class's state, not just the active one
  classes.list.forEach(c=>{ try{ localStorage.removeItem(classStateKey(c.id)); }catch(e){} });
  try{ localStorage.removeItem(CLASSES_KEY); }catch(e){}
  localStorage.removeItem(LS_KEY);
  indexedDB.deleteDatabase('TeachersDeck');
  location.reload();
});

/* ---------------- Language: quick toggle + settings pickers ---------------- */
function setLanguage(code){
  state.lang = code;
  saveState();
  document.documentElement.lang = code;
  localizeNode(document);
  rebuildAllDocks();
  buildLangToggle();
  buildClassPill();
  buildClassList();
}

function buildLangToggle(){
  const box = document.getElementById('lang-toggle');
  box.innerHTML = '';
  state.langPair.forEach(code=>{
    const lang = LANGS.find(l=>l.code===code);
    if(!lang) return;
    const btn = document.createElement('button');
    btn.textContent = lang.code.toUpperCase();
    btn.title = lang.name;
    btn.className = state.lang === code ? 'active' : '';
    btn.addEventListener('click', ()=> setLanguage(code));
    box.appendChild(btn);
  });
}

function buildLangSelects(){
  const sel1 = document.getElementById('lang-select-1');
  const sel2 = document.getElementById('lang-select-2');
  [sel1, sel2].forEach(sel=>{
    sel.innerHTML = LANGS.map(l=>`<option value="${l.code}">${l.name}</option>`).join('');
  });
  sel1.value = state.langPair[0];
  sel2.value = state.langPair[1];

  function onPairChange(){
    state.langPair = [sel1.value, sel2.value];
    saveState();
    if(!state.langPair.includes(state.lang)){
      setLanguage(state.langPair[0]);
    } else {
      buildLangToggle();
    }
  }
  sel1.addEventListener('change', onPairChange);
  sel2.addEventListener('change', onPairChange);
}

/* ---------------- Init ---------------- */
function init(){
  // One-time cleanup: the local database used to be named "widget-wall"
  // (from before the app was renamed to TeachersDeck). It's fully replaced
  // by the "TeachersDeck" database now, so remove the old one rather than
  // leaving orphaned data sitting in the browser. Best-effort and silent —
  // this is harmless if it's already gone.
  try{ indexedDB.deleteDatabase('widget-wall'); }catch(e){}

  ensureDockPlacement();
  buildLangToggle();
  rebuildAllDocks();
  wireClasses();
  wireAppTray();
  buildLangSelects();
  buildLayoutModeSelector();
  buildDockPlacementList();
  buildDrawerSettings();
  buildCalendarSystemSelect();
  localizeNode(document);
  buildPresetSwatches();
  applyTheme();
  initCustomBg();
  buildProStatus();
  const verEl = document.getElementById('app-version');
  if(verEl) verEl.textContent = `${t('version_label')} ${APP_VERSION}`;
  Object.keys(state.active).filter(id=>state.active[id]).forEach(id=> openWidget(id));
  checkScoreboardTransfer(); // catches a game's "send scores" that arrived while this tab was closed
  if(!Object.keys(state.active).some(id=>state.active[id])){
    openWidget('clock'); saveState();
  }
  checkReminders();
  setInterval(checkReminders, 30000);
}
init();
