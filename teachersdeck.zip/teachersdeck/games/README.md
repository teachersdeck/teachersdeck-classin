# games/

A place to drop your own HTML games (plus anything they need — images,
sound effects, a separate .js/.css file, a PDF or .txt of instructions for
students) so they show up in the Games widget's **Built-in games** section,
right alongside anything uploaded through the widget itself.

This is a second, separate way to get a game into the widget:

- **Upload button in the widget** — quick, but only accepts a single
  `.html`/`.htm` file at a time. Fine for a game that's one self-contained
  file with everything inlined (styles and script in `<style>`/`<script>`
  tags, no separate image files).
- **This folder** — for a game that's more than one file (a folder of
  images, a separate script, an instructions handout). Drop the whole
  folder here and register it below.

## Adding a game

1. Make a subfolder here, one per game, e.g. `games/my-trivia-game/`.
2. Put the game's entry HTML file in it (commonly `index.html`), plus any
   other files it needs — same folder or a subfolder of its own.
3. Add an entry for it to `games.json` in this same directory:

   ```json
   {
     "name": "My Trivia Game",
     "folder": "my-trivia-game",
     "entry": "index.html",
     "instructions": "instructions.txt"
   }
   ```

   `instructions` is optional — leave it out if the game doesn't have one.
   When it's set, the game's tile in the widget gets a small "?" button
   (top-left corner) that opens that file in a new tab — handy for a plain
   `.txt`/`.pdf` handout. If your game already has its own in-game "How to
   play" link (like the Classroom Word Wheel example below does), the "?"
   button and the in-game link both work — pick whichever you want to keep.
   Add your game's object to the array alongside any others already there.
4. Reload the app. Your game appears as a tile in the Games widget's
   Built-in games section, next to any uploaded games.

An example is already set up here (`example-guess-the-number/`, listed in
`games.json`) — open it up to see the pattern, or just delete it once you
don't need it as a reference. `Classroom-Word-Wheel/` is a second, more
built-out example — see "House style for TeachersDeck games" below if
you're building something in that vein.

## House style for TeachersDeck games

`Classroom-Word-Wheel/` is the reference for how games in this app should
look and feel going forward — not a rule that every game must copy every
piece of it, but the default to reach for unless a game has a good reason
to differ:

- **Look:** dark navy/gold theme — a `:root` block of CSS custom properties
  for the palette (stage/panel backgrounds, gold accent, ink text colors,
  plus a small set of bright accent colors for things like team cards),
  'Baloo 2' (rounded, playful) for headings and big display text, 'Inter'
  for body text and UI chrome, both pulled from Google Fonts. Single
  self-contained HTML file — CSS and JS inline, no build step, no external
  JS dependencies (any sound is synthesized with the WebAudio API rather
  than loading audio files).
- **A companion `instructions.html`** — same visual theme, a "Back to the
  game" link at the top, numbered sections explaining setup and play,
  linked from a "How to play" button in the game's own header. (Simpler
  games can use a plain `.txt`/`.pdf` via the `instructions` field in
  `games.json` instead — see above.)
- **Teacher-only setup, hidden in plain sight:** for games with a secret
  answer/prompt, a "Host setup" panel with the secret entered as a
  password-masked input (dots instead of characters) so it's safe to fill
  in even with the screen projected, plus a separate field for anything
  meant to be shown to the class (like a category).
- **Feedback:** a small toast notification for status messages, a
  mute/sound-on-off toggle in the header, distinct sounds for
  correct/incorrect/win — all synthesized, not audio files.
- **Scoring:** a Teams panel — click a team's card to mark it active, each
  card has an editable name and +1/−1 buttons, plus a "reset scores"
  action. Multi-round friendly (scores persist across "New puzzle"/"New
  round").

**Sending scores to the Scoreboard widget:** Classroom Word Wheel's "Send
scores to Scoreboard widget" button hands its team scores to TeachersDeck's
built-in Scoreboard widget — via `localStorage.setItem('td_scoreboard_transfer', ...)`,
since the game and the app share the same origin. The app listens for that
key and applies it (live via a `storage` event if its tab is already open,
or on its next load otherwise), opening the Scoreboard widget if it isn't
open already. Any new game that keeps its own scores can use this same
handoff instead of reinventing a scoreboard — write
`{ teams: [{name, score}, ...], from: '<game name>' }` (JSON-stringified)
to that same key.

## Notes

- Games listed in `games.json` open in a new browser tab (`games/<folder>/<entry>`),
  same as an uploaded game does.
- This only works when TeachersDeck is served over `http://localhost` or
  loaded as the Chrome extension — same requirement as the rest of the app
  (see the main README's "load via Chrome" section). Opened as a plain
  double-clicked `index.html` file, the browser won't let the page read
  `games.json` off disk, so this section just won't show anything; the
  widget's own upload button still works either way.
- Games added here aren't stored in the browser's IndexedDB the way
  uploaded games are — they're just files sitting in this folder, so
  there's nothing to "lose" if a teacher clears site data or switches
  computers, as long as this `teachersdeck/` folder comes along with them.
